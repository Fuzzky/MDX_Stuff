


/****************************************************************************
;
; NAME: oswrap.c
;
;
; DESCRIPTION:
;
;       Linux interface wrap functions
;
;
; REVISION HISTORY:
;
;       $Log: /pcidrv/source/shared/linux/driver/oswrap.c $
; 
; 188   6/10/16 5:34p Mharbison
; multipath: fix compile error on Linux
; 
; 187   6/10/16 5:15p Mharbison
; multipath: disable device_reset and target_reset handlers on Linux
; 
; These were using the OS's idea of the target and LUN to tell the HW
; layer what to do, but need to be translated first.  Disabling seems
; less risky than trying to figure out how to test this close to a
; release.
; 
; 186   6/08/16 10:51a Jseba
; Pass pointer to ioctl to OsGetIoctlSize (IR 16261)
; 
; 185   5/26/16 3:25p Mharbison
; linux: add support for reporting 32Gb/s port speed
; 
; 183   4/12/16 5:33p Sschmitz
; Remove EXPRESS2 code.
; 
; 182   4/12/16 1:42p Mharbison
; multipath: allow the SfDebug mask to be configured on Linux
; 
; Support for this mask is conditionally compiled into the core module by
; setting ENABLE_ATTO_DEBUG=1 in the make command, but the driver layer
; makefile doesn't pay any attention to that.  Since the modparam logic
; needs to live in the driver layer, detect whether or not the core was
; built with SfDebug support, and tailor driver conditionals accordingly.
; 
; The sysfs node '/sys/bus/pci/drivers/$driver/module/parameters/atto_sfl
; ib_mask'
; is created by the kernel (at least on Fedora 16), so don't bother with
; that.  (Yes, existing *_log_mask file code is probably useless.)
; Unfortunately, it is
; readonly and printed in decimal instead of hex.
; 
; We could leave the parameter always compiled in and do nothing with it,
; but that would leave no easy way to tell if the driver supports the
; logging, and it seems better to fail fast if the parameter is
; configured, and the driver
; doesn't support it.
; 
; 181   11/13/15 10:49a Bgrove
; Added messages documenting conflict with open source kernel driver for
; esas2hba, esas4hba, and esasraid2.
;  
; 
; 180   10/29/15 11:20a Bgrove
; Don't fall back to legacy interrupts when MSI-X interrupts are enabled
; but only one queue is allocated (IR 15727).   Also fixed bug where ESXi
; could not write to diagnostic partition when MSI-X interrupts were
; enabled.
; 
; 179   10/20/15 2:08p Jseba
; Fix num_sas_addr settings and defaults for ESAS2HBA and ESAS4HBA and
; remove it altogether for ESAS3HBA
; 
; 178   6/17/15 1:05p Bgrove
; Tom's cleanup of cpp macros to enable VSA IOCTLs
; 
; 176   5/26/15 1:23p Jschreiber
; The t10_dif module parameter no longer applies to the 8 and 16Gb
; Celerity adapters.
; 
; 175   4/22/15 11:55a Bgrove
; Rename driver os.h to oscommon.h to eliminate duplicate filename
; 
; 174   4/22/15 11:45a Bgrove
; Use unique names for FC and SAS transport layers
; 
; 173   2/26/15 3:46p Jseba
; Updates for kernels 3.19 and 4.0
; 
; 172   11/14/14 2:55p Jseba
; Enable zero_eecc for ESAS2HBA
; 
; 171   10/15/14 11:26a Jschreiber
; Add login_to_targets_only module parameter for 16Gb Celerity.  The
; default for this setting should be 0 (DISABLED).
; 
; 170   9/25/14 4:14p Bgrove
; Turn on VMware multiqueue support by default
; 
; 169   7/24/14 1:55p Jschreiber
; Change the default value of the can_queue module parameter to 512 (was
; 128).
; 
; 168   7/21/14 11:24a Jseba
; Use proper signedness for module parameters (IR 14452)
; 
; 167   7/02/14 4:14p Jseba
; Added support for "zero_eecc" parameter for 12GB (IR IR 14220)
; 
; 166   6/11/14 3:14p Pcullen
; Make change_notification a module parameter only for SAS HBAs. (IR
; 14285).
; 
; 165   6/11/14 11:13a Pcullen
; Clarify that the change_notification module parameter is SAS only (IR
; 14285).
; 
; 164   5/14/14 4:29p Bgrove
; IR 14200 - Removed the broken max_xfer_size parameter.    The Linux
; driver has an atto_max_sectors parameter that preforms a similar
; function, though the limit in bytes depends on the sector size of the
; device.
; 
; 163   4/01/14 10:34a Rcrispo
; 13007 Performance opts. Added support for req_slg_pcnt,
; per_cpu_msix_cnt, eq_delay.
; 
; 162   3/26/14 4:30p Bgrove
; Disable software RAID for 12G VMware driver
; 
; 161   3/20/14 4:37p Jseba
; Fix disable_device_scan declaration (thanks Bradley)
; 
; 160   2/27/14 11:30a Jseba
; Added disable_device_scan for 12GB
; 
; 159   2/18/14 10:13a Pcullen
; atto_log_state is only available when USE_ATTO_LOG is defined.
; 
; 158   2/18/14 9:55a Pcullen
; Linux MP modifications from NetApp & HP certification testing.
; 
; 157   2/18/14 8:51a Pcullen
; Use 64 bit DMA mask for dynamic allocation, but 32 bit for coherent.
; Added force_low_dma module parameter to override 64 bit mask back to 32
; bit for odd memory configurations. (IR 9893)
; 
; 156   2/17/14 1:07p Bgrove
; Conditionally enable IODM for VMware
; 
; 155   2/12/14 2:09p Bgrove
; Fixes for IODM support in VMWare 5.5
; 
; 154   2/06/14 4:23p Bgrove
; VMware 5.5 support, including multiqueue and IODM
; 
; 153   1/15/14 1:53p Jseba
; Fixed for older kernels; fix atto_show_info
; 
; 152   12/19/13 10:50a Jseba
; Enable t10_dif for ESAS4HBA (IR 9801)
; 
; 151   12/02/13 4:08p Jseba
; Fix return values from atto_show_info and atto_write_info
; 
; 150   11/07/13 10:02a Bgrove
; VSA IOCTL Support
; 
; 149   10/24/13 8:59a Pcullen
; Change port_retry_delay default value to 0 which allows the NVRAM
; setting to take affect instead. 
; 
; 148   9/25/13 11:27a Pcullen
; Added 12Gb ESASHBA4 Support
; 
; 147   8/21/13 2:12p Bgrove
; Fix read operations in 3.10+ kernels
; 
; 146   7/31/13 11:38a Jseba
; Update atto_show_info
; 
; 145   7/09/13 4:28p Bgrove
; Use new proc api for compatability with 3.10 kernel
; 
; 144   5/21/13 10:55a Pcullen
; Add _scst_connect functions to kernel space for celerity and fastframe
; families.
; 
; 143   5/17/13 9:36a Pcullen
; IR 9097: Indicate to scsi mid layer that we are handling the command if
; the timer expires.
; 
; 142   4/04/13 10:14a Pcullen
; IR 9169: Linux 3.8 compile issue with __devinit and __devexit
; 
; 141   2/25/13 11:23a Pcullen
; PM Fixes: Start/stop worker thread on suspend/resume; Clear
; atto_thread[index] when worker thread exits; init max_e_q properly;
; module parameter interrupt_mode now always available.
; 
; 140   1/18/13 9:15a Pcullen
; Compile the new SAS transport code for ESASHBA3.
; 
; 139   1/17/13 3:23p Pcullen
; IR 8307: Change order of devices in driver proc file.
; 
; 138   1/17/13 10:40a Jseba
; Added support for custom stacks
; 
; 137   1/03/13 3:19p Jseba
; Disable clustering for FastFrame; pass CPU number to OsStartCommand
; 
; 136   12/21/12 9:02a Pcullen
; Fix declaration of host so it's only declared when needed.
; 
; 135   12/14/12 4:30p Pcullen
; Fix compile issue for esas2hba - need host variable for rports.
; 
; 134   12/06/12 10:27a Pcullen
; Added declaration of port_retry_delay; Disable multipathing for certain
; Autodesk/Xyratex arrays.
; 
; 133   11/16/12 1:48p Pcullen
; For vmware drivers, don't set quick_init=1 as the port db may not be
; sorted when control returns to the kernel and that can mess up virtual
; ports.
; 
; 132   11/05/12 4:00p Pcullen
; IR 8704: kernel panic with certain driver params. Do not call
; LinuxScsiDone until after the done field is set.
; 
; 131   9/25/12 2:41p Pcullen
; Enable FS API for Celerity16 and make fs api code respect
; OSFAMILY_SUPPORT_FS_API
; 
; 130   9/14/12 9:15a Pcullen
; Added mp_check_block param to control whether the check/block state is
; used in discovery/activation.
; 
; 129   8/15/12 1:06p Pcullen
; Added log stmt to timeout fn so we know when MP commands timeout.
; 
; 128   7/26/12 9:56a Pcullen
; IR 8473 - added mp_disable_failback param.
; 
; 127   5/25/12 10:41a Jseba
; Moved the pci_device_id table to ospciids.h
; 
; 126   5/21/12 1:08p Pcullen
; IR 8282 - atfcnvr failure: kernel 2.6.35 should use the new ioctl
; structure.
; 
; 125   5/17/12 10:54a Pcullen
; Added rport_timeout param for dev_loss_tmo on fc rports; IR 8281 -
; don't call pci_enable_device_mem, it's redundant and only adds to the
; enable_cnt in the pci_dev.
; 
; 124   5/04/12 1:06p Pcullen
; Added cpu_affinity module param to control binding cpu to the MSI-X
; vector.
; 
; 123   5/02/12 4:38p Bgrove
; Register as a scsi host, even when device is not an initator.
; 
; 122   4/27/12 1:22p Pcullen
; ClryFC16 support; MSI-X support; Fix compilation when TARGETMODE is not
; defined.
; 
; 121   3/16/12 2:44p Pcullen
; sas transport compatibility fix for "new" transport layer in ESASHBA2
; to compile with older versions.
; 
; 120   3/06/12 5:35p Jseba
; target_link_delay_mask applies to all target mode drivers; streamlined
; error handling
; 
; 119   3/05/12 4:41p Jseba
; Remove speed_override for FastFrame
; 
; 118   2/15/12 3:01p Pcullen
; Fixed compile warning on pre 2.6.25 kernels; updated to newer SAS
; transport layer api; removed vn2vn_port_mode parameter.
; 
; 117   1/31/12 1:29p Bgrove
; Added macro for DMA_BIT_MASK for pre-2.6.24 kernels.
; Conditionalized code that uses pci_enable_device_mem for pre-2.6.25
; kernels.
; 
; 116   1/24/12 9:13a Jseba
; Added call to pci_enable_device_mem
; 
; 115   1/09/12 5:26p Jseba
; Enable t10_dif for ESAS3HBA
; 
; 114   1/09/12 4:22p Pcullen
; IR7845	Kernel Panic in CentOS 5.3
; IR7864	Need to be able to report enclosure IDs and slot information in
; SAS transport layer.
; 
; 113   12/14/11 1:45p Jseba
; Added new 6Gb SAS and FastFrame PCI IDs
; 
; 112   12/14/11 11:31a Jseba
; SG list fixes
; 
; 111   10/26/11 3:15p Pcullen
; Minor fixes to logging commands
; 
; 110   9/27/11 3:16p Jseba
; Fix a crash that could occur if a command is started for a device that
; is being removed
; 
; 109   9/16/11 3:02p Jseba
; Added interrupt_mode
; 
; 108   7/28/11 5:02p Jseba
; Support for FastFrame transport layer, ESAS3HBA, and new ESAS2HBA
; models; fixes for ioctls on kernels 2.6.37 and newer; call
; scsi_scan_host() after enabling change notification; fix a build
; warning on SLES 11 SP1
; 
; 107   7/22/11 2:11p Pcullen
; Fix for Fedora 15 compile issue.
; 
; 106   6/20/11 1:57p Pcullen
; Fix for IR7505 and associated kernel panics during driver removal.
; Also, instrumented Linux code with attolog statements.
; 
; 105   4/22/11 8:52a Pcullen
; Changes for ESXi 5 RC celerity8fc driver; includes fix for IR7577.
; 
; 104   3/10/11 3:29p Pcullen
; Support for IRs 7183, 7443 - ability to set initator, target and target
; delay on a per-port basis.
; 
; 103   3/02/11 3:07p Jseba
; Support speed_override for FastFrame
; 
; 102   2/14/11 2:38p Pcullen
; Add support for NPIV in Celerity8 driver.
; 
; 101   1/12/11 8:54a Jseba
; Fixes for newer kernels
; 
; 100   1/06/11 10:37a Jseba
; Updated copyright information
; 
; 99    12/21/10 4:13p Jseba
; Change default cmd_per_lun based on product type; change default
; queuing type from ordered to simple
; 
; 98    11/17/10 2:58p Jseba
; Fixes for Red Hat 6; add FastFrame NIC support and max_logins and
; target mode parameters
; 
; 97    10/29/10 11:20a Mseier
; Added some #ifdefs to avoid cross-product contamination of new ATA
; IOCTL code.
; 
; 96    10/25/10 4:41p Mseier
; IR 6836:  Added handling for more ATA IOCTLs used in hdparm; offloaded
; ATA IOCTL processing to osata.c.
; 
; 95    10/25/10 3:24p Pcullen
; Fix for IR7342: clear scan state table when use_transport_layer=0; same
; as when transport layer is compiled out.
; 
; 94    10/14/10 11:08a Pcullen
; Fixed compile issue with mp driver
; 
; 93    9/28/10 4:09p Jseba
; Fixed speed_override description; misc. minor format cleanups; fixed
; atto_device_reset() behavior; added atto_target_reset(); added
; old_device_reset parameter to revert to previous reset behavior
; 
; 92    9/08/10 9:37a Jseba
; Added FastFrame support
; 
; 91    7/09/10 10:14a Pcullen
; Added t10_dif module parameter to enable T10-DIF support
; 
; 90    7/01/10 11:04a Pcullen
; Fix for use_transport_layer=0; in that case scsi_scan_host will get
; called even when the transport layer is compiled, but turned off.
; 
; 89    6/18/10 10:32a Pcullen
; Added hw node to sysfs
; 
; 88    6/15/10 10:05a Mseier
; Updated ESASRAID VDA events to use new async event naming scheme.
; 
; 87    6/01/10 12:54p Mseier
; Added support for slot binding and bad block reporting
; 
; 86    5/10/10 1:30p Pcullen
; Fixed conditional compilation on transport usage so that older (RH4)
; kernel don't attempt to use it.
; 
; 85    4/22/10 8:16a Pcullen
; Implementation of Linux SAS Transport
; 
; 84    4/15/10 1:26p Mseier
; Removed R348.
; 
; 83    4/14/10 1:31p Mseier
; Updates for ESASRAID2 project.
; 
; 82    3/23/10 11:47a Jseba
; Fixes for 2.6.33
; 
; 81    3/01/10 2:35p Pcullen
; Updates for Celerity 8Gb Multipathing: Use LinuxScsiDone for completing
; all commands; added support for MP ioctl and async messages
; 
; 80    12/17/09 3:28p Jseba
; Define use_transport_layer only if ATTO_USE_TRANSPORT is also defined
; 
; 79    12/17/09 2:23p Pcullen
; When calling OsAllowChangeNotification, pass third param to indicate
; whether to clear ScanState; when FC rports or SAS ports are enabled,
; ScanState is not cleared, otherwise it is.
; 
; 78    11/24/09 1:49p Pcullen
; Fixed compile issues for RPORTS
; 
; 77    11/20/09 4:19p Pcullen
; Rudimentary Linux SAS Transport implementation
; 
; 76    10/30/09 9:27a Pcullen
; VMware 4 porting
; Added inclusion of oscommon.h for VMware 4.
; Include VMkernel SCSI header for VMware 4.
; Removed legacy ESX 3.5 changes - VMKERNEL_MODULE.
; Added code to create char device for ioctls during module init.
; Retained usage of VMK_FLAGS_USE_LUNRESET for VMware 4 using VMKLNX
; flag.
; 
; 75    10/15/09 3:25p Jseba
; Removed more ATTO-specific data types
; 
; 74    10/12/09 3:32p Jseba
; Added io_time_out parameter
; 
; 73    10/06/09 2:40p Jseba
; Added bind_to_phy support (3gb SAS only)
; 
; 72    10/05/09 5:02p Jseba
; Removed all ATTO-specific data types; use OsAccessNvram instead of an
; ioctl for NVRAM access
; 
; 71    8/06/09 1:29p Pcullen
; Provide more complete implementation of Linux FC Transport, including
; remote port api (rports)
; 
; 70    7/31/09 3:31p Jseba
; Get rid of num_ioreq and low_memory_mode parameters
; 
; 69    7/22/09 2:52p Jseba
; Change default event_log_mask to 1 so we always log critical events;
; make sure host->this_id is always outside the range of valid IDs
; 
; 68    7/21/09 3:07p Jseba
; Reduce default cmd_per_lun to 7; clean up the module params definitions
; and add disable_wide_ports and num_targets parameters for ESASHBA;
; unlock host during task management handling (not yet enabled)
; 
; 67    7/01/09 2:55p Jseba
; Add ESAS2HBA support for initiator_phy_mask and target_phy_mask
; 
; 66    5/26/09 11:45a Jseba
; Fix scsi_execute_req call for >= 2.6.29
; 
; 65    5/11/09 2:12p Jseba
; Add num_targets for ESAS2HBA and fix some debug print statements
; 
; 64    4/20/09 11:39a Jseba
; Fixed compilation error with older kernels in code that modifies queue
; types
; 
; 63    4/10/09 7:40a Pcullen
; Removed ATTONode for VMware 
; 
; 62    2/06/09 2:10p Pcullen
; make the HDIO_DRIVE_CMD/HDIO_DRIVE_TASK handling only for a 2.6 kernel
; 
; 61    2/05/09 12:34p Pcullen
; Initial checkin from VMware 3.5 porting
; 
; 60    11/17/08 11:03a Jseba
; Clean up properly if adapter initialization fails
; 
; 59    11/05/08 2:45p Jseba
; OsAbortTarget is now OsAbortCommand; cleaned up some of the module
; paramter descriptions and added multimode_ports for ESAS2HBA
; 
; 58    10/20/08 10:31a Jseba
; Update 2.4 Vendor/Device ID tables
; 
; 57    10/07/08 4:50p Jseba
; ESAS2HBA support
; 
; 56    9/23/08 9:12a Jseba
; Add ESASHBA read-only device type
; 
; 55    9/17/08 2:37p Jseba
; Add addr_override parameter
; 
; 54    8/11/08 10:27a Jseba
; Another power management fix
; 
; 53    8/05/08 3:02p Jseba
; Fix power management for older kernels (eg. RH4)
; 
; 52    7/14/08 3:23p Jseba
; Add power management code; improve rescan code
; 
; 51    6/03/08 9:30a Jseba
; Remove atto_bios_param entirely; fix 2.4 builds
; 
; 50    6/02/08 11:11a Jseba
; Added R30F
; 
; 49    5/22/08 2:34p Jseba
; Use module_init/exit; change return value of attocfg register function
; 
; 48    4/30/08 5:04p Jseba
; Fix return value for unimplemented IOCTLs
; 
; 47    4/24/08 11:38a Jseba
; Fixes for kernel 2.6.25; embed version information with MODULE_VERSION;
; removed attcfg_read_version
; 
; 46    4/17/08 4:52p Jseba
; CELERITY8FC is now CELERITY8FC
; 
; 45    4/04/08 11:31a Jseba
; Fix atto_bios_param and remove it from 2.6 builds
; 
; 44    3/19/08 1:28p Jseba
; Oops, fix atto_bios_param for 32-bit builds
; 
; 43    3/19/08 1:21p Jseba
; Add support for H30F; add atto_bios_param for 2.6; enable
; change_notification by default
; 
; 42    3/05/08 1:53p Jseba
; CELERITYFC8 changes; add check for Celerity "dummy" devices
; 
; 41    2/19/08 9:44a Jseba
; For ESASHBA, if an ATA ioctl (HDIO_DRIVE_CMD or HDIO_DRIVE_TASK) comes
; in, wrap it in an ATA PASS-THROUGH 12 SCSI command and send it on down.
; 
; 40    11/27/07 5:06p Jseba
; Remove remove atto_allow_rescans and call OsAllowChangeNotification
; instead
; 
; 39    11/06/07 12:59p Jseba
; Rework rescan code (change_notification=1) to fix problems with older
; kernels; fix bug when starting commands without sg lists
; 
; 38    9/21/07 3:12p Jseba
; Cleaned up print statements
; 
; 37    9/13/07 11:15a Jseba
; Add support for Celerity parameters fab_alternate_exchanges, num_xcb,
; num_scb
; 
; 36    9/04/07 2:38p Jseba
; Fix 2.4 builds
; 
; 35    9/04/07 1:28p Jseba
; Fix device IDs for ESASHBA
; 
; 34    8/27/07 11:10a Jseba
; Use pci_register_driver instead of pci_module_init on newer kernels
; 
; 33    8/21/07 10:42a Jseba
; Removed change_notification from 2.4 and EXPRESS2 builds
; 
; 32    8/15/07 2:52p Jseba
; Use OsLikely/Unlikely; enable FS interface for ESASHBA; set command
; success before calling OsStartCommand
; 
; 31    8/06/07 3:24p Jseba
; Support for ESASHBA driver; enable use_clustering; changed interface to
; OsStartCommand to use command and SGL structure offets (see
; LinuxExchangeOffsets in osutil.c);  map SGLs ahead of calling
; OsStartCommand; added slave_ and change_queue functions, although they
; are not yet implemented.
; 
; 30    6/04/07 3:20p Jseba
; Changed device ID for read-only SCSI adapters
; 
; 29    4/30/07 4:11p Jseba
; Make atto_detect apply only to 2.4 builds
; 
; 28    4/27/07 4:56p Jseba
; Added "low_memory_mode" parameter to automatically reduce memory usage;
; check error code from pci_module_init; add debug statements for abort
; and reset completions
; 
; 27    11/14/06 2:31p Jseba
; Add "fs" handlers for ESASRAID FS_API
; 
; 26    11/08/06 11:38a Jseba
; Move VDA event notification socket code to attocfg
; 
; 25    10/31/06 5:03p Jseba
; Added speed_override and topology_override for Celerity
; 
; 24    10/09/06 9:47a Jseba
; Added OsGetNvramSize instead of hard-coded NVRAM size; added ESASRAID
; VDA node handler; fixed init error handling for 2.4 kernel
; 
; 23    9/29/06 3:57p Jseba
; Removed unused sgl_page_size parameter from EXPRESS2;  fixed typo in
; num_ioreq default
; 
; 22    9/27/06 9:43a Jseba
; Don't use cmd->data_cmnd; fix host->max_id and host->max_lun; fix some
; debug statements
; 
; 21    9/22/06 5:23p Jseba
; Increase default can_queue, cmd_per_lun, num_sg_lists, and num_ioreq
; settings; use new OsStartCommand return values
; 
; 20    9/20/06 10:24a Jseba
; Change max_sectors to atto_max_sectors to avoid object name collision
; with 2.4 kernel; support for EXPRESS2; OsStartCommand no longer returns
; a status - failed commands will be completed via LinuxCompleteRequest
; 
; 19    8/28/06 11:19a Jseba
; Support for ESASRAID driver
; 
; 18    7/24/06 4:14p Jseba
; Scrap GlobalFlags; expand module parameters (cmd_per_lun, max_sectors,
; etc) and add description strings; misc. cleanups
; 
; 17    1/03/06 10:27a Jseba
; Remove deprecated "intermodule" functions, and just export the
; connection function; move sysfs support to attocfg module; various
; cleanups
; 
; 16    8/04/05 11:53a Jseba
; Add support for 16-byte CDBs so we work with large (>2TB) devices.
; 
; 15    3/21/05 10:30a Jseba
; Use new MODULE_PARAM_INT and MODULE_PARAM_LONG; disable sysfs functions
; for newer kernels, where such functions are GPL only
; 
; 14    12/28/04 9:52a Jseba
; Improved PCI initialization;  fixed some bugs with cleanup after driver
; fails to load
; 
; 13    12/09/04 12:29p Jseba
; Fix debug statements for 64 bit
; 
; 12    11/19/04 11:25a Jseba
; 64-bit support; sysfs support
; 
; 11    10/15/04 2:24p Jseba
; Skip initialization of dummy channels.
; 
; 10    6/29/04 3:31p Jseba
; Minor cleanups, support for 4gig
; 
; 9     6/21/04 4:47p Jseba
; Oops... set driver_template.module = THIS_MODULE before registering the
; module, otherwise our usage count will not get handled correctly.
; 
; 8     6/16/04 11:42a Jseba
; Oops - remove the proc entry before unregistering the driver
; 
; 7     6/07/04 1:54p Jseba
; Fixes for RedHat 2.1
; 
; 6     3/31/04 3:54p Jseba
; Initial support for 2.6 kernel
; 
; 5     2/04/04 9:41a Jseba
; Check subsystem vendor ID; increase max LUN; save host IRQ
; 
; 4     12/09/03 9:52a Jseba
; Rename to celerityfc
; 
; 3     11/18/03 10:25a Jseba
; Fix device discovery; return 1 (instead of DID_BUS_BUSY) if we are
; unable to start a command.
; 
; 2     11/03/03 10:49a Jseba
; Support for DX2+ chips
; 
; 1     10/24/03 10:38a Jseba
; Initial entry
; 
; 
; THIS PROGRAM AND THE INFORMATION CONTAINED HEREIN IS THE PROPERTY OF
; ATTO TECHNOLOGY, INC. AND SHALL NOT BE REPRODUCED, COPIED, OR USED IN
; WHOLE OR IN PART OTHER THAN AS PROVIDED FOR IN THE LICENSE AGREEMENT
; PURSUANT TO WHICH IT WAS FURNISHED.
;
; COPYRIGHT (c) ATTO TECHNOLOGY, INC. 10/24/03 - $JustDate:  6/10/16 $
; ALL RIGHTS RESERVED.
;
;***************************************************************************/

#include "oscommon.h"
#include "oswrap.h"

#ifdef ESASHBA
#include "osata.h"
#endif

#ifdef ATTO_USE_TRANSPORT
#if defined(CELERITYFC) || defined(FASTFRAME)
#include "ostransportfc.h"
#else
#include "ostransportsas.h"
#endif
#endif

#ifdef __VMKLNX__
#ifdef IODM
#include <vmklinux_9/vmklinux_iodm.h>
#endif
#ifdef ATTO_VMK_50
#include <vmklinux_scsi.h>
#else
#include <vmklinux26/vmklinux26_scsi.h>
#endif
#endif


#if defined (ATTO_RPORTS) || defined (ATTO_SAS_PORTS)
extern void LinuxScheduleWork (unsigned int index);
#endif

unsigned int atto_target_id (Scsi_Cmnd *cmd);

extern int global_pci_dev_offset;

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,4,0)
#error !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
#error !!! This driver only works on version 2.4, 2.6, or 3.0 of the Linux kernel !!!
#error !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
#endif

MODULE_DESCRIPTION (ATTO_DRVR_NAME ": " ATTO_LONGNAME " driver");
MODULE_AUTHOR ("ATTO Technology");

#ifdef ATTO_VMK_50
MODULE_LICENSE ("proprietary");
#else
#ifndef __VMKLNX__ /* VMware 4.1 doesn't like proprietary */
#ifdef MODULE_LICENSE
MODULE_LICENSE ("Proprietary");
#endif /* MODULE_LICENSE */
#endif /* !__VMKLNX__ */
#endif /* !ATTO_VMK_50 */

#ifdef MODULE_VERSION
MODULE_VERSION (VER_FILEVERSION_STR);
#endif

/* Build family specific symbol names.  Do not use these first two directly! */
#define ATTO_CONCAT(prefix, name)       prefix ## _ ## name
#define ATTO_EVAL_NAME(prefix, name)    ATTO_CONCAT(prefix, name)

/* e.g. ATTO_DRVR_SYM(init) -> celerityfc_init */
#define ATTO_DRVR_SYM(name)             ATTO_EVAL_NAME(ATTO_DRVR_RAWNAME, name)


/* Export the target mode entry point function */

#ifdef TARGET_MODE
#if defined (CELERITY16FC)
EXPORT_SYMBOL (celerity16fc_target_connect);
EXPORT_SYMBOL (celerity16fc_scst_connect);
#elif defined (CELERITY8FC)
EXPORT_SYMBOL (celerity8fc_target_connect);
EXPORT_SYMBOL (celerity8fc_scst_connect);
#elif defined (CELERITYFC)
EXPORT_SYMBOL (celerityfc_target_connect);
EXPORT_SYMBOL (celerityfc_scst_connect);
#elif defined (ESAS3HBA)
EXPORT_SYMBOL (esas3hba_target_connect);
#elif defined (ESAS2HBA)
EXPORT_SYMBOL (esas2hba_target_connect);
#elif defined (ESAS4HBA)
EXPORT_SYMBOL (esas4hba_target_connect);
#elif defined (FASTFRAME)
EXPORT_SYMBOL (fastframe_target_connect);
EXPORT_SYMBOL (fastframe_scst_connect);
#endif
#endif

#ifdef FASTFRAME
EXPORT_SYMBOL (fastframe_network_connect);
#endif

/* Global definitions */

int found_adapters = 0;

/* Host device attributes */
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,12)
ATTO_DEV_ATTR_T *atto_attrs[];
#endif

/* Scsi_Host_Template defined in scsi/hosts.h (struct SHT) */

static Scsi_Host_Template driver_template =
{
/*  next:                    NULL,                  */
/*  module:                  NULL,                  */
/*  proc_dir:                NULL,                  */
    module:                  THIS_MODULE,
#if  LINUX_VERSION_CODE < KERNEL_VERSION(3,10,0)
    proc_info:               atto_proc_info,
#else
    show_info:               atto_show_info,
    write_info:              atto_write_info,
#endif
    name:                    ATTO_LONGNAME,
    release:                 atto_release,
    info:                    atto_info,
    ioctl:                   atto_ioctl,
/*  command:                 NULL,                  */
    queuecommand:            atto_queuecommand,
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,27)
    eh_timed_out:            atto_eh_timed_out,
#endif
/*  eh_strategy_handler:     NULL,                  */
    eh_abort_handler:        atto_eh_abort,

#ifndef _MP_
    eh_device_reset_handler: atto_device_reset,
#endif  /* !_MP_ */

    eh_bus_reset_handler:    atto_bus_reset,
    eh_host_reset_handler:   atto_host_reset,
    can_queue:               512,
    this_id:                 -1,
    sg_tablesize:            SG_ALL,
    cmd_per_lun:             ATTO_DEFAULT_CMD_PER_LUN,
    present:                 0,
    unchecked_isa_dma:       0,
#ifdef FASTFRAME
    use_clustering:          DISABLE_CLUSTERING,
#else
    use_clustering:          ENABLE_CLUSTERING,
#endif
    emulated:                0,
    proc_name:               ATTO_DRVR_NAME,
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,12)
    shost_attrs:             atto_attrs,
#endif
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,5,0)
    detect:                  atto_detect,
    use_new_eh_code:         0,
#else
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,11)
    slave_configure:         atto_slave_configure,
    slave_alloc:             atto_slave_alloc,
    slave_destroy:           atto_slave_destroy,
    change_queue_depth:      atto_change_queue_depth,
#if LINUX_VERSION_CODE < KERNEL_VERSION(3,19,0)
    change_queue_type:       atto_change_queue_type,
#endif
#endif
    max_sectors:             0xFFFF,
#endif
};

#ifdef ATTO_USE_NPIV
Scsi_Host_Template atto_vport_template =
{
    module:                  THIS_MODULE,
    proc_info:               atto_proc_info,
    name:                    ATTO_LONGNAME,
    release:                 atto_release,
    info:                    atto_info,
    ioctl:                   atto_ioctl,
    queuecommand:            atto_queuecommand,
    eh_abort_handler:        atto_eh_abort,
    eh_device_reset_handler: atto_device_reset,
    eh_bus_reset_handler:    atto_bus_reset,
    eh_host_reset_handler:   atto_host_reset,
    can_queue:               512,
    this_id:                 -1,
    sg_tablesize:            SG_ALL,
    cmd_per_lun:             7,
    present:                 0,
    unchecked_isa_dma:       0,
#ifdef FASTFRAME
    use_clustering:          DISABLE_CLUSTERING,
#else
    use_clustering:          ENABLE_CLUSTERING,
#endif
    emulated:                0,
    proc_name:               ATTO_DRVR_NAME,
    slave_configure:         atto_slave_configure,
    slave_alloc:             atto_slave_alloc,
    slave_destroy:           atto_slave_destroy,
    change_queue_depth:      atto_change_queue_depth,
    change_queue_type:       atto_change_queue_type,
    max_sectors:             0xFFFF,
};
#endif /* ATTO_USE_NPIV */
/* Module parameter definitions */

#if defined(CELERITYFC) || defined(FASTFRAME)
#if defined (_MP_)
/* quick_init always on for multipathing since device      */
/* discovery is delayed until the paths can be configured. */
unsigned int       quick_init = 1;
#else
unsigned int       quick_init = 0;
#endif /* _MP_ || ATTO_VMK_50 */
MODULE_PARAM_UINT (quick_init);
MODULE_PARM_DESC  (quick_init,
                   "Enable quick link initialization.  Default is 0 (off).  "
                   "WARNING: See readme.txt before using.");

unsigned int       port_retry_delay = 0;
MODULE_PARAM_UINT (port_retry_delay);
MODULE_PARM_DESC  (port_retry_delay,
                   "Amount of time (in milliseconds) to wait for a port"
                   "to log back in after being lost. Default is 0 ms, which."
                   "allows the NVRAM Port Down Timeout value to be used.");

unsigned int       max_logins = 256;
MODULE_PARAM_UINT (max_logins);
MODULE_PARM_DESC  (max_logins,
                   "Defines the maximum number of ports that can be logged "
                   "in at once.  Default 256.");

#endif
#ifdef CELERITYFC

#if defined( IFF_CELERITY8FC )
unsigned int       force_low_dma = 0;
MODULE_PARAM_UINT (force_low_dma);
MODULE_PARM_DESC  (force_low_dma,
                   "Force all DMA mappings to below 4GB.  This may severely "
                   "impact performance and should only be used on systems "
                   "with > 512GB of physical RAM or unusual physical "
                   "memory layouts. Default is 0.");
#endif /* IFF_CELERITY8FC */

int                speed_override = -1;
MODULE_PARAM_SINT (speed_override);
MODULE_PARM_DESC  (speed_override,
                   "Override the NVRAM link speed setting.  0 for auto speed "
#if defined (CELERITY16FC)
                   "negotiation, 4 for 4Gb, 8 for 8Gb, 16 for 16Gb or 32 for 32Gb.  "
#elif defined (CELERITY8FC)
                   "negotiation, 2 for 2Gb, 4 for 4Gb, or 8 for 8Gb.  "
#else
                   "negotiation, 1 for 1Gb, 2 for 2Gb, or 4 for 4Gb.  "
#endif
                   "Invalid values will result in the use of the NVRAM "
                   "setting.  Default is -1 (use NVRAM setting).");

#if defined (CELERITY16FC)

#if defined (ATTO_MSIX_SUPPORT)
unsigned int       max_e_q = 8; /* Default to 8 MSI-X vectors */
#elif defined (ATTO_MSI_SUPPORT)
unsigned int       max_e_q = 1; /* Linux only support 1 MSI vector */
#else
unsigned int       max_e_q = 1;
#endif
MODULE_PARAM_UINT (max_e_q);
MODULE_PARM_DESC  (max_e_q,
                   "Maximum number of event queues.");

unsigned int       num_w_q = 4;
MODULE_PARAM_UINT (num_w_q);
MODULE_PARM_DESC  (num_w_q,
                   "Number of work queues. Default 4.");

unsigned int       num_w_q_pgs = 1;
MODULE_PARAM_UINT (num_w_q_pgs);
MODULE_PARM_DESC  (num_w_q_pgs,
                   "Number of pages per work queue. Default 1 (64 entries)");

unsigned int       num_r_q = 2;
MODULE_PARAM_UINT (num_r_q);
MODULE_PARM_DESC  (num_r_q,
                   "Number of receive queue pairs. Default 2.");

unsigned int       num_r_q_pgs = 1;
MODULE_PARAM_UINT (num_r_q_pgs);
MODULE_PARM_DESC  (num_r_q_pgs,
                   "Number of pages per receive queue. Default 1 (512 entries).");

unsigned int       num_m_q_pgs = 1;
MODULE_PARAM_UINT (num_m_q_pgs);
MODULE_PARM_DESC  (num_m_q_pgs,
                   "Number of pages per mailbox queue. Default 1 (16 entries).");

unsigned int       num_r_q_2k = 32;
MODULE_PARAM_UINT (num_r_q_2k);
MODULE_PARM_DESC  (num_r_q_2k,
                   "Number of 2k receive buffers. Default 32.");

unsigned int       num_r_q_128 = 256;
MODULE_PARAM_UINT (num_r_q_128);
MODULE_PARM_DESC  (num_r_q_128,
                   "Number of 128 byte receive buffers. Default 256.");

unsigned int       num_rpi = 2048;
MODULE_PARAM_UINT (num_rpi);
MODULE_PARM_DESC  (num_rpi,
                   "Number of RPIs. Default 2048");
                   
unsigned int       reg_slg_pcnt = 30;
MODULE_PARAM_UINT (reg_slg_pcnt);
MODULE_PARM_DESC  (reg_slg_pcnt,
                   "Percentage of total exchanges with registered SGLs."
                   "Default 30.");
                   
unsigned int       per_cpu_msix_cnt = 1;
MODULE_PARAM_UINT (per_cpu_msix_cnt);
MODULE_PARM_DESC  (per_cpu_msix_cnt,
                   "Create one MSIX vector per online CPU. Default 1.");

int                eq_delay = -1;
MODULE_PARAM_SINT (eq_delay);
MODULE_PARM_DESC  (eq_delay,
                   "Maximum interrupts per second delay. Default is -1 "
                   "(use NVRAM setting).");
                   
unsigned int       login_to_targets_only = 0;
MODULE_PARAM_UINT (login_to_targets_only);
MODULE_PARM_DESC  (login_to_targets_only,
                   "For fabric topologies, only log in to devices that "
                   "register themselves as SCSI Targets with the switch. "
                   "Default: 0.");

#else
unsigned int       num_sest = 256;
MODULE_PARAM_UINT (num_sest);
MODULE_PARM_DESC  (num_sest,
                   "Number of entries in the SCSI Exchange State Table "
                   "(SEST).  One of these structures is used per active "
                   "Exchange, either Initiator or Target Mode.  Default 256.");

unsigned int       num_imq = 256;
MODULE_PARAM_UINT (num_imq);
MODULE_PARM_DESC  (num_imq,
                   "Incoming Message Queue (IMQ) entries.  These are used to "
                   "report completion of I/O requests and to notify the host "
                   "driver of certain other kinds of events detected by the "
                   "hardware.  Default 256.");

unsigned int       num_erq = 256;
MODULE_PARAM_UINT (num_erq);
MODULE_PARM_DESC  (num_erq,
                   "Exchange Request Queue (ERQ) entries.  In general, one ERQ "
                   "entry is required for each SEST entry.  Default 256.");

unsigned int       fab_alternate_exchanges = 0;
MODULE_PARAM_UINT (fab_alternate_exchanges);
MODULE_PARM_DESC  (fab_alternate_exchanges,
                   "Causes the chip to alternate between two exchanges when it "
                   "runs out of credits on a fabric.  This may improve "
                   "performance in multiple initiator/target environments.  "
                   "Default is 0 (off).");


#endif
unsigned int       private_els_timeout = 2;
MODULE_PARAM_UINT (private_els_timeout);
MODULE_PARM_DESC  (private_els_timeout,
                   "Timeout, in seconds, for ELS commands when on a private "
                   "loop.  Default 2.");

unsigned int       port_retry_count = 0;
MODULE_PARAM_UINT (port_retry_count);
MODULE_PARM_DESC  (port_retry_count,
                   "Maximum number of retries allowed for a port which is "
                   "logged out.  Default 0 (use NVRAM setting).");

int                topology_override = -1;
MODULE_PARAM_SINT (topology_override);
MODULE_PARM_DESC  (topology_override,
                   "Override the NVRAM topology setting.  0 for loop, 1 for "
                   "PTP, 2 for loop preferred, 3 for PTP preferred.  Invalid "
                   "values will result in the use of the NVRAM setting.  "
                   "Default is -1 (use NVRAM setting).");

#endif

#ifdef TARGET_MODE
unsigned int       target_mode = 0;
MODULE_PARAM_UINT (target_mode);
MODULE_PARM_DESC  (target_mode,
                   "Enable target mode function.  Default is 0 (off).");

unsigned int       target_mode_mask = 0x00000000;
MODULE_PARAM_UINT (target_mode_mask);
MODULE_PARM_DESC  (target_mode_mask,
                   "Enable target mode on a per-port basis. Each bit in the mask represents a physical port. Default is 0x00000000 (all off).");

#if defined (CELERITYFC) || defined (FASTFRAME)
unsigned int       initiator_mode = 1;
MODULE_PARAM_UINT (initiator_mode);
MODULE_PARM_DESC  (initiator_mode,
                   "Enable initiator mode function.  Default is 1 (on).");

unsigned int       initiator_mode_mask = 0xffffffff;
MODULE_PARAM_UINT (initiator_mode_mask);
MODULE_PARM_DESC  (initiator_mode_mask,
                   "Enable initiator mode on a per-port basis. Each bit in the mask represents a physical port. Default is 0xffffffff (all on).");

unsigned int       target_mode_link_delay = 0;
MODULE_PARAM_UINT (target_mode_link_delay);
MODULE_PARM_DESC  (target_mode_link_delay,
                   "Delay link initialization until a target mode driver (TMD) "
                   "connects to the HBA driver.  Default is 0 (do not delay).");

unsigned int       target_link_delay_mask = 0x00000000;
MODULE_PARAM_UINT (target_link_delay_mask);
MODULE_PARM_DESC  (target_link_delay_mask,
                   "Enable target mode link delay on a per-port basis. Each bit in the mask represents a physical port. Default is 0x00000000 (all off).");

unsigned int       num_xcb = 512;
MODULE_PARAM_UINT (num_xcb);
MODULE_PARM_DESC  (num_xcb,
                   "Number of Exchange Control Blocks (XCBs) available for "
                   "Target Mode requests.  Each request requires one XCB.  "
                   "Incoming commands above the set limit are dropped.  This "
                   "setting is only valid when Target Mode is enabled.  "
                   "Default 512.");

unsigned int       num_scb = 1024;
MODULE_PARAM_UINT (num_scb);
MODULE_PARM_DESC  (num_scb,
                   "Number of Sequence Control Blocks (SCBs) available for "
                   "Target Mode requests.  This setting is only valid when "
                   "Target Mode is enabled.  Default 1024.");

#else /* ESAS2HBA, ESAS3HBA, ESAS4HBA */
unsigned int       multimode_ports = 0;
MODULE_PARAM_UINT (multimode_ports);
MODULE_PARM_DESC  (multimode_ports,
                   "Enable initiator mode function if target_mode is enabled.  "
                   "Default is 0 (off).");
#if defined (ESAS4HBA)
unsigned int       initiator_phy_mask = 0xffff;
MODULE_PARAM_UINT (initiator_phy_mask);
MODULE_PARM_DESC  (initiator_phy_mask,
                   "Specifies a 16-bit mask to enable or disable PHYs as "
                   "initiators.  Bit 0 corresponds to PHY 0.  Default is "
                   "0xffff (all PHYs are active initiators).");

unsigned int       target_phy_mask = 0xffff;
MODULE_PARAM_UINT (target_phy_mask);
MODULE_PARM_DESC  (target_phy_mask,
                   "Specifies a 16-bit mask to enable or disable PHYs as "
                   "targets.  Bit 0 corresponds to PHY 0.  target_phy_mask is "
                   "ignored if target_mode is disabled.  Any bits set in "
                   "target_phy_mask will be cleared in initiator_phy_mask when "
                   "target mode is enabled, unless multimode_ports is also "
                   "enabled.  Default is 0xffff (all PHYs are active targets).");
#else /* ESAS2HBA || ESAS3HBA */
unsigned int       initiator_phy_mask = 0xff;
MODULE_PARAM_UINT (initiator_phy_mask);
MODULE_PARM_DESC  (initiator_phy_mask,
                   "Specifies an 8-bit mask to enable or disable PHYs as "
                   "initiators.  Bit 0 corresponds to PHY 0.  Default is "
                   "0xff (all PHYs are active initiators).");

unsigned int       target_phy_mask = 0xff;
MODULE_PARAM_UINT (target_phy_mask);
MODULE_PARM_DESC  (target_phy_mask,
                   "Specifies an 8-bit mask to enable or disable PHYs as "
                   "targets.  Bit 0 corresponds to PHY 0.  target_phy_mask is "
                   "ignored if target_mode is disabled.  Any bits set in "
                   "target_phy_mask will be cleared in initiator_phy_mask when "
                   "target mode is enabled, unless multimode_ports is also "
                   "enabled.  Default is 0xff (all PHYs are active targets).");
#endif /* ESAS2HBA || ESAS3HBA */

unsigned int       num_tgt_req = 1024;
MODULE_PARAM_UINT (num_tgt_req);
MODULE_PARM_DESC  (num_tgt_req,
                   "Number of Target Mode requests.  This setting is only "
                   "valid when Target Mode is enabled.  Default 1024.");
#endif
#endif

unsigned int       sgl_page_size = ATTO_DEFAULT_SGL_PAGE_SIZE;
MODULE_PARAM_UINT (sgl_page_size);
MODULE_PARM_DESC  (sgl_page_size,
                   "Scatter/Gather List (SGL) Page Size in number of S/G "
                   "entries.  If your application is doing a lot of very large "
                   "transfers, you may want to increase the SGL page size.  "
                   "Default "DEFINED_NUM_TO_STR (ATTO_DEFAULT_SGL_PAGE_SIZE)".");

#ifdef ESASHBA
unsigned int       num_targets = 512;
MODULE_PARAM_UINT (num_targets);
MODULE_PARM_DESC  (num_targets,
                   "Maximum number of target devices.  Default 512.");

ATTO_DEV_ATTR_UINT(sas_dev_order, 0,
                   "Order of discovered devices shown in the driver proc file."
                   "  0 = the order in the internal target database. 1 = the "
                   "order devices were reported to the kernel SCSI layer.  "
                   "Default is 0.");
ATTO_DEV_ATTR_SHOW_DEC(sas_dev_order);
ATTO_DEV_ATTR_STORE_DEC(sas_dev_order);
ATTO_DEV_ATTR_RW(sas_dev_order);

#if defined (ESAS2HBA) || defined (ESAS4HBA)
unsigned int       zero_eecc = 0;
MODULE_PARAM_UINT (zero_eecc);

#if defined (ESAS4HBA)
unsigned int       num_sas_addr = 2;
#define NUM_SAS_ADDR_SETTINGS "2, 4, 8, 16, default 2"
#elif defined (ESAS2HBA)
unsigned int       num_sas_addr = 1;
#define NUM_SAS_ADDR_SETTINGS "1, 2, 4, 8, default 1"
#endif
MODULE_PARAM_UINT (num_sas_addr);
MODULE_PARM_DESC  (num_sas_addr,
                   "Number of SAS addresses to assign to the adapter's PHYs.  "
                   "Addresses are assigned sequentially from the base address.  "
                   "Valid settings " NUM_SAS_ADDR_SETTINGS);
#else
unsigned int       disable_wide_ports = 0;
MODULE_PARAM_UINT (disable_wide_ports);
MODULE_PARM_DESC  (disable_wide_ports,
                   "Disable wide port connections to end devices.  Default 0 "
                   "(wide ports are enabled).");
#endif
#endif /* ESASHBA || ESAS4HBA */


#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0) 
unsigned int       change_notification = 1;
#if ( defined (ESAS2HBA) || defined (ESAS3HBA) || defined (ESAS4HBA) )
MODULE_PARAM_UINT (change_notification);
MODULE_PARM_DESC  (change_notification,
                   "Enable notifying the OS of the arrival and departure of "
                   "target devices, after initial discover is complete "
                   "Default is 1 (on). ");
#endif
#else
/* always off for 2.4 kernels */
unsigned int       change_notification = 0;
#endif

ATTO_DEV_ATTR_ULONG(event_log_mask, 1,
                    "Specify a bit mask of events to report to the system "
                    "log.  Default is 1 (critical events only).");
ATTO_DEV_ATTR_SHOW_HEX(event_log_mask);
ATTO_DEV_ATTR_STORE_HEX(event_log_mask);
ATTO_DEV_ATTR_RW(event_log_mask);

unsigned int       cmd_per_lun = ATTO_DEFAULT_CMD_PER_LUN;
MODULE_PARAM_UINT (cmd_per_lun);
MODULE_PARM_DESC  (cmd_per_lun,
                   "Maximum number of commands per LUN.  Default "
                   DEFINED_NUM_TO_STR (ATTO_DEFAULT_CMD_PER_LUN) ".");

unsigned int       can_queue = 512;
MODULE_PARAM_UINT (can_queue);
MODULE_PARM_DESC  (can_queue,
                   "Maximum number of commands per adapter.  Default 512.");

unsigned int       num_sg_lists = ATTO_DEFAULT_NUM_SG_LISTS;
MODULE_PARAM_UINT (num_sg_lists);
MODULE_PARM_DESC  (num_sg_lists,
                   "Number of SGL pages.  Default " 
                   DEFINED_NUM_TO_STR (ATTO_DEFAULT_NUM_SG_LISTS) ".");

unsigned int       sg_tablesize = ATTO_SG_TABLESIZE_MAX;
MODULE_PARAM_UINT (sg_tablesize);
MODULE_PARM_DESC  (sg_tablesize,
                   "Maximum number of entries in a scatter/gather table.  "
#ifdef FASTFRAME
                   "The FastFrame driver can only handle up to 254 entries.  "
                   "Default 254.");
#else
                   "Default 255, maximum " 
                   DEFINED_NUM_TO_STR (ATTO_SG_TABLESIZE_MAX) ".");
#endif

unsigned int       atto_max_sectors = 0xFFFF;
MODULE_PARAM_UINT (atto_max_sectors);
MODULE_PARM_DESC  (atto_max_sectors,
                   "Maximum number of disk sectors in a single data transfer.  "
                   "Default 65535 (largest possible setting).");

#ifdef ESAS4HBA
unsigned int       disable_device_scan = 0;
MODULE_PARAM_UINT (disable_device_scan);
MODULE_PARM_DESC  (disable_device_scan,
                   "Disable device scanning for RAID groups.  WARNING: This "
                   "will disable *all* support for ATTO PowerCenter Pro RAID "
                   "groups, which could cause data loss if drives containing "
                   "RAID data are connected to the adapter. Default is 0.");
#endif /* ESAS4HBA */

unsigned int       cmd_retry_count = 20;
MODULE_PARAM_UINT (cmd_retry_count);
MODULE_PARM_DESC  (cmd_retry_count,
                   "Maximum number of retries allowed for a command.  Default "
                   "20.");

unsigned int       io_time_out = 30;
MODULE_PARAM_UINT (io_time_out);
MODULE_PARM_DESC  (io_time_out,
                   "Time (in seconds) before an I/O command is timed out by "
                   "the driver.  Set to 0 for no timeout.  Default 30.");

#if defined (CELERITYFC) || (defined (ESASHBA) && !defined (ESAS3HBA))
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0)
char               addr_override [ATTO_PARAM_STR_LEN];
MODULE_PARAM_STR  (addr_override);
#else
/* No support for older kernels */
char               addr_override [] = "";
#endif
#endif

#if defined (ATTO_USE_TRANSPORT)
unsigned int        use_transport_layer =1;
MODULE_PARAM_UINT  (use_transport_layer);
MODULE_PARM_DESC   (use_transport_layer,
                    "Attach to the SCSI transport layer. Default 1 (enabled).");
#endif

#if defined (ATTO_RPORTS)
unsigned int       rport_timeout = 30;
MODULE_PARAM_UINT (rport_timeout);
MODULE_PARM_DESC  (rport_timeout,
                   "Time (in seconds) before an FC rport device is timed "
                   "out by the OS.  Default is 30.");

#endif /* ATTO_RPORTS */

#ifdef BIND_TO_PHY_SUPPORT
unsigned int       bind_to_phys = 0;
MODULE_PARAM_UINT (bind_to_phys);
#endif

#ifdef _MP_
unsigned int       disable_oem = 0;
MODULE_PARAM_UINT (disable_oem);
MODULE_PARM_DESC  (disable_oem,
                   "Disable OEM multipathing customization.  Default is 0 "
                   "(off).");

unsigned int       mp_config = 0;
MODULE_PARAM_UINT (mp_config);
MODULE_PARM_DESC  (mp_config,
                   "Configure multipathing override options (bitfield).  "
                   "Bit 0 turn on override when set,  "
                   "bit 1 controls the \"path\" option, "
                   "bit 2 controls the \"pathset\" option.  Default is 0 (no "
                   "override).");

unsigned int       max_luns = 1024;
MODULE_PARAM_UINT (max_luns);
MODULE_PARM_DESC  (max_luns,
                   "Configure maximum number of luns across all targets that "
                   "can be accessed with multi-path driver.  Default is 1024.");

unsigned int       mp_init_wait = 60;
MODULE_PARAM_UINT (mp_init_wait);
MODULE_PARM_DESC  (mp_init_wait,
                   "Configure the time delay (in seconds) that the driver "
                   "waits for a multi-pathing configuration to be loaded "
                   "from the ATTO Config Tool before proceeding with a "
                   "default configuration.  Default is 60 seconds.");

unsigned int       mp_disable_failback = 0;
MODULE_PARAM_UINT (mp_disable_failback);
MODULE_PARM_DESC  (mp_disable_failback,
                   "Disable failback in the multipathing driver (value 1). "
                   "When disabled, the driver will failover to "
                   "alternate/standby path; however, the driver will not "
                   "failback automatically.  The user will need to manually "
                   "switch the path back to the preferred controller."
                   "Default is 0 (failback enabled).");

unsigned int       mp_check_block = 0;
MODULE_PARAM_UINT (mp_check_block);
MODULE_PARM_DESC  (mp_check_block,
                   "Enable the discovery and activation state machine states "
                   "that check for blocks (other discoveries or activations. "
                   "Default is 0 (check block state disabled).");

unsigned long      mp_discovery_mode = 0;
MODULE_PARAM_ULONG(mp_discovery_mode);
MODULE_PARM_DESC  (mp_discovery_mode,
                   "Vendor-specific modification to MP device discovery. Default is 0.");
#endif

#ifdef ATTO_USE_TM_COMPLETIONS
#ifdef __VMKLNX__
unsigned int       use_tm_completions = 1;
#else
unsigned int       use_tm_completions = 0;
#endif /* __VMKLNX__ */
MODULE_PARAM_UINT (use_tm_completions);
MODULE_PARM_DESC  (use_tm_completions,
                   "Wait for task management commands to complete before "
#ifdef __VMKLNX__
                   "returning from handler.  Default 1 (enabled).");
#else
                   "returning from handler.  Default 0 (disabled).");
#endif
#endif /* ATTO_USE_TM_COMPLETIONS */

#if defined (ESAS3HBA) || defined (ESAS4HBA)
unsigned int       t10_dif = 0;
MODULE_PARAM_UINT (t10_dif);
MODULE_PARM_DESC  (t10_dif,
                   "Enable T10-DIF functionality.  Default is 0 (off).");
#endif /* CELERITY8FC || ESAS3HBA */

unsigned int       old_device_reset = 0;
MODULE_PARAM_UINT (old_device_reset);
MODULE_PARM_DESC  (old_device_reset,
                   "Use the old device reset method.  Default is 0 (use new "
                   "method).");

#ifdef ATTO_USE_NPIV
unsigned int       max_npiv_vports = MAX_NPIV_VPORTS_DEFAULT;
MODULE_PARAM_UINT (max_npiv_vports);
MODULE_PARM_DESC  (max_npiv_vports,
                   "Defines the maximum number of NPIV virtual ports for an adapter. Default 4; Maximum allowed 126.");

unsigned int       max_npiv_logins = MAX_NPIV_LOGINS_DEFAULT;
MODULE_PARAM_UINT (max_npiv_logins);
MODULE_PARM_DESC  (max_npiv_logins,
                   "Defines the maximum number of ports that can be logged in to an NPIV virtual port. Default 32; Maximum allowed 256.");

unsigned int       npiv_disc_wait_time = VPORT_DISC_WAIT_TIME_DEFAULT;
MODULE_PARAM_UINT (npiv_disc_wait_time);
MODULE_PARM_DESC  (npiv_disc_wait_time,
                   "Defines the time period that the driver waits for discovery to be completed after creating a virtual port.");

unsigned int       npiv_init_retries = VPORT_INIT_RETRIES_DEFAULT;
MODULE_PARAM_UINT (npiv_init_retries);
MODULE_PARM_DESC  (npiv_init_retires,
                   "Defines the number of retries to initialize a virtual port before giving up.");
#endif /* ATTO_USE_NPIV */

#ifdef USE_ATTO_LOG
#include "attolog.h"
ATTO_DEV_ATTR_ULONG(atto_log_mask, ATTO_LOG_NONE,
                    "Defines the log mask for sending ATTO driver information "
                    "to the system log. Default is 0 (none). See attolog.h "
                    "for bit mask definitions");
ATTO_DEV_ATTR_SHOW_HEX(atto_log_mask);
ATTO_DEV_ATTR_STORE_HEX(atto_log_mask);
ATTO_DEV_ATTR_RW(atto_log_mask);
unsigned long atto_log_start;
#endif /* USE_ATTO_LOG */


#ifdef SF_DEBUG
unsigned long atto_sflib_mask = 0;
MODULE_PARAM_ULONG( atto_sflib_mask );
MODULE_PARM_DESC( atto_sflib_mask,
                  "Defines the log mask for sending ATTO multipathing debug "
                  "information to the system log. Default is 0 (none).  See "
                  "lib/storfilt/shared/sfdbg.h");
#endif /* SF_DEBUG */


/* There is an implicit assignment of these default values to values in */
/* the core. Any changes to these values must also be reflected there.  */
#if defined (ATTO_MSIX_SUPPORT)
unsigned int       interrupt_mode = 2;
#elif defined (ATTO_MSI_SUPPORT)
unsigned int       interrupt_mode = 1;
#else /* Legacy only */
unsigned int       interrupt_mode = 0;
#endif /* !ATTO_MSIX_SUPPORT */
MODULE_PARAM_UINT (interrupt_mode);
MODULE_PARM_DESC  (interrupt_mode,
                   "Defines the interrupt mode to use.  0 for legacy"
#if defined (ATTO_MSIX_SUPPORT)
                   ", 1 for MSI, 2 for MSI-X.  Default is MSI-X (2)"
#elif defined (ATTO_MSI_SUPPORT)
                   ", 1 for MSI.  Default is MSI (1)."
#else
                   ". Default is Legacy (0)"
#endif /* !ATTO_MSIX_SUPPORT */
                  );


#if defined (ATTO_MSIX_SUPPORT)
#ifdef __VMKLNX__
unsigned int       use_multiqueue = 1;
MODULE_PARAM_UINT (use_multiqueue);
MODULE_PARM_DESC  (use_multiqueue,
                   "Enables multiqueue.  "
                   "1 to enable affinity, 0 to disable.  "
                   "Default is 1 (enabled)");
#else
unsigned int       cpu_affinity = 0;
MODULE_PARAM_UINT (cpu_affinity);
MODULE_PARM_DESC  (cpu_affinity,
                   "Enables CPU affinity between I/O request and response.  "
                   "1 to enable affinity, 0 to disable.  "
                   "Default is 0 (disabled)");
#endif /* __VMKLNX__ */
#endif /* ATTO_MSIX_SUPPORT */

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,12)
ATTO_DEV_ATTR_T *atto_attrs[] = {
    &ATTO_DEV_ATTR_NAME(event_log_mask),
#ifdef USE_ATTO_LOG
    &ATTO_DEV_ATTR_NAME(atto_log_mask),
#endif
#ifdef ESASHBA
    &ATTO_DEV_ATTR_NAME(sas_dev_order),
#endif
    NULL,
};
#endif

#ifdef ATTO_AS_STACK_SUPPORT
extern int third_party_stack;
extern int stack_max_targets;

static ssize_t atto_as_proc_read (struct file *file,
                                  char __user *buffer,
                                  size_t len,
                                  loff_t *offset)
{
    char *kernel_buffer = vmalloc (len);
    int result;

    if (kernel_buffer == NULL)
        return -ENOMEM;

    result = OsAsProcHandler (kernel_buffer, (int) len, (int) (*offset), 0);

    if (__copy_to_user (buffer, kernel_buffer, result) != 0)
    {
        vfree (kernel_buffer);

        return -EFAULT;
    }

    if (result > 0)
        (*offset) += result;

    return result;
}


static ssize_t atto_as_proc_write (struct file *file,
                                   const char __user *buffer,
                                   size_t len,
                                   loff_t *offset)
{
    char *kernel_buffer = vmalloc (len);
    int result;

    if (kernel_buffer == NULL)
        return -ENOMEM;

    if (__copy_from_user (kernel_buffer, buffer, len) != 0)
    {
        vfree (kernel_buffer);

        return -EFAULT;
    }

    result = OsAsProcHandler (kernel_buffer, (int) len, (int) (*offset), 1);

    if (result > 0)
        (*offset) += result;

    return result;
}


int atto_as_proc_init = 0;
#define ATTO_AS_PROC_NODE_NAME   "atto_" ATTO_DRVR_NAME

static const struct file_operations atto_as_proc_fops =
{
    .owner = THIS_MODULE,
    .read  = atto_as_proc_read,
    .write = atto_as_proc_write,
    .ioctl = atto_proc_ioctl,
};

#endif

/****************************************************************************

    FUNCTION:   void PcidwFromPcid (PPCIDW pcidw, struct pci_dev *pcid)

    PURPOSE:    Populate PCIDW wrap structure from a Linux pci_dev

****************************************************************************/

void PcidwFromPcid (PPCIDW pcidw, struct pci_dev *pcid)
{
    int i;

    pcidw->original = pcid;

    pcidw->bus_number = pcid->bus->number;
    pcidw->devfn      = pcid->devfn;
    pcidw->irq        = pcid->irq;
    pcidw->device     = pcid->device;
    pcidw->vendor     = pcid->vendor;

    for (i = 0; i < PCIDW_RESOURCE_COUNT; i++)
    {
        pcidw->resource[i].start = pcid->resource[i].start;
        pcidw->resource[i].end   = pcid->resource[i].end;
    }
}


/****************************************************************************

    FUNCTION:   void ShwFromScsiHost (PSHW shw, struct Scsi_Host *host)

    PURPOSE:    Populate SHW wrap structure from a Linux Scsi_Host

****************************************************************************/

void ShwFromScsiHost (PSHW shw, struct Scsi_Host *host)
{
    if (host)
    {
        shw->original = host;
        shw->host_no  = host->host_no;
    }
    else
    {
        shw->original = NULL;
        shw->host_no  = 0;
    }

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0)
    shw->os_minor_version = 6;
#else
    shw->os_minor_version = 4;
#endif
}

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0)

#include <ospciids.h>

MODULE_DEVICE_TABLE (pci, atto_pci_table);

static int
#if LINUX_VERSION_CODE < KERNEL_VERSION(3,8,0)
__devinit
#endif
atto_probe_one (struct pci_dev *pdev, const struct pci_device_id *pcid);

static void
#if LINUX_VERSION_CODE < KERNEL_VERSION(3,8,0)
__devexit
#endif
atto_remove_one (struct pci_dev *pdev);

#ifdef CONFIG_PM
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,11)
static int atto_suspend (struct pci_dev *pdev, pm_message_t state);
#else
static int atto_suspend (struct pci_dev *pdev, u32 state);
#endif
static int atto_resume (struct pci_dev *pdev);
#endif

static struct pci_driver 
atto_pci_driver = {
        .name     = ATTO_DRVR_NAME,
        .id_table = atto_pci_table,
        .probe    = atto_probe_one,
        .remove   = 
#if LINUX_VERSION_CODE < KERNEL_VERSION(3,8,0)
                    __devexit_p(atto_remove_one),
#else
                    atto_remove_one,
#endif
#ifdef CONFIG_PM
        .suspend  = atto_suspend,
        .resume   = atto_resume,
#endif
};


/* Following functions add support for the "attocfg" driver, */
/* which discovers HBAs for the ATTO Configuration Tool.     */

/****************************************************************************

    FUNCTION:   atto_attocfg_nvram_handler

    PURPOSE:    Provide attocfg interface to read/write NVRAM.
                These functions just provide an alternate way to do the
                PARAM ioctls to manipulate firmware.
                The buffer size must always be exactly 512 bytes.

    ARGUMENTS:  kobj  - kernel object for this adapter
                buf   - data buffer to read or write
                off   - offset into firmware
                count - size of buffer

    RETURNS:    Actual amount of data read or written

****************************************************************************/

static int verify_nvram_range (int NvramSize, loff_t off, size_t count)
{
    /* Sometimes an app makes one last request for 0 bytes when they */
    /* are done, so silently give it to 'em. Also, if someone tried  */
    /* to write to the file, the size is reset to 0, so the system   */
    /* will try to keep reading up to a page. This needs to be       */
    /* silently handled here too. Otherwise an error is emitted.     */

    if (off >= NvramSize || count == 0)
        return 0;

    /* It must be a full request for the nvram.   The caller can be  */
    /* shorted if they give too much space.                          */

    if (off != 0 || count < NvramSize)
        return -EINVAL;
    
    return 1;
}

#define kobj_to_hostdata(_kobj) \
        dev_to_shost (container_of ((_kobj), struct device, kobj))->hostdata

ssize_t atto_attocfg_nvram_handler  (struct kobject *kobj,
                                     char *buf,
                                     loff_t off,
                                     size_t count,
                                     int operation)
{
    void *context = kobj_to_hostdata (kobj);
    int err;
    int nvram_operation;
    int NvramSize = OsAccessNvram (ATTO_NVRAM_GET_SIZE, context, NULL);

    switch (operation)
    {
    case ATTOCFG_DEFAULT_NVRAM: nvram_operation = ATTO_NVRAM_DEFAULT; break;
    case ATTOCFG_READ_NVRAM:    nvram_operation = ATTO_NVRAM_READ;    break;
    case ATTOCFG_WRITE_NVRAM:   nvram_operation = ATTO_NVRAM_WRITE;   break;
    default:                    return -EFAULT;
    }

    if ((err = verify_nvram_range (NvramSize, off, count)) != 1)
        return err;

    if (!context)
        return -ENODEV;

    if (OsAccessNvram (nvram_operation, context, buf))
        return NvramSize;

    return -EFAULT;
}


#if defined (ESASRAID) || defined (ESASRAID2) || defined (ESAS4HBA) || defined (_MP_)
attocfg_fire_async_event fire_async_event = NULL;
#endif
#ifdef ESASHBA
attocfg_fire_async_event fire_bb_event  = NULL;
#endif

/****************************************************************************

    FUNCTION:   void atto_attocfg_unregister (struct device_driver* driver)

    PURPOSE:    Provide attocfg with driver version information

    ARGUMENTS:  kobj  - kernel object for this adapter
                buf   - data buffer to read or write
                off   - offset into firmware
                count - size of buffer

    RETURNS:    Actual amount of data read or written

****************************************************************************/

static void atto_attocfg_unregister (void)
{
#if defined (ESASRAID) || defined (ESASRAID2) || defined (ESAS4HBA) || defined (_MP_)
    fire_async_event = NULL;
#endif
#ifdef ESASHBA
    fire_bb_event  = NULL;
#endif
}


/****************************************************************************

    FUNCTION:   static ssize_t atto_attocfg_fw_handler (struct kobject *kobj,
                                                        char *buf,
                                                        loff_t off,
                                                        size_t count,
                                                        int operation)


    PURPOSE:    Provide attocfg support to read/write firmware.

    ARGUMENTS:  kobj  - kernel object for this adapter
                buf   - data buffer to read or write
                off   - offset into firmware
                count - size of buffer
                operation - specifies read or write

    RETURNS:    Actual amount of data read or written

****************************************************************************/

static ssize_t atto_attocfg_fw_handler (struct kobject *kobj,
                                        char *buf,
                                        loff_t off,
                                        size_t count,
                                        int operation)
{
    void *context = kobj_to_hostdata (kobj);

    if (operation == ATTOCFG_READ_FW)
        return OsReadFw (context, buf, off, count);
    else if (operation == ATTOCFG_WRITE_FW)
        return OsWriteFw (context, buf, off, count);
    else return -EFAULT;
}


#if defined (ESASRAID) || defined (ESASRAID2)
/****************************************************************************

    FUNCTION:   static ssize_t atto_attocfg_vda_handler (struct kobject *kobj,
                                                         char *buf,
                                                         loff_t off,
                                                         size_t count,
                                                         int operation)

    PURPOSE:    Provide attocfg support to read/write VDA commands.

    ARGUMENTS:  kobj  - kernel object for this adapter
                buf   - data buffer to read or write
                off   - offset into firmware
                count - size of buffer

    RETURNS:    Actual amount of data read or written
                operation - specifies read or write

****************************************************************************/

static ssize_t atto_attocfg_vda_handler (struct kobject *kobj,
                                         char *buf,
                                         loff_t off,
                                         size_t count,
                                         int operation)
{
    void *context = kobj_to_hostdata (kobj);

    if (operation == ATTOCFG_READ_VDA)
        return OsReadVda (context, buf, off, count);
    else if (operation == ATTOCFG_WRITE_VDA)
        return OsWriteVda (context, buf, off, count);
    else return -EFAULT;
}
#endif

#ifdef ENABLE_VSA_IOCTLS
/****************************************************************************

    FUNCTION:   static ssize_t atto_attocfg_vsa_handler (struct kobject *kobj,
                                                         char *buf,
                                                         loff_t off,
                                                         size_t count,
                                                         int operation)

    PURPOSE:    Provide attocfg support to read/write VSA commands.

    ARGUMENTS:  kobj  - kernel object for this adapter
                buf   - data buffer to read or write
                off   - offset into firmware
                count - size of buffer

    RETURNS:    Actual amount of data read or written
                operation - specifies read or write

****************************************************************************/

static ssize_t atto_attocfg_vsa_handler (struct kobject *kobj,
                                         char *buf,
                                         loff_t off,
                                         size_t count,
                                         int operation)
{
    void *context = kobj_to_hostdata (kobj);

    if (operation == ATTOCFG_READ_VSA)
        return OsReadVsa (context, buf, off, count);
    else if (operation == ATTOCFG_WRITE_VSA)
        return OsWriteVsa (context, buf, off, count);
    else return -EFAULT;
}
#endif

#if defined(ESASRAID) || defined(ESASRAID2) || defined(ESASHBA) || defined(CELERITY16FC)
/****************************************************************************

    FUNCTION:   static ssize_t atto_attocfg_fs_handler (struct kobject *kobj,
                                                        char *buf,
                                                        loff_t off,
                                                        size_t count,
                                                        int operation)

    PURPOSE:    Provide attocfg support to read/write FS_API commands.

    ARGUMENTS:  kobj  - kernel object for this adapter
                buf   - data buffer to read or write
                off   - offset into firmware
                count - size of buffer

    RETURNS:    Actual amount of data read or written
                operation - specifies read or write

****************************************************************************/

static ssize_t atto_attocfg_fs_handler (struct kobject *kobj,
                                        char *buf,
                                        loff_t off,
                                        size_t count,
                                        int operation)
{
    void *context = kobj_to_hostdata (kobj);

    if (operation == ATTOCFG_READ_FS)
        return OsReadFs (context, buf, off, count);
    else if (operation == ATTOCFG_WRITE_FS)
        return OsWriteFs (context, buf, off, count);
    else return -EFAULT;
}
#endif

#ifdef _MP_
/****************************************************************************

    FUNCTION:   static ssize_t atto_attocfg_mp_handler (struct kobject *kobj,
                                                        char *buf,
                                                        loff_t off,
                                                        size_t count,
                                                        int operation)

    PURPOSE:    Provide attocfg support to read/write multipath commands.

    ARGUMENTS:  kobj  - kernel object for this adapter
                buf   - data buffer to read or write
                off   - offset into firmware
                count - size of buffer

    RETURNS:    Actual amount of data read or written
                operation - specifies read or write

****************************************************************************/

static ssize_t atto_attocfg_mp_handler (struct kobject *kobj,
                                        char *buf,
                                        loff_t off,
                                        size_t count,
                                        int operation)
{
    void *context = kobj_to_hostdata (kobj);

    if (operation == ATTOCFG_READ_MP)
        return OsReadMp (context, buf, off, count);
    else if (operation == ATTOCFG_WRITE_MP)
        return OsWriteMp (context, buf, off, count);
    else return -EFAULT;
}
#endif

/****************************************************************************

    FUNCTION:   static ssize_t atto_attocfg_hw_handler (struct kobject *kobj,
                                                        char *buf,
                                                        loff_t off,
                                                        size_t count,
                                                        int operation)

    PURPOSE:    Provide attocfg support to read/write hw/hba commands.

    ARGUMENTS:  kobj  - kernel object for this adapter
                buf   - data buffer to read or write
                off   - offset into buffer
                count - size of buffer

    RETURNS:    Actual amount of data read or written
                operation - specifies read or write

****************************************************************************/

static ssize_t atto_attocfg_hw_handler (struct kobject *kobj,
                                        char *buf,
                                        loff_t off,
                                        size_t count,
                                        int operation)
{
    void *context = kobj_to_hostdata (kobj);

    if (operation == ATTOCFG_READ_HW)
        return OsReadHw (context, buf, off, count);
    else if (operation == ATTOCFG_WRITE_HW)
        return OsWriteHw (context, buf, off, count);
    else return -EFAULT;
}


/****************************************************************************

    FUNCTION:   int celerityfc_attocfg_register (PATTOCFG_HANDLERS handlers)

    PURPOSE:    Called by attocfg driver to register this driver's 
                configuration functions.

    RETURNS:    Number of hosts registered, -1 on error

****************************************************************************/

int ATTO_DRVR_SYM( attocfg_register )(PATTOCFG_REGISTER reg)
{
    ATTOCFG_HANDLERS handlers;
    int index;
    int success = 0;

        /* Structure version check */

    if (reg->version != ATTOCFG_VERSION)
    {
        printk (DEBUG_HEADER "attocfg version mismatch! expected %d, got %d.\n",
                ATTOCFG_VERSION, reg->version);

        reg->version = ATTOCFG_VERSION;
        return -1;
    }

        /* Pass along our unregister handler. */

    reg->attocfg_unregister = atto_attocfg_unregister;

#if defined (ESASRAID) || defined (ESASRAID2) || defined (ESAS4HBA) || defined (_MP_)
    if (reg->init_async_event_sockets)
    {
        fire_async_event = reg->fire_vda_event;

        if (!(*reg->init_async_event_sockets) ())
        {
            printk (DEBUG_HEADER "attocfg failed to init async events, "
                    "your adapter may not work as expected.\n");

            fire_async_event = NULL;
        }
    }
    else
    {
        printk (DEBUG_HEADER "attocfg does not support async events, "
                "you may need to get a newer version.\n");
    }
#endif
#ifdef ESASHBA
    if (reg->init_async_event_sockets)
    {
        fire_bb_event = reg->fire_bb_event;

        if (!(*reg->init_async_event_sockets) ())
        {
            printk (DEBUG_HEADER "attocfg failed to init async events, "
                    "your adapter may not work as expected.\n");

            fire_bb_event = NULL;
        }
    }
    else
    {
        printk (DEBUG_HEADER "attocfg does not support async events, "
                "you may need to get a newer version.\n");
    }
#endif

       /* Register all of our hosts. */

    memset (&handlers, 0, sizeof (handlers));
    handlers.hba_nvram_handler = atto_attocfg_nvram_handler;
    handlers.hba_fw_handler    = atto_attocfg_fw_handler;
#if defined(ESASRAID) || defined(ESASRAID2)
    handlers.hba_vda_handler   = atto_attocfg_vda_handler;
#endif
#ifdef ENABLE_VSA_IOCTLS
    handlers.hba_vsa_handler   = atto_attocfg_vsa_handler;
#endif
#if defined(ESASRAID) || defined(ESASRAID2) || defined(ESASHBA) || defined (CELERITY16FC)
    handlers.hba_fs_handler    = atto_attocfg_fs_handler;
#endif
#ifdef _MP_
    handlers.hba_mp_handler    = atto_attocfg_mp_handler;
#endif
    handlers.hba_hw_handler    = atto_attocfg_hw_handler;

    for (index = 0; index < ATTO_MAX_DEVICES; index++)
    {
        struct Scsi_Host *host = OsGetAdapterHost (index);

        if (host)
        {
            if (!(*reg->attocfg_register_host) (reg->context,
                                                &host->shost_gendev.kobj,
                                                &handlers))
            {
#if defined (ESASRAID) || defined (ESASRAID2) || defined (ESAS4HBA) || defined (_MP_) 
                fire_async_event = NULL;
#endif
#ifdef ESASHBA
                fire_bb_event = NULL;
#endif
                return -1;
            }

            success++;
        }
    }

    return success;
}


/****************************************************************************

    FUNCTION:   static int __devinit
                atto_probe_one (struct pci_dev *pdev,
                                const struct pci_device_id *pcid)

                static void __devexit
                atto_remove_one (struct pci_dev *pdev)

    PURPOSE:    Device discovery and removal

    RETURNS:    0 on success, -errno on failure

****************************************************************************/

static int
#if LINUX_VERSION_CODE < KERNEL_VERSION(3,8,0)
__devinit
#endif
atto_probe_one (struct pci_dev *pdev, const struct pci_device_id *pcid)
{
    Scsi_Host_Template *sht = NULL;
    int rez;

#ifdef ATTO_CUSTOM_STACK_SUPPORT
    if (!third_party_stack)
#endif
    {
        sht = &driver_template;

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,26) && !defined( _MP_ )
        if (!old_device_reset)
            sht->eh_target_reset_handler = atto_target_reset;
#endif
    }
#ifdef ATTO_AS_STACK_SUPPORT
    else if (!atto_as_proc_init)
    {
        struct proc_dir_entry *pde;

#if LINUX_VERSION_CODE < KERNEL_VERSION(3,10,0)
        pde = create_proc_entry (ATTO_AS_PROC_NODE_NAME, 0, NULL);
#else
        pde = proc_create(ATTO_AS_PROC_NODE_NAME, 0, NULL, &atto_as_proc_fops);
#endif

        if (!pde)
            printk (DEBUG_HEADER "Failed to create /proc/" ATTO_AS_PROC_NODE_NAME "\n");
        else
        {
#if LINUX_VERSION_CODE < KERNEL_VERSION(3,10,0)
            pde->proc_fops = &atto_as_proc_fops;
#endif
            atto_as_proc_init = 1;
        }

    }
#endif

    rez = atto_init_device (sht, pdev);

    if (rez < 0)
        return rez;

    if (rez == 1)
        found_adapters++;

    return 0;
}

static void
#if LINUX_VERSION_CODE < KERNEL_VERSION(3,8,0)
__devexit
#endif
atto_remove_one (struct pci_dev *pdev)
{
    struct Scsi_Host *host;
    int index;

    if (pdev == NULL)
    {
        printk (DEBUG_HEADER "atto_remove_one pdev==NULL\n");
        return;
    }

    host = pci_get_drvdata (pdev);

    if (host == NULL)
    {
        /* This can happen if pci_set_drvdata was already called */
        /* to clear the host pointer.  If this is the case, we   */
        /* are okay; this channel has already been cleaned up.   */

        return;
    }

#if defined(__VMKLNX__) && defined (IODM)
	vmklnx_iodm_disable_events(host);
#endif

    ATTO_DEV_LOG (KERN_INFO, ATTO_LOG_INIT, &pdev->dev,
                  "atto_remove_one(%p) called; host:%p\n", pdev, host);

    index = OsCleanup (host);

    if (index < 0)
        ATTO_DEV_LOG (KERN_WARNING, ATTO_LOG_INIT, &pdev->dev,
                      "Unknown host in atto_remove_one\n");

    found_adapters--;

    /* If this was the last adapter, clean up the rest of the driver */

    if (found_adapters == 0)
        OsCleanup (NULL);
}

#ifdef CONFIG_PM
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,11)
static int atto_suspend (struct pci_dev *pdev, pm_message_t state)
#else
static int atto_suspend (struct pci_dev *pdev, u32 state)
#endif
{
    struct Scsi_Host *host = pci_get_drvdata (pdev);
    int rez;
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,11)
    u32 device_state;
#endif

    ATTO_DEV_LOG(KERN_INFO, ATTO_LOG_PCI, &pdev->dev,
                 "suspending adapter()\n");

    rez = OsSuspend (host);

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,11)
    device_state = pci_choose_state (pdev, state);
#endif

#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,9)
    ATTO_DEV_LOG(KERN_INFO, ATTO_LOG_PCI, &pdev->dev,
                 "pci_save_state() called\n");    
    pci_save_state (pdev);
#endif
    ATTO_DEV_LOG(KERN_INFO, ATTO_LOG_PCI, &pdev->dev,
                 "pci_disable_device() called\n");    
    pci_disable_device (pdev);
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,11)
    ATTO_DEV_LOG(KERN_INFO, ATTO_LOG_PCI, &pdev->dev,
                 "pci_set_power_state() called\n");    
    pci_set_power_state (pdev, device_state);
#endif

    ATTO_DEV_LOG(KERN_INFO, ATTO_LOG_PCI, &pdev->dev,
                 "atto_suspend(): %d\n", rez);    

    return rez;
}

#ifndef PCI_D0
#define PCI_D0 0
#endif

static int atto_resume (struct pci_dev *pdev)
{
    struct Scsi_Host *host = pci_get_drvdata (pdev);
    int rez;

    ATTO_DEV_LOG(KERN_INFO, ATTO_LOG_PCI, &pdev->dev,
                 "Resuming adapter()\n");

    ATTO_DEV_LOG(KERN_INFO, ATTO_LOG_PCI, &pdev->dev,
                 "pci_set_power_state(PCI_D0) called\n");    
    pci_set_power_state (pdev, PCI_D0);

    ATTO_DEV_LOG(KERN_INFO, ATTO_LOG_PCI, &pdev->dev,
                 "pci_enable_wake(PCI_D0, 0) called\n");    
    pci_enable_wake (pdev, PCI_D0, 0);

#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,9)
    ATTO_DEV_LOG(KERN_INFO, ATTO_LOG_PCI, &pdev->dev,
                 "pci_restore_state() called\n");    
    pci_restore_state (pdev);
#endif

    ATTO_DEV_LOG(KERN_INFO, ATTO_LOG_PCI, &pdev->dev,
                 "pci_enable_device() called\n");    
    rez = pci_enable_device (pdev);

    pci_set_master (pdev);

    ATTO_DEV_LOG(KERN_INFO, ATTO_LOG_SCSI, &host->shost_gendev,
                 "calling OsResume()\n");
    rez = OsResume (host);

    ATTO_DEV_LOG(KERN_INFO, ATTO_LOG_PCI, &pdev->dev,
                 "atto_resume(): %d\n", rez);    

    return rez;
}
#endif

#endif


/****************************************************************************

    FUNCTION:   int esashba_init (void)

    PURPOSE:    Called when the module loads.  Checks for module parameters,
                the registers us as a SCSI driver.

    ARGUMENTS:  none

    RETURNS:    0 on success
                -1 on error

****************************************************************************/

static int __init ATTO_DRVR_SYM( init )(void)
{
#ifdef USE_ATTO_LOG
    atto_log_start = jiffies;
#endif

    ATTO_LOG (KERN_INFO, ATTO_LOG_INIT, "module init called\n");

    /* Make sure core revision is correct */

    if (OsGetCoreRev () != ATTO_CORE_REV)
    {
        printk (DEBUG_HEADER "Mismatched core revision: Expected %d, got %d.\n", ATTO_CORE_REV, OsGetCoreRev ());

        return -1;
    }

#ifdef SF_DEBUG
    OsSfDbgSetMask( atto_sflib_mask );
#endif

#if defined (ATTO_USE_TRANSPORT) && defined (ATTO_TRANSPORT)
    if (use_transport_layer) {
       if (!atto_attach_transport ())
       {
           printk (DEBUG_HEADER "Failed to attach to transport.\n");

           return -1;
       }
    }
#endif

    /* Verify valid parameters */

#ifdef TARGET_MODE
    if (target_mode == 0
    &&  initiator_mode == 0)
    {
        printk (DEBUG_HEADER "Must enable one of target_mode or "
                "initiator_mode.\n");

        return -1;
    }
#endif

    if (can_queue < 1)
    {
        printk (DEBUG_HEADER "Warning: can_queue must be at least 1, value "
                "forced.\n");
        can_queue = 1;
    }
    else if (can_queue > 2048)
    {
        printk (DEBUG_HEADER "Warning: can_queue must be no larger than 2048, "
                "value forced.\n");
        can_queue = 2048;
    }

    if (cmd_per_lun < 1)
    {
        printk (DEBUG_HEADER "Warning: cmd_per_lun must be at least 1, value "
                "forced.\n");
        cmd_per_lun = 1;
    }
    else if (cmd_per_lun > 2048)
    {
        printk (DEBUG_HEADER "Warning: cmd_per_lun must be no larger than "
                "2048, value forced.\n");
        cmd_per_lun = 2048;
    }

    if (sg_tablesize < 32)
    {
        printk (DEBUG_HEADER "Warning: sg_tablesize must be at least 32, value "
                "forced.\n");
        sg_tablesize = 32;
    }
    else if (sg_tablesize > ATTO_SG_TABLESIZE_MAX)
    {
        printk (DEBUG_HEADER "Warning: sg_tablesize must be no larger than %d, "
                "value forced.\n",
                ATTO_SG_TABLESIZE_MAX);
        sg_tablesize = ATTO_SG_TABLESIZE_MAX;
    }

    if (atto_max_sectors < 1)
    {
        printk (DEBUG_HEADER "Warning: atto_max_sectors must be at least 1, "
                "value forced.\n");
        atto_max_sectors = 1;
    }
    else if (atto_max_sectors > 0xffff)
    {
        printk (DEBUG_HEADER "Warning: atto_max_sectors must be no larger than "
                "0xffff, value forced.\n");
        atto_max_sectors = 0xffff;
    }

    /* Initialize */


#if LINUX_VERSION_CODE < KERNEL_VERSION(2,5,0)
    if (initiator_mode)
    {
        /* Register us as a SCSI module */

        driver_template.module = THIS_MODULE;
        scsi_register_module (MODULE_SCSI_HA, &driver_template);
    }
    else
    {
        /* Manually detect HBAs */

        atto_detect (NULL);

        if (!found_adapters)
        {
            printk (DEBUG_HEADER "Driver will not be loaded because no " ATTO_DRVR_NAME " devices were found. \n");
            OsCleanup (NULL);
            return -1;
        }
        else
            printk (DEBUG_HEADER "Found %d adapters.\n", found_adapters);
    }
#else /* LINUX_VERSION_CODE >= KERNEL_VERSION(2,5,0) */
    /* Manually detect HBAs */

    driver_template.module = THIS_MODULE;

    /* The system will call the driver structure's */
    /* probe method for each device.               */

#if LINUX_VERSION_CODE <= KERNEL_VERSION(2,6,18)
    if (pci_module_init (&atto_pci_driver) != 0)
        printk (DEBUG_HEADER "pci_module_init() FAILED\n");
    else
        ATTO_LOG (KERN_INFO, ATTO_LOG_PCI, "pci_module_init() OK\n");
#else
    if (pci_register_driver (&atto_pci_driver) != 0)
        printk (DEBUG_HEADER "pci_register_driver FAILED\n");
    else
        ATTO_LOG (KERN_INFO, ATTO_LOG_PCI, "pci_register_driver() OK\n");
#endif

    if (!found_adapters)
    {
        ATTO_LOG (KERN_INFO, ATTO_LOG_PCI, "pci_unregister_driver() called\n");
        pci_unregister_driver (&atto_pci_driver);
        OsCleanup (NULL);
        printk(DEBUG_HEADER "Driver will not be loaded because no ATTO " ATTO_DRVR_NAME " devices were found\n");
#if defined (ESAS2HBA) || defined (ESAS4HBA)
        printk(DEBUG_HEADER "This can be caused by a conflict with pm8001/pm80xx kernel driver.  In order to use the " ATTO_DRVR_NAME " driver, the pm8001/pm80xx driver must be unloaded.\n");
#endif
#if defined (ESASRAID2)
        printk(DEBUG_HEADER "This can be caused by a conflict with esas2r kernel driver.  In order to use the " ATTO_DRVR_NAME " driver, the esas2r driver must be unloaded.\n");
#endif
       return -1;
    }
    else
        printk (DEBUG_HEADER "Found %d adapters.\n", found_adapters);
#endif /* LINUX_VERSION_CODE >= KERNEL_VERSION(2,5,0) */

    return 0;
}


/****************************************************************************

    FUNCTION:   int atto_proc_ioctl (struct inode *inode, struct file *fp,
                                     unsigned int cmd, unsigned long arg) 


    PURPOSE:    Handle ioctl calls to "/proc/scsi/celerityfc/ATTONode"

****************************************************************************/

#ifdef CONFIG_PROC_FS
static struct file_operations atto_proc_fops =
{
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,35)
    .ioctl = atto_proc_ioctl,
#else
    .compat_ioctl   = atto_proc_ioctl,
    .unlocked_ioctl = atto_proc_ioctl,
#endif
};
static struct Scsi_Host *atto_proc_host = NULL;
static int atto_proc_major = 0;

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,35)
int atto_proc_ioctl (struct inode *inode, struct file *fp,
                     unsigned int cmd, unsigned long arg)
#else
long atto_proc_ioctl (struct file *fp, unsigned int cmd, unsigned long arg)
#endif
{
    return atto_ioctl_handler (atto_proc_host->hostdata,
                               (int) cmd, (void *) arg);
}
#endif

/****************************************************************************

    FUNCTION:   void esashba_exit (void)

    PURPOSE:    Called when module unloads.  Unregisters us & free memory.

    ARGUMENTS:  none

    RETURNS:    Nothing

****************************************************************************/

static void __exit ATTO_DRVR_SYM( exit )(void)
{
    ATTO_LOG (KERN_INFO, ATTO_LOG_INIT, "module exit\n");

#ifdef CONFIG_PROC_FS
    if (atto_proc_major > 0)
    {
        ATTO_LOG (KERN_INFO, ATTO_LOG_INIT, "unregister proc\n");
        remove_proc_entry (ATTONODE_NAME, atto_proc_host->hostt->proc_dir);
        unregister_chrdev (atto_proc_major, ATTO_DRVR_NAME);
        atto_proc_major = 0;
    }
#endif

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,5,0)
    if (initiator_mode)
        scsi_unregister_module (MODULE_SCSI_HA, &driver_template);
#endif

#ifdef ATTO_CUSTOM_STACK_SUPPORT
    if (third_party_stack)
        OsCleanup (NULL);

#ifdef ATTO_AS_STACK_SUPPORT
    if (atto_as_proc_init)
    {
        remove_proc_entry (ATTO_AS_PROC_NODE_NAME, NULL);
        atto_as_proc_init = 0;
    }
#endif
#endif

    /* Do not call OsCleanup(NULL) here. The call to                      */
    /* pci_unregister_driver() will call atto_remove_one() on each device */
    /* which will in turn call OsCleanup() on each SCSI host. When the    */
    /* last host has been cleaned up, an OsCleanup(NULL) call is made.    */

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0)
    ATTO_LOG (KERN_INFO, ATTO_LOG_PCI, "pci_unregister_driver() called\n");
    pci_unregister_driver (&atto_pci_driver);
#endif

#if defined (ATTO_USE_TRANSPORT) && defined (ATTO_TRANSPORT)
    if (use_transport_layer)
        atto_release_transport ();
#endif
}

/****************************************************************************

    FUNCTION:   int atto_proc_info (char *buffer, char **start, off_t offset,
                                    int len, int host, int in)

    PURPOSE:    Support for /proc entry for this driver

    ARGUMENTS:  buffer - input/output buffer
                start  - start of valid data in buffer (when !in)
                offset - offset to begin buffer write (when !in)
                len    - size of buffer
                host   - host number
                in     - 1 if data is input, 0 if its output

    RETURNS:    If in, number of bytes written
                If !in, number of bytes read
                For error, return negative errno

****************************************************************************/

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,5,0)

int atto_proc_info (char *buffer, char **start, off_t offset,
                    int len, int host, int in)
{
    ATTO_LOG (KERN_INFO, ATTO_LOG_DEBUG,
              "proc_info (%p, %p, %d, %d, %d, %d)\n",
              buffer, start, (int) offset, len, host, in);

    if (in)
        return OsInProcInfo (buffer, len, host);
    else
        return OsOutProcInfo (buffer, start, offset, len, host);
}

#elif  LINUX_VERSION_CODE < KERNEL_VERSION(3,10,0)

int atto_proc_info (struct Scsi_Host *sh, char *buffer,
                    char **start, off_t offset, int len, int in)
{
    ATTO_LOG (KERN_INFO, ATTO_LOG_DEBUG,
              "proc_info (%p, %p, %d, %d, %d, %d)\n",
              buffer, start, (int) offset, len, sh->host_no, in);

    if (in)
        return OsInProcInfo (buffer, len, sh->host_no);
    else
        return OsOutProcInfo (buffer, start, offset, len, sh->host_no);
}
#else

int atto_show_info(struct seq_file *m, struct Scsi_Host *sh)
{
    int len;
    int avail = m->size - m->count;

    len = OsOutProcInfo (m, NULL, 0, avail, sh->host_no);

    ATTO_LOG (KERN_INFO, ATTO_LOG_DEBUG,
              "show_info (%d, %d, %d)\n",
              len, avail, sh->host_no);

    return 0;
}

int atto_write_info(struct Scsi_Host *sh, char *buf, int len)
{
    ATTO_LOG (KERN_INFO, ATTO_LOG_DEBUG,
              "write_info (%p, %d, %d)\n",
              buf, len, sh->host_no);

    return OsInProcInfo (buf, len, sh->host_no);
}
#endif


/****************************************************************************

    FUNCTION:   int atto_init_device (Scsi_Host_Template *sht,
                                      struct pci_dev *pcid)

    PURPOSE:    Initialize a discovered HBA

    ARGUMENTS:  sht - Scsi Host Template passed to scsi_register_module
                pcid - PCI device detected

    RETURNS:    1 on success
                0 on if a dummy device was detected
                -errno if failure

****************************************************************************/

int atto_init_device (Scsi_Host_Template *sht, struct pci_dev *pcid)
{
    struct Scsi_Host *host = NULL;
    PCIDW pcidw;
    SHW shw;
    void **context;
    int err;

    ATTO_DEV_LOG (KERN_INFO, ATTO_LOG_INIT, &pcid->dev,
                  "atto_init_device() 0x%02x 0x%02x  0x%02x 0x%02x\n",
                  pcid->vendor, pcid->device, pcid->subsystem_vendor, pcid->subsystem_device );

    /* Make sure its ours, not some other vendor's HBA */

    if (pcid->subsystem_vendor != ATTO_VENDOR_ID)
    {
        ATTO_DEV_LOG (KERN_INFO, ATTO_LOG_INIT, &pcid->dev,
                      "non-ATTO subsystem vendor\n");
#if !defined (CELERITY16FC)
// TODO - FIXME
        return -ENODEV;
#endif
    }

    /* See if it is a dummy device */

    if (pcid->subsystem_device == 0x0024)
    {
        ATTO_DEV_LOG (KERN_INFO, ATTO_LOG_INIT, &pcid->dev,
                      "dummy channel - not initializing\n");
        return 0;
    }

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,20)
    ATTO_DEV_LOG (KERN_INFO, ATTO_LOG_PCI, &pcid->dev,
                  "before pci_enable_device() enable_cnt:%d\n",
                  pcid->enable_cnt.counter);
#endif

    if ((err = pci_enable_device (pcid)) != 0)
    {
        ATTO_DEV_LOG (KERN_WARNING, ATTO_LOG_PCI, &pcid->dev,
                      "pci_enable_device() FAIL (%d)\n", err);
        return -ENODEV;
    }
    ATTO_DEV_LOG(KERN_INFO, ATTO_LOG_PCI, &pcid->dev,
                  "pci_enable_device() OK\n");

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,20)
    ATTO_DEV_LOG (KERN_INFO, ATTO_LOG_PCI, &pcid->dev,
                  "after pci_device_enable() enable_cnt:%d\n",
                  pcid->enable_cnt.counter);
#endif

#ifdef ATTO_CUSTOM_STACK_SUPPORT
    if (!third_party_stack)
#endif
    {
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0)

        if ((host = scsi_host_alloc (sht, sizeof (void *))) == NULL)
        {
            ATTO_LOG (KERN_WARNING, ATTO_LOG_SCSI, "scsi_host_alloc() FAIL\n");
            return -ENODEV;
        }
        ATTO_LOG (KERN_INFO, ATTO_LOG_SCSI, "scsi_host_alloc() OK host:%p\n", host);
#else /* LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0) */
        if ((host = scsi_register (sht, sizeof (void *))) == NULL)
        {
            ATTO_LOG (KERN_WARNING, ATTO_LOG_SCSI, "scsi_register() FAIL\n");
            return -ENODEV;
        }
        ATTO_LOG (KERN_INFO, ATTO_LOG_SCSI, "scsi_register() OK host:%p\n", host);
#endif /* LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0) */

        /* Override max LUN and max target id */

        host->max_id  = ATTO_MAX_ID + 1;
        host->max_lun = ATTO_MAX_LUN + 1;

        /* We can handle 16-byte CDBs */

        host->max_cmd_len  = 16;

        host->can_queue    = can_queue;
        host->cmd_per_lun  = cmd_per_lun;
        host->this_id      = host->max_id + 1;
        host->max_channel  = 0;
        host->unique_id    = found_adapters;
        host->sg_tablesize = sg_tablesize;
        host->max_sectors  = atto_max_sectors;
#if defined(ATTO_USE_TRANSPORT) && defined(ATTO_TRANSPORT)
        if (use_transport_layer)
            host->transportt = atto_get_transport_template ();
#endif

        context = (void **) host->hostdata;
    }
#ifdef ATTO_CUSTOM_STACK_SUPPORT
    else
    {
        if ((context = (void **) vmalloc (sizeof (void *))) == NULL)
        {
            ATTO_LOG (KERN_WARNING, ATTO_LOG_INIT, "could not allocate adapter extension\n");
            return -ENOMEM;
        }
    }
#endif

    /* Set to bus master for BIOSes that don't do it for us */
    ATTO_LOG (KERN_INFO, ATTO_LOG_PCI, "pci_set_master() called\n");
    pci_set_master (pcid);

    /* Fill in the pci_dev and Scsi_Host wrappers for the core portion */

    PcidwFromPcid (&pcidw, pcid);
    ShwFromScsiHost (&shw, host);

    if (!OsInitAdapter (&shw, context, &pcidw, found_adapters))
    {
        ATTO_LOG (KERN_WARNING, ATTO_LOG_INIT, "unable to initalize device at PCI bus %x:%x\n", pcid->bus->number, pcid->devfn);

        goto InitFailed;
    }

    /* If OsInitAdapter returned success, but the context is NULL,   */
    /* this channel is a dummy driver and no further init is needed. */

    if ((*context) == NULL)
    {
        /* Note - this should never happen, we should have caught */
        /* the dummy channel above based on the SS device ID.     */

        ATTO_LOG (KERN_INFO, ATTO_LOG_INIT, "dummy channel found at PCI bus %x:%x\n", pcid->bus->number, pcid->devfn);

InitFailed:
#ifdef ATTO_CUSTOM_STACK_SUPPORT
        if (third_party_stack)
        {
            fixme undo proc entry
            vfree (context);
        }
        else
#endif
        {
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0)
            ATTO_DEV_LOG (KERN_INFO, ATTO_LOG_SCSI, &(host->shost_gendev),
                          "scsi_host_put() called\n");
            scsi_host_put (host);
#else
            ATTO_DEV_LOG (KERN_INFO, ATTO_LOG_SCSI, &(host->shost_gendev),
                          "scsi_unregister() called\n");
            scsi_unregister (host);
#endif
        }

        context = NULL;
    
        return 0;
    }


#ifdef ATTO_CUSTOM_STACK_SUPPORT
    if (third_party_stack)
    {
        OsAllowChangeNotification (found_adapters, 1, 0);
        LinuxScheduleWork (found_adapters);
    }
    else
#endif
    {
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0)
    /* Add this channel as a SCSI host */

    ATTO_LOG (KERN_INFO, ATTO_LOG_PCI, "pci_set_drvdata(%p, %p) called\n", pcid, context);
    /* The PCI driver data is a pointer to the SCSI host instance. */
    pci_set_drvdata (pcid, host);

    ATTO_LOG (KERN_INFO, ATTO_LOG_SCSI, "scsi_add_host() called\n");
    err = scsi_add_host (host, &pcid->dev);

#ifdef __VMKLNX__
    OsSetupIoqueue(pcid, context);
#endif    

    if (err)
    {
        printk (DEBUG_HEADER "scsi_add_host returned %d.\n", err);
        ATTO_DEV_LOG (KERN_WARNING, ATTO_LOG_SCSI, &(host->shost_gendev),
                      "scsi_add_host() FAIL\n");

        ATTO_DEV_LOG (KERN_INFO, ATTO_LOG_SCSI, &(host->shost_gendev),
                      "scsi_host_put() called\n");
        scsi_host_put (host);
            
        ATTO_DEV_LOG (KERN_INFO, ATTO_LOG_PCI, &(host->shost_gendev), "pci_set_drvdata(%p, NULL) called\n", pcid);
        pci_set_drvdata (pcid, NULL);
        return -ENODEV;
    }

#ifdef __VMKLNX__


#ifdef IODM
    vmklnx_iodm_enable_events(pci_get_drvdata(pcid));
#endif
     
#ifdef ATTO_VMK_50
    /* For VMware, register the interrupt handler with the VMkernel */
    /* so that it gets called during coredump.                      */
    OsSetupPollHandler(host, pcid->irq, context);
#endif /* ATTO_VMK_50 */

    /* Set up the character device for handling ioctls */
    if (atto_proc_major <= 0)
    {
        atto_proc_host = host;
        atto_proc_major = register_chrdev(0,
                                          ATTO_DRVR_NAME,
                                          &atto_proc_fops);

        ATTO_LOG (KERN_INFO, ATTO_LOG_INIT,
            "register_chrdev (major %d) VMKLNX\n",
            atto_proc_major);
    }
#endif

#if defined (ATTO_USE_TRANSPORT) && defined (ATTO_TRANSPORT)
    if (use_transport_layer)
        atto_init_host_attr (host, found_adapters);
#endif

#ifdef ATTO_RESCANS_ENABLED
#if defined (ATTO_RPORTS) || defined (ATTO_SAS_PORTS)
    /* If using FC rports or SAS ports, then process all scan state */
    /* changes.                                                     */
    if (use_transport_layer)
        OsAllowChangeNotification (found_adapters, 1, 0);
    else
#endif
    /* If not using FC rports or SAS ports, then clear the */
    /* ScanState table (third param = 1).                  */
    OsAllowChangeNotification (found_adapters, 1, 1);

#if defined (ATTO_RPORTS) || defined (ATTO_SAS_PORTS)
    if (use_transport_layer)
        LinuxScheduleWork (found_adapters);
#endif
#endif /* ATTO_RESCANS_ENABLED */

#if !defined (ATTO_RPORTS) && !defined (ATTO_SAS_PORTS) && !defined (_MP_)
    /* Do not scan the host. In the case of FC Rports or SAS ports */
    /* the devices are discovered via the transport layer as       */
    /* targets are reported. In the case of MP, the driver will    */
    /* report the devices as they are discovered.                  */
    ATTO_DEV_LOG (KERN_INFO, ATTO_LOG_SCSI, &(host->shost_gendev),
                  "scsi_scan_host() called.\n");
    scsi_scan_host (host);
#else
    /* This is the case where RPORTS, SAS_PORTS or MP is compiled in */
    /* but the transport_layer is turned off by module param. In     */
    /* this case, we need to scan the host.                          */
#if defined (ATTO_USE_TRANSPORT) && defined (ATTO_TRANSPORT)
    if (!use_transport_layer)
    {
        ATTO_DEV_LOG (KERN_INFO, ATTO_LOG_SCSI, &(host->shost_gendev),
                      "scsi_scan_host() called.\n");
        scsi_scan_host (host);
    }
#endif
#endif

#if LINUX_VERSION_CODE <= KERNEL_VERSION(2,6,12)

    /* This function was removed in 2.6.13 */

    ATTO_DEV_LOG (KERN_INFO, ATTO_LOG_SCSI, &(host->shost_gendev),
                  "scsi_set_device() called.\n");
    scsi_set_device (host, &pcid->dev);

#endif /* LINUX_VERSION_CODE <= KERNEL_VERSION(2,6,12) */

#else /* LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0) */

    ATTO_DEV_LOG (KERN_INFO, ATTO_LOG_SCSI, &(host->shost_gendev),
                  "scsi_set_pci_device(%p, %p) called.\n", host, pcid);
    scsi_set_pci_device (host, pcid);

#if defined(ATTO_USE_TRANSPORT) && defined (ATTO_TRANSPORT)
    /* Init host attributes for transport layer here. This will */
    /* get called here for vmware driver. For other standard    */
    /* linux (< 2.6.0) it's a no-op (see os.h)                  */

    if (use_transport_layer)
        atto_init_host_attr(host, found_adapters);
#endif /* ATTO_USE_TRANSPORT */

#endif /* LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0) */
    if (host)
    {
        host->irq     = pcid->irq;
        host->io_port = pcid->resource[0].start;
    }
    }

    return 1;
}

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,5,0)
/****************************************************************************

    FUNCTION:   int atto_detect (Scsi_Host_Template *sht)

    PURPOSE:    Detect & initialize installed HBAs

    ARGUMENTS:  sht - Scsi Host Template passed to scsi_register_module

    RETURNS:    Number of HBAs detected

****************************************************************************/

#ifdef CELERITYFC
#if defined (CELERITY16FC)
unsigned short VendorIds [] = {0x10DF};
unsigned short DeviceIds [] = {0xE200};
#elif defined (CELERITY8FC)
unsigned short VendorIds [] = {0x11F8, 0x11F8};
unsigned short DeviceIds [] = {0x8032, 0x8031};
#else
unsigned short VendorIds [] = {0x103C, 0x15BC, 0x15BC, 0x15BC,
                               0x15BC, 0x15BC, 0x15BC, 0x15BC};
unsigned short DeviceIds [] = {0x1029, 0x0100, 0x0101, 0x0102,
                               0x0103, 0x0104, 0x0105, 0x1203};
#endif
#endif

#ifdef ESASRAID
unsigned short VendorIds [] = {ATTO_VENDOR_ID};
unsigned short DeviceIds [] = {0x002C};
#endif

#ifdef ESASHBA
#ifdef ESAS3HBA
unsigned short VendorIds [] = {ATTO_VENDOR_ID};
unsigned short DeviceIds [] = {0x0056};
#ifdef ESAS2HBA
unsigned short VendorIds [] = {ATTO_VENDOR_ID};
unsigned short DeviceIds [] = {0x0042};
#else /* ESASHBA */
unsigned short VendorIds [] = {ATTO_VENDOR_ID, ATTO_VENDOR_ID};
unsigned short DeviceIds [] = {0x0033,         0x0039};
#endif
#endif
#endif

#ifdef ESASRAID2
unsigned short VendorIds [] = {ATTO_VENDOR_ID};
unsigned short DeviceIds [] = {0x0049};
#endif


int atto_detect (Scsi_Host_Template *sht)
{
    int found_orig = found_adapters;
    struct pci_dev *pcid = NULL;
    int dev_index = 0;

    ATTO_LOG (KERN_INFO, ATTO_LOG_INIT, "detect (%p)\n", sht);


    if (!pci_present ())
    {
        printk (DEBUG_HEADER "PCI not present.\n");
        return 0;
    }

    while (found_adapters < ATTO_MAX_DEVICES
       &&  dev_index < numof (VendorIds))
    {
        /* Look for the next device matching our vendor/device IDs */

        if ((pcid = pci_find_device (VendorIds [dev_index],
                                     DeviceIds [dev_index],
                                     pcid)) == NULL)
        {
            ATTO_LOG (KERN_INFO, ATTO_LOG_PCI, "pci_find_device() returned NULL\n");
            dev_index++;
            pcid = NULL;
            continue;
        }

        ATTO_LOG (KERN_INFO, ATTO_LOG_PCI,
                  "pci_find_device() OK 0x%02x 0x%02x 0x%02x 0x%02x\n"
                  VendorIds[dev_index], DeviceIds[dev_index],
                  pcid->subsystem_vendor, pcid->subsystem_device);
        ATTO_LOG (KERN_INFO, ATTO_LOG_PCI,
                  "  bus:%d, devfn:%d class:%d IRQ:%d\n",
                  pcid->bus_number, pcid->devfn, pcid->class, pci->irq);

        if (atto_init_device (sht, pcid) == 1)
            found_adapters++;
    }

    /* NOW, set use_new_eh_code to 1.  We don't do it in the template     */
    /* because then the scsi module would disable ints for this function. */

    if (sht)
        sht->use_new_eh_code = 1;

    return (found_adapters - found_orig);
}
#endif


/****************************************************************************

    FUNCTION:   int atto_release (Scsi_Host *sh)

    PURPOSE:    Free memory for associated SCSI host

    ARGUMENTS:  sh - Scsi Host to free

    RETURNS:    0 always

****************************************************************************/

int atto_release (struct Scsi_Host *sh)
{
    ATTO_DEV_LOG (KERN_INFO, ATTO_LOG_INIT, &(sh->shost_gendev),
                  "atto_release() called\n");

    OsCleanup ((void *) sh);

    return 0;
}


/****************************************************************************

    FUNCTION:   const char *atto_info (struct Scsi_Host *)

    PURPOSE:    Get a string describing the adapter

    ARGUMENTS:  sh - Scsi Host to get string for

    RETURNS:    Pointer to retreived string

****************************************************************************/

const char *atto_info (struct Scsi_Host *sh)
{
    ATTO_DEV_LOG (KERN_INFO, ATTO_LOG_DEBUG, &(sh->shost_gendev),
                  "atto_info() called\n");

#ifndef ATTO_VMK_50

#ifdef CONFIG_PROC_FS
    /* If we haven't done so already, register as a char driver */
    /* and stick a node under "/proc/scsi/celerityfc/ATTONode"  */

    if (atto_proc_major <= 0)
    {
        atto_proc_host = sh;

        atto_proc_major = register_chrdev (0, ATTO_DRVR_NAME, &atto_proc_fops);

        ATTO_DEV_LOG (KERN_INFO, ATTO_LOG_DEBUG, &(sh->shost_gendev),
                      "register_chrdev (major %d)\n", atto_proc_major);

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,5,0)

        if (atto_proc_major > 0)
            proc_mknod (ATTONODE_NAME,
                        0777 + S_IFCHR,
                        sh->hostt->proc_dir,
                        (kdev_t) MKDEV (atto_proc_major, 0));

#else

        if (atto_proc_major > 0)
        {
            struct proc_dir_entry *pde;

#if LINUX_VERSION_CODE < KERNEL_VERSION(3,10,0)
            pde = create_proc_entry (ATTONODE_NAME, 0, sh->hostt->proc_dir);
#else
            pde = proc_create(ATTONODE_NAME, 0, sh->hostt->proc_dir, &atto_proc_fops);
#endif

            if (!pde)
            {
                ATTO_DEV_LOG (KERN_WARNING, ATTO_LOG_DEBUG, &(sh->shost_gendev),
                              "failed to create_proc_entry\n");
                atto_proc_major = -1;
            }
#if LINUX_VERSION_CODE < KERNEL_VERSION(3,10,0)
            else
                pde->proc_fops = &atto_proc_fops;
#endif
        }

#endif
    }

#endif

#endif /* ATTO_VMK_50 */

    return OsDriverInfo (sh->hostdata);
}


/****************************************************************************

    FUNCTION:   int atto_ioctl_handler (void *hostdata, int cmd, void *arg)
                int atto_ioctl (Scsi_Device *sd, int cmd, void *arg)

    PURPOSE:    Handles IOCTL calls to the driver

    ARGUMENTS:  sd  - Scsi Device to handle the IOCTL
                cmd - command number for the IOCTL
                arg - raw buffer for the IOCTL data

    RETURNS:    0 on success, negative errno on failure

****************************************************************************/

int atto_ioctl_handler (void *hostdata, int cmd, void *arg)
{
    int rez;
    int size;
    void *ioctl_data = NULL;

#ifdef ESASHBA
    /* Check for an  ATA IOCTL that we need to process specially */

    if ( cmd >= ATA_IOCTL_MIN 
      && cmd <= ATA_IOCTL_MAX )
        size = OsAtaGetIoctlSize (cmd);
    else
#endif
    size = OsGetIoctlSize (cmd, arg);

    ATTO_LOG (KERN_INFO, ATTO_LOG_IOCTL, "ioctl (%p, %x, %p)\n",
              hostdata, cmd, arg);

    /* If OsGetIoctlSize returns -1, that means its not an ATTO-specific    */
    /* cmd, so we'll just return error.                                     */
    /* Some HDIO IOCTL types arrive that are only supported by IDE devices- */
    /* we reject these with a code of "not implemented".                    */

    if ( size == ATTO_NOT_IMPLMNTD 
      || size == -1 )
        return -EINVAL;

    /* Make sure we can r/w to the user-space memory */

    if (size)
    {
        if (!access_ok (VERIFY_WRITE, arg, size))
        {
            ATTO_LOG (KERN_WARNING, ATTO_LOG_IOCTL,
                      "ioctl_handler access_ok failed for cmd %d, address %p, size %d\n",
                      cmd, arg, size);

            return -EFAULT;
        }

        /* Allocate a kernel memory buffer for the IOCTL data */

        if ((ioctl_data = vmalloc (size)) == NULL)
        {
            ATTO_LOG (KERN_WARNING, ATTO_LOG_IOCTL, 
                      "ioctl_handler vmalloc failed for %d bytes\n", size);

            return -EFAULT;
        }

        /* Copy the user-space memory into the kernel memory buffer */

        /* Note that some HDIO IOCTLs pass arg directly as data, instead of */
        /* as a pointer, so we'll make an exception for them.               */

#if defined(ESASHBA)
        if ( cmd == HDIO_SET_MULTCOUNT
          || cmd == HDIO_SET_PIO_MODE )
        {
            *((long*)ioctl_data) = (long)arg;
        }
        else if ( cmd == HDIO_GET_MULTCOUNT )
        {
            ioctl_data = NULL;
        }
        else 
#endif
        if (__copy_from_user (ioctl_data, arg, size) != 0)
        {
            ATTO_LOG (KERN_WARNING, ATTO_LOG_IOCTL,
                      "copy_from_user didn't copy everything\n");
            vfree (ioctl_data);

            return -EFAULT;
        }
    }

#if defined(ESASHBA) && LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0)

/* Handling all of the ATA IOCTLs requires scsi subsystem code that only    */
/* exists in a 2.6 kernel.                                                  */

    if ( cmd >= ATA_IOCTL_MIN && cmd <= ATA_IOCTL_MAX )
    {
        rez = OsAtaProcessIoctl( cmd, ioctl_data, 
                                (Scsi_Device*) hostdata, arg );

        if ( rez < 0 )
        {
            if (ioctl_data) 
                vfree (ioctl_data);
            return rez;
        }
    }
    else
#endif /* defined(ESASHBA) && LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0) */

    /* Call the IOCTL handler */

    if ((rez = OsIoctl (hostdata, cmd, ioctl_data)) < 0)
    {
        if (ioctl_data) vfree (ioctl_data);
        return rez;
    }

    /* See if the handler needs us to copy the buffer back */

    if ((rez == OSIOCTL_COPY_BACK) && size)
    {
        if (__copy_to_user (arg, ioctl_data, size) != 0)
        {
            ATTO_LOG (KERN_WARNING, ATTO_LOG_IOCTL,
                      "ioctl_handler copy_to_user didn't copy everything\n");
            if (ioctl_data) vfree (ioctl_data);

            return -EFAULT;
        }
    }

    if (ioctl_data) vfree (ioctl_data);

    return 0;
}

int atto_ioctl (Scsi_Device *sd, int cmd, void *arg)
{
#ifdef ESASHBA
#define EXPRESS_IOCTL_GET_ID 0x450E

    if ( ( cmd >= ATA_IOCTL_MIN 
      && cmd <= ATA_IOCTL_MAX )
    ||  cmd == EXPRESS_IOCTL_GET_ID)
    {
        if (arg == NULL
         && cmd != HDIO_SET_MULTCOUNT
         && cmd != HDIO_SET_PIO_MODE
         && cmd != HDIO_DRIVE_RESET )
            return -EINVAL;

        return atto_ioctl_handler (sd, cmd, arg);
    }
#endif

    return atto_ioctl_handler (sd->host->hostdata, cmd, arg);

}


/****************************************************************************

    FUNCTION:   int atto_queuecommand (Scsi_Cmnd *cmd,
                                       void (*done)(Scsi_Cmnd *))

    PURPOSE:    Enqueue a SCSI command

    ARGUMENTS:  cmd  - SCSI command to enqueue
                done - completion routine

    RETURNS:    0 on success, 1 on failure

****************************************************************************/

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,37)
int atto_queuecommand (Scsi_Cmnd *cmd, void (*done)(Scsi_Cmnd *))
#else
int atto_queuecommand (struct Scsi_Host *host, struct scsi_cmnd *cmd)
#endif
{
    int rez;
    void *hostdata = CMD_HOST(cmd)->hostdata;
    unsigned int target_id;
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,25)
    int use_sg = cmd->use_sg;
    struct scatterlist *list = (struct scatterlist *) cmd->request_buffer;
    struct pci_dev *pdev     = GetPciDevFromHostData (hostdata);
    int dir = scsi_to_pci_dma_dir (cmd->sc_data_direction);

#else /* LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,25) */
    int use_sg = scsi_dma_map (cmd);
#endif /* LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,25) */

#if defined (__VMKLNX__)
    struct Scsi_Host *host = CMD_HOST(cmd);
    int cpu_id = (int)(unsigned long)vmklnx_scsi_get_cmd_ioqueue_handle(cmd, host);
#elif LINUX_VERSION_CODE >=  KERNEL_VERSION(2,6,28)
    int cpu_id = (cmd->request->cpu < 0) ? smp_processor_id () : cmd->request->cpu;
#else
    int cpu_id = smp_processor_id ();
#endif

#if defined (ATTO_RPORTS)
    struct fc_rport *rport;
#endif

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,37)
    cmd->scsi_done = done;
#endif


#if defined (ATTO_RPORTS)

#ifdef TARGET_MODE
    if (initiator_mode == 0)
    {
        cmd->result = DID_NO_CONNECT << 16;
        LinuxScsiDone (cmd);
        return 0;
    }
#endif
#ifdef ATTO_AS_STACK_SUPPORT
    if (third_party_stack)
    {
        cmd->result = DID_NO_CONNECT << 16;
        LinuxScsiDone (cmd);
        return 0;
    }
#endif

    rport = starget_to_rport(scsi_target(cmd->device));
    if (use_transport_layer)
    {
        int err;

        err = fc_remote_port_chkready(rport);
        if (err)
        {
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,37) && defined (USE_ATTO_LOG)
            struct Scsi_Host *host = CMD_HOST(cmd);
#endif

            ATTO_DEV_LOG (KERN_INFO, ATTO_LOG_DEBUG, &(host->shost_gendev),
                          "fc_remote_port not ready. failing command\n");
            cmd->result = err;
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,37)
            done(cmd);
#else
            cmd->scsi_done(cmd);
#endif
            return 0;
        }
    }
#endif

    /* Override allowed retry count */

    if (cmd->allowed < cmd_retry_count)
        cmd->allowed = cmd_retry_count;

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,25)
    /* Map SG list, if any. */

    if (use_sg)
    {
#ifdef ATTO_USE_KERNEL24_SCSI_TAPE_WORKAROUND
        /* There is a bug in the 2.4 SCSI Tape driver which can result in */
        /* a malformed scatterlist for tape requests. This leads to a     */
        /* kernel panic when the x86_64 version of pci_map_sg validates   */
        /* the request's scatterlist structure. As a workaround, we will  */
        /* just map and unmap the scatterlist entries individually.       */

        int i;
        struct scatterlist *tmp_list = list;

        for (i = 0; i < use_sg; i++, tmp_list++)
        {
            void *address = tmp_list->address;

            if (!address)
                address = page_address (tmp_list->page) + tmp_list->offset;

            tmp_list->dma_address = pci_map_single (pdev, address, 
                                                    tmp_list->length, dir);
        }
#else /* NOT ATTO_USE_KERNEL24_SCSI_TAPE_WORKAROUND */

        if (OsUnlikely (pci_map_sg (pdev, list, use_sg, dir) != use_sg))
        {
            ATTO_LOG (KERN_WARNING, ATTO_LOG_TARG,
                      "queuecommand: pci_map_sg returned bad value\n");
            return 1;
        }

#endif /* NOT ATTO_USE_KERNEL24_SCSI_TAPE_WORKAROUND */

    }

#endif /* LINUX_VERSION_CODE < KERNEL_VERSION(2,6,25) */

    /* Assume success, if it fails we will fix the result later. */

    cmd->result = DID_OK << 16;

    target_id = atto_target_id(cmd);

    /* Start it up. */
    rez = OsStartCommand (hostdata, cmd,
                          target_id, CMD_LUN(cmd), CMD_TAGS(cmd), cpu_id);

    if (OsLikely (rez == OSSC_SUCCESS))
    {
        /* All good */
        return 0;
    }

    /* Failed, unmap the SG if present. */

    if (use_sg)
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,25)
        LinuxPciUnmapSg (cmd);
#else
        scsi_dma_unmap (cmd);
#endif

    if (rez == OSSC_BUSY)
    {
        /* Core is out of resources, the OS will retry later */

        return 1;
    }
    else if (rez == OSSC_SEL_TIMEOUT)
    {
        /* Core has immediately rejected the request, */
        /* because there is no device at that address */
        cmd->result = DID_NO_CONNECT << 16;
        LinuxScsiDone (cmd);
    }
    else
        ATTO_LOG (KERN_WARNING, ATTO_LOG_TARG,
                  "queuecommand: invalid return from OsStartCommand (%d)!\n",
                  rez);

    return 0;
}

/****************************************************************************

    FUNCTION:   enum blk_eh_timer_return atto_eh_timed_out (Scsi_Cmnd *cmd)

    PURPOSE:    Handle a timed out scsi command

    ARGUMENTS:  cmd  - SCSI command that timed out

    RETURNS:    BLK_EH_RESET_TIMER to give the command more time to complete

****************************************************************************/

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,27)
enum blk_eh_timer_return atto_eh_timed_out (Scsi_Cmnd *cmd)
{
    unsigned int target_id = atto_target_id(cmd);
    void *hostdata = CMD_HOST(cmd)->hostdata;

    if ( !OsCmdHandled(hostdata, target_id, cmd))
    {
        ATTO_DEV_LOG (KERN_INFO, ATTO_LOG_SCSI, &(CMD_HOST(cmd)->shost_gendev),
                      "atto_eh_timed_out cmd:%p. BLK_EH_NOT_HANDLED\n", cmd);
        return BLK_EH_NOT_HANDLED;
    }
    else
    {
        ATTO_DEV_LOG (KERN_INFO, ATTO_LOG_SCSI, &(CMD_HOST(cmd)->shost_gendev),
                      "atto_eh_timed_out cmd:%p. BLK_EH_RESET_TIMER\n", cmd);
        return BLK_EH_RESET_TIMER;
    }
}
#endif


#if 0
/* Eventually we may want to use these functions to release the host_lock */
/* while handling task management.  For now we'll just leave it.          */
/* #if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0)                        */
/* #if LINUX_VERSION_CODE <  KERNEL_VERSION(2,6,13)                       */
#define UnlockHost(_cmd)  spin_unlock_irq ((_cmd)->device->host->host_lock)
#define LockHost(_cmd)    spin_lock_irq   ((_cmd)->device->host->host_lock)
#else
#define UnlockHost(_cmd)
#define LockHost(_cmd)
#endif

/****************************************************************************

    FUNCTION:   int atto_eh_abort (Scsi_Cmnd *cmd)

    PURPOSE:    Abort an outstanding command

    ARGUMENTS:  cmd - SCSI command to abort

    RETURNS:    SUCCESS or FAILED

****************************************************************************/

int atto_eh_abort (Scsi_Cmnd *cmd)
{
    UnlockHost (cmd);
    ATTO_LOG (KERN_INFO, ATTO_LOG_TASKM, "eh_abort (%p)\n", cmd);

    if (OsAbortCommand (CMD_HOST(cmd)->hostdata, cmd))
    {
        ATTO_LOG (KERN_INFO, ATTO_LOG_TASKM, "eh_abort (%p) done\n", cmd);
        LockHost (cmd);
        return SUCCESS;
    }

    ATTO_LOG (KERN_INFO, ATTO_LOG_TASKM, "eh_abort (%p) failed\n", cmd);
    LockHost (cmd);
    return FAILED;
}


/****************************************************************************

    FUNCTION:   int atto_host_reset (Scsi_Cmnd *cmd)
                int atto_bus_reset (Scsi_Cmnd *cmd)
                int atto_device_reset (Scsi_Cmnd *cmd)
                int atto_target_reset (Scsi_Cmnd *cmd)

    PURPOSE:    Reset the host, bus, or device

    ARGUMENTS:  cmd   - SCSI command that caused the reset

    RETURNS:    SUCCESS or FAILED

****************************************************************************/

int atto_host_reset (Scsi_Cmnd *cmd)
{
    UnlockHost (cmd);
    
    ATTO_LOG (KERN_INFO, ATTO_LOG_TASKM, "host_reset (%p)\n", cmd);

    if (OsHostReset (CMD_HOST(cmd)->hostdata))
    {
        LockHost (cmd);
        return SUCCESS;
    }

    LockHost (cmd);
    return FAILED;
}

int atto_bus_reset (Scsi_Cmnd *cmd)
{
    UnlockHost (cmd);
    ATTO_LOG (KERN_INFO, ATTO_LOG_TASKM, "bus_reset (%p)\n", cmd);

    if (OsBusReset (CMD_HOST(cmd)->hostdata))
    {
        ATTO_LOG (KERN_INFO, ATTO_LOG_TASKM, "bus_reset (%p) done\n", cmd);
        LockHost (cmd);
        return SUCCESS;
    }

    LockHost (cmd);
    return FAILED;
}

#ifndef _MP_

int atto_device_reset (Scsi_Cmnd *cmd)
{
#ifdef __VMKLNX__
    UnlockHost (cmd);

    if ((cmd->vmkflags & VMK_FLAGS_USE_LUNRESET) == 0)
    {
        ATTO_LOG (KERN_INFO, ATTO_LOG_TASKM, "target_reset (%p)\n", cmd);

        /* Execute a target reset because the caller requested it */
        if (OsTargetReset (CMD_HOST(cmd)->hostdata, 
                           CMD_TARG(cmd), CMD_LUN(cmd)))
        {
            ATTO_LOG (KERN_INFO, ATTO_LOG_TASKM, "target_reset (%p) done\n",
                      cmd);
            LockHost (cmd);
            return SUCCESS;
        }
    }
    else
    {
        ATTO_LOG (KERN_INFO, ATTO_LOG_TASKM, "device_reset (%p:%d:%d)\n",
                  cmd, CMD_TARG(cmd), CMD_LUN(cmd));

        if (OsDeviceReset (CMD_HOST(cmd)->hostdata,
                           CMD_TARG(cmd), CMD_LUN(cmd)))
        {
            ATTO_LOG (KERN_INFO, ATTO_LOG_TASKM, "device_reset (%p) done\n",
                      cmd);
            LockHost (cmd);
            return SUCCESS;
        }
    }

    LockHost (cmd);
    return FAILED;        

#else /* NOT __VMKLNX__ */

    int result = 0;

    ATTO_LOG (KERN_INFO, ATTO_LOG_TASKM, "device_reset (%p)\n", cmd);

    UnlockHost (cmd);

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,26)
    if (!old_device_reset)
        result = OsTargetReset (CMD_HOST(cmd)->hostdata, CMD_TARG(cmd), CMD_LUN(cmd));
    else
#else
    result = OsDeviceReset (CMD_HOST(cmd)->hostdata, CMD_TARG(cmd), CMD_LUN(cmd));
#endif

    ATTO_LOG (KERN_INFO, ATTO_LOG_TASKM, "device_reset (%p) result %d\n"
              , cmd, result);
    LockHost (cmd);
    return (result ? SUCCESS : FAILED);

#endif /* NOT __VMKLNX__ */
}

int atto_target_reset (Scsi_Cmnd *cmd)
{
    int result;

    ATTO_LOG (KERN_INFO, ATTO_LOG_TASKM, "target_reset (%p)\n", cmd);

    UnlockHost (cmd);

    result = OsTargetReset (CMD_HOST(cmd)->hostdata, CMD_TARG(cmd), CMD_LUN(cmd));

    ATTO_LOG (KERN_INFO, ATTO_LOG_TASKM, "target_reset (%p) result %d\n",
              cmd, result);

    LockHost (cmd);
    return (result ? SUCCESS : FAILED);
}

#endif  /* !_MP_ */


#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,11)
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,33) && LINUX_VERSION_CODE < KERNEL_VERSION(3,19,0)) || defined(ATTO_RHEL6) || defined(ATTO_SLES11SP1)
int atto_change_queue_depth (Scsi_Device *dev, int depth, int reason)
#else
int atto_change_queue_depth (Scsi_Device *dev, int depth)
#endif
{
    ATTO_LOG (KERN_INFO, ATTO_LOG_DEBUG, "change_queue_depth %p, %d\n",
              dev, depth);

#if LINUX_VERSION_CODE < KERNEL_VERSION(3,19,0)
    scsi_adjust_queue_depth (dev, scsi_get_tag_type (dev), depth);
#else
    scsi_change_queue_depth (dev, depth);
#endif

    return dev->queue_depth;
}


#if LINUX_VERSION_CODE < KERNEL_VERSION(3,19,0)
int atto_change_queue_type (Scsi_Device *dev, int type)
{
    ATTO_LOG (KERN_INFO, ATTO_LOG_DEBUG, "change_queue_type %p, %d\n",
              dev, type);

    if (dev->tagged_supported)
    {
#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,10)
        scsi_set_tag_type (dev, type);
#endif

        if (type)
            scsi_activate_tcq (dev, dev->queue_depth);
        else
            scsi_deactivate_tcq (dev, dev->queue_depth);
    }
    else
        type = 0;

    return type;
}
#endif
#endif


#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0)

/****************************************************************************

    FUNCTION:   int atto_slave_alloc (Scsi_Device *dev)
                int atto_slave_configure (Scsi_Device *dev)
                void atto_slave_destroy (Scsi_Device *dev)

    PURPOSE:    Allocate, configure, and destroy SCSI devices

    ARGUMENTS:  dev - SCSI device

    RETURNS:    0 on success, -errno on error

    NOTES:      If using SAS ports (Linux SAS Transport), find the
                ESAS device for this SCSI device and save a link
                in the hostdata. This lets us easily map back to the HW
                layer's target ID during I/O.

****************************************************************************/

int atto_slave_alloc (Scsi_Device *dev)
{
    ATTO_DEV_LOG (KERN_INFO, ATTO_LOG_TARG, &(dev->sdev_gendev),
                  "atto_slave_alloc()\n");

#if defined (_MP_) && LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,27)

    /* If the scsi device handler is not set, install a NULL one         */
    /* called 'proprietary' to prevent another one (alua, rdac, etc.)    */
    /* from being used and conflicting with our proprietary MP solution. */
    if (dev->scsi_dh_data == NULL)
    {
        struct scsi_device_handler *dh = kmalloc (sizeof(*dh), GFP_ATOMIC);

	if (dh)
	{
            struct scsi_dh_data *dh_data = kmalloc (sizeof(*dh_data), GFP_ATOMIC);

	    if (dh_data)
	    {
                memset (dh, 0, sizeof(*dh));
                dh->name = "proprietary";

                memset (dh_data, 0, sizeof(*dh_data));
	        dh_data->scsi_dh = dh;
		dev->scsi_dh_data = dh_data;
		
		ATTO_DEV_LOG (KERN_INFO, ATTO_LOG_TARG, &(dev->sdev_gendev),
			      "proprietary scsi_dh_data: %p\n",
                              dev->scsi_dh_data);
	    }
            else
            {
                kfree(dh);
            }
	}
    }
#endif /* defined(_MP_) && LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,27) */

#if defined (ATTO_RPORTS)
    if (use_transport_layer)
    {
        struct fc_rport *rport = starget_to_rport(scsi_target(dev));
        int rc;

        /* When using FC Transport, check the remote port. Returning */
        /* an error at this point stops the midlayer from doing bad  */
        /* things with an invalid port/target.                       */

        if (!rport)
        {
            ATTO_DEV_LOG (KERN_INFO, ATTO_LOG_TARG, &(dev->sdev_gendev),
                          "no rport found\n");
            return -ENXIO;
        }

        rc = fc_remote_port_chkready (rport);

        if (rc)
        {
            ATTO_DEV_LOG (KERN_INFO, ATTO_LOG_TARG, &(dev->sdev_gendev),
                          "fc_remote_port_checkready: %d\n ", rc);
            return -ENXIO;
        }
    }
#endif

#if defined (ATTO_SAS_PORTS)
    if (use_transport_layer)
    {
        PESASTOPOLOGY    etop;
        PESASDEVICE      edev;
        struct Scsi_Host *sh;
        struct sas_rphy  *rphy;

        sh = dev->host;
        etop = esas_topology_by_host_no (sh->host_no);
        if (!etop)
        {
            printk (DEBUG_HEADER "Unable to find SAS Topology for host %d\n",
                sh->host_no);
            return -ENXIO;
        }

        rphy = dev_to_rphy (dev->sdev_target->dev.parent);
        if (!rphy)
        {
            printk (DEBUG_HEADER "Unable to find rphy for device %p\n",
                    dev->sdev_target->dev.parent);
            return -ENXIO;
        }

        edev = esas_device_by_address (etop, rphy->identify.sas_address);
        if (!edev)
        {
            printk (DEBUG_HEADER "Unable to find esas device 0x%llx\n",
                    rphy->identify.sas_address);
            return -ENXIO;
        }

        ATTO_DEV_LOG (KERN_INFO, ATTO_LOG_TOPOL, &(dev->sdev_gendev),
                      "atto_slave_alloc: hostdata for scsi device  0x%llx\n",
                      edev->sas_address);

        dev->hostdata = edev;
    }
#endif

    ATTO_DEV_LOG (KERN_INFO, ATTO_LOG_TARG, &(dev->sdev_gendev),
                  "slave_alloc OK\n");

    return 0;
}


int atto_slave_configure (Scsi_Device *dev)
{
    ATTO_DEV_LOG (KERN_INFO, ATTO_LOG_TARG, &(dev->sdev_gendev),
                  "atto_slave_configure()\n");

#if LINUX_VERSION_CODE < KERNEL_VERSION(3,19,0)
    if (dev->tagged_supported)
    {
#if defined(MSG_SIMPLE_TAG) && LINUX_VERSION_CODE > KERNEL_VERSION(2,6,10)
        scsi_set_tag_type (dev, MSG_SIMPLE_TAG);
#endif
        scsi_activate_tcq (dev, cmd_per_lun);
    }
    else
    {
#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,10)
        scsi_set_tag_type (dev, 0);
#endif
        scsi_deactivate_tcq (dev, cmd_per_lun);
    }
#endif

    return 0;
}


void atto_slave_destroy (Scsi_Device *dev)
{
    ATTO_DEV_LOG (KERN_INFO, ATTO_LOG_TARG, &(dev->sdev_gendev),
                  "atto_slave_destroy()\n");

#if defined (_MP_) && LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,27)

    if ( (dev->scsi_dh_data) 
      && (dev->scsi_dh_data->scsi_dh)
      && (!strncmp(dev->scsi_dh_data->scsi_dh->name, "proprietary", 11)) )
    {
        ATTO_DEV_LOG (KERN_INFO, ATTO_LOG_TARG, &(dev->sdev_gendev),
		      "proprietary scsi_dh_data free'd\n");

	kfree(dev->scsi_dh_data->scsi_dh);
	kfree(dev->scsi_dh_data);
    }

#endif /* defined (_MP_) && LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,27) */

#if defined (ATTO_SAS_PORTS)
    if (use_transport_layer)
    {
        dev->hostdata = NULL;
    }
#endif
}
#endif /* LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0) */


unsigned int atto_target_id (Scsi_Cmnd *cmd)
{
    unsigned int target_id;

#if defined (ATTO_RPORTS)
    struct fc_rport *rport = starget_to_rport(scsi_target(cmd->device));

    if (use_transport_layer)
        target_id = *((unsigned int *)(rport->dd_data));
    else
        target_id = CMD_TARG(cmd);
#elif defined (ATTO_SAS_PORTS)
    /* The SCSI device's hostdata is set up with a pointer to the ESAS */
    /* device corresponding to the SCSI target. That ESAS device       */
    /* maintains the HW layer target ID, so we use that here.          */
    /* See atto_slave_alloc().                                         */
    if (use_transport_layer && cmd->device && cmd->device->hostdata)
            target_id = ((PESASDEVICE)(cmd->device->hostdata))->target_id;
    else
            target_id = CMD_TARG(cmd);
#else
    target_id = CMD_TARG(cmd);
#endif

    return target_id;
}



#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0)
#define EXPORT_ATTOCFG_SYMBOL(_sym) EXPORT_SYMBOL (_sym)
#else
#define EXPORT_ATTOCFG_SYMBOL(_sym)
#endif

#if !defined (__VMKLNX__)
/* e.g., celerity16fcmp_attocfg_register */
EXPORT_ATTOCFG_SYMBOL ( ATTO_DRVR_SYM(attocfg_register) );
#endif


/* This double indirection is needed so that ATTO_DRVR_SYM is fully unrolled
 * by the time it is passed to the module_xxx() macro.
 */
#define DECLARE_MOD_ENTRY2(name, decl)  module_ ## name( decl )
#define DECLARE_MOD_ENTRY(name)         DECLARE_MOD_ENTRY2(name, \
                                                           ATTO_DRVR_SYM(name))


/* e.g., celerity16fcmp_init */
DECLARE_MOD_ENTRY( init );

/* e.g., celerity16fcmp_exit */
DECLARE_MOD_ENTRY( exit );


