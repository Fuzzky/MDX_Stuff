


/****************************************************************************
;
; NAME: atto_cfg.h
;
;
; DESCRIPTION:
;
;       Header file for the atto_cfg driver
;
;
; REVISION HISTORY:
;
;       $Log: /EsasHba4/Linux/driver/atto_cfg.h $
; 
; 11    11/07/13 10:02a Bgrove
; VSA IOCTL Support
; 
; 10    6/30/10 4:38p Jseba
; Define an hba_handler type for the ATTOCFG_HANDLERS structure
; 
; 9     6/18/10 10:32a Pcullen
; Added hw node to sysfs
; 
; 8     6/01/10 12:54p Mseier
; Added support for slot binding and bad block reporting
; 
; 7     3/01/10 2:25p Pcullen
; Updates for Celerity 8Gb Multipathing: added mp handler; rolled cfg
; version.
; 
; 6     5/22/08 2:14p Jseba
; Bumped ATTOCFG_VERSION
; 
; 5     4/24/08 11:34a Jseba
; Removed "file_version" stuff, version info is now embedded in main
; driver; bumped ATTOCFG_VERSION
; 
; 4     11/14/06 2:31p Jseba
; Add "fs" handlers for ESASRAID FS_API
; 
; 3     11/08/06 11:34a Jseba
; Interface version 3 - added VDA event notification and de-registration
; 
; 2     10/09/06 9:51a Jseba
; Added ESASRAID VDA node support; bumped ATTOCFG_VERSION
; 
; 1     1/03/06 10:47a Jseba
; Initial submission
; 
; COPYRIGHT (c) ATTO TECHNOLOGY, INC. 2006
; ALL RIGHTS RESERVED.
;
;***************************************************************************/

/* Version of the interface.  Increment this when the structure changes. */

#define ATTOCFG_VERSION  8

typedef struct attocfg_handlers *PATTOCFG_HANDLERS;

typedef int (*attocfg_register_host_callback) (void *context,
                                               struct kobject *kobj,
                                               PATTOCFG_HANDLERS handlers);

typedef void (*drvr_attocfg_unregister) (void);

typedef int (*attocfg_init_async_event_sockets) (void);

typedef int (*attocfg_fire_async_event) (void *data, int len);

/* Structure to register attocfg */

typedef struct attocfg_register
{
    int             version;  /* Better be ATTOCFG_VERSION     */
    void           *context;  /* attocfg context for callbacks */

    attocfg_register_host_callback    attocfg_register_host;
    attocfg_init_async_event_sockets  init_async_event_sockets;
    attocfg_fire_async_event          fire_vda_event;
    attocfg_fire_async_event          fire_bb_event;

    /* Following are filled in by the HBA driver */
    /* before successfully completing the call.  */

    drvr_attocfg_unregister attocfg_unregister;

} ATTOCFG_REGISTER, *PATTOCFG_REGISTER;


typedef ssize_t (*hba_handler) (struct kobject *kobj,
                                char           *buf,
                                loff_t          off,
                                size_t          count,
                                int             operation);

typedef struct attocfg_handlers
{
    /* HBA driver callback functions */

    hba_handler hba_nvram_handler;
#define ATTOCFG_DEFAULT_NVRAM  1
#define ATTOCFG_READ_NVRAM     2
#define ATTOCFG_WRITE_NVRAM    3

    hba_handler hba_fw_handler;
#define ATTOCFG_READ_FW        4
#define ATTOCFG_WRITE_FW       5

    hba_handler hba_vda_handler;
#define ATTOCFG_READ_VDA       6
#define ATTOCFG_WRITE_VDA      7

    hba_handler hba_fs_handler;
#define ATTOCFG_READ_FS        8
#define ATTOCFG_WRITE_FS       9

    hba_handler hba_mp_handler;
#define ATTOCFG_READ_MP        10
#define ATTOCFG_WRITE_MP       11

    hba_handler hba_hw_handler;
#define ATTOCFG_READ_HW        12
#define ATTOCFG_WRITE_HW       13

    hba_handler hba_vsa_handler;
#define ATTOCFG_READ_VSA       14
#define ATTOCFG_WRITE_VSA      15

} ATTOCFG_HANDLERS;


/* Callback function to register attocfg */
/* attocfg uses intermodule_get to find  */
/* known ATTO HBA drivers, and calls     */
/* their registration functions with an  */
/* ATTO_HANLDERS structure.  The HBA     */
/* driver registers each of its hosts,   */
/* and then returns 1 on success.        */

typedef int (*attocfg_register_callback) (PATTOCFG_REGISTER reg);
