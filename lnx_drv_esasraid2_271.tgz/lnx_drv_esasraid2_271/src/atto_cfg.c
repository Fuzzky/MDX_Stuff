


/****************************************************************************
;
; NAME: atto_cfg.c
;
;
; DESCRIPTION:
;
;       Driver to discover ATTO HBAs for the Configuration Tool
;
;
; REVISION HISTORY:
;
;       $Log: /pcidrv/source/shared/linux/driver/atto_cfg.c $
; 
; 40    7/29/15 3:30p Bgrove
; Fir for 4.1+ kernels.  sock_sendmsg no longer requires size argument.
; 
; 38    2/26/15 3:46p Jseba
; Updates for kernels 3.19 and 4.0
; 
; 37    7/25/14 1:06p Pcullen
; Added logging to attocfg driver and fixed locking problem when read
; occurs before write for a different process id.
; 
; 36    10/03/13 4:12p Jseba
; Renamed BIN_ATTR to avoid a collision with a similar macro recently
; added to the kernel header files.
; 
; 35    9/25/13 11:27a Pcullen
; Added 12Gb ESASHBA4 Support
; 
; 34    7/09/13 4:28p Bgrove
; Use new proc api for compatability with 3.10 kernel
; 
; 33    9/14/12 1:00p Pcullen
; IR 8589 - Make errors when attempting to install driver in SUSE 10. The
; 2.6.16 kernel in SUSE 10 does not define a 'bool' type. The pci_device
; also does not contain msi/msix_enabled.
; 
; 32    8/22/12 10:50a Jseba
; Change locking to avoid holding the lock while sleeping (IR 8494)
; 
; 31    4/27/12 1:17p Pcullen
; CELERITY16FC support
; 
; 30    7/28/11 4:51p Jseba
; Support for ESAS3HBA; fix a harmless build warning
; 
; 29    1/12/11 8:55a Jseba
; Fixes for newer kernels
; 
; 28    1/06/11 10:37a Jseba
; Updated copyright information
; 
; 27    11/17/10 2:56p Jseba
; Fixes for Red Hat 6
; 
; 26    8/10/10 3:35p Jseba
; Fixed incompatibility with 2.6.35; added FastFrame support
; 
; 25    6/30/10 4:41p Jseba
; For handlers that require it, added spinlocks to ensure serialized
; access, and added a check that the process doing a read was the last
; process to do a write (IR 7031)
; 
; 24    6/18/10 10:32a Pcullen
; Added hw node to sysfs
; 
; 23    6/07/10 9:57a Pcullen
; Fixed compiler warning when using debug
; 
; 22    6/01/10 12:54p Mseier
; Added support for slot binding and bad block reporting
; 
; 21    4/14/10 1:31p Mseier
; Updates for ESASRAID2 project.
; 
; 20    3/01/10 2:24p Pcullen
; Updates for Celerity 8Gb Multipathing: handle mp async events.
; 
; 19    10/07/08 4:47p Jseba
; ESAS2HBA support
; 
; 18    8/14/08 10:17a Jseba
; Fixes for 2.6.26
; 
; 17    5/22/08 2:16p Jseba
; Use module_init/exit; change return value of attocfg register function
; 
; 16    4/24/08 11:33a Jseba
; Removed "file_version" stuff, version info is now embedded in main
; driver
; 
; 15    4/17/08 4:50p Jseba
; CELERITYFC2 is now CELERITY8FC
; 
; 14    2/19/08 10:57a Jseba
; Add CELERITYFC2 support; create "/proc/attocfg" to allow manual rescans
; for new hosts
; 
; 13    1/25/08 4:25p Jseba
; Fix function declarations for 2.6.22 and up
; 
; 12    8/06/07 3:19p Jseba
; Support for ESASHBA driver
; 
; 11    4/27/07 4:53p Jseba
; Pick up errors from sysfs_create calls
; 
; 10    4/02/07 11:30a Jseba
; Fixed work_struct stuff for 2.6.20 kernel
; 
; 9     3/14/07 4:40p Jseba
; Only include config.h if ATTO_USE_CONFIG_H is defined
; 
; 8     2/27/07 11:10a Jseba
; Don't call vfree with IRQs disabled
; 
; 7     2/20/07 2:48p Jseba
; Add code to queue VDA events and schedule a non-interrupt context task
; to send them
; 
; 6     11/14/06 2:31p Jseba
; Add "fs" handlers for ESASRAID FS_API
; 
; 5     11/08/06 11:34a Jseba
; Interface version 3 - added VDA event notification and de-registration
; 
; 4     10/09/06 9:50a Jseba
; Added ESASRAID VDA node support
; 
; 3     9/20/06 9:55a Jseba
; Support for EXPRESS2 driver
; 
; 2     8/28/06 11:13a Jseba
; Support for ESASRAID driver
; 
; 1     1/03/06 10:47a Jseba
; Initial submission
; 
; 
; 
;
;
; Released under GPL v2
;
; COPYRIGHT (c) ATTO TECHNOLOGY, INC. 1/03/06 - $JustDate:  7/29/15 $
; ALL RIGHTS RESERVED.
;
;***************************************************************************/

#ifdef ATTO_USE_CONFIG_H
#include <linux/config.h>
#endif
#define EXPORT_SYMTAB

#ifndef LINUX_VERSION_CODE
#include <linux/version.h>
#endif

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,5,0)
#include <linux/modversions.h>
#endif

#include <linux/kernel.h>
#include <linux/moduleparam.h>
#include <linux/module.h>
#include <linux/device.h>
#include <linux/vmalloc.h>
#include <linux/socket.h>
#include <linux/net.h>
#include <linux/in.h>
#include <linux/workqueue.h>
#include <net/sock.h>
#ifdef CONFIG_PROC_FS
#include <linux/proc_fs.h>
#endif

#include "atto_cfg.h"
#include "attolog.h"

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0)
#error !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
#error !!! This driver will only work on version 2.6.x or 3.x of the Linux kernel !!!
#error !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
#endif

MODULE_DESCRIPTION ("ATTO Configuration Tool driver");
MODULE_AUTHOR ("ATTO Technology");
MODULE_LICENSE("GPL");

#ifdef USE_ATTO_LOG
#define ATTO_DRVR_NAME "attocfg"
unsigned long atto_log_mask;
unsigned long atto_log_start;
module_param (atto_log_mask, ulong, S_IRUGO | S_IRUSR);
#endif /* USE_ATTO_LOG */

void scan_for_hba_drivers (void);

/* Global structures to track drivers and hosts */

typedef struct _attocfg_host       *PATTOCFG_HOST;
typedef struct _attocfg_hba_driver *PATTOCFG_HBA_DRVR;

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,18)
typedef unsigned char bool;
#endif

typedef struct _attocfg_host
{
    PATTOCFG_HBA_DRVR driver;
    PATTOCFG_HOST     next;
    ATTOCFG_HANDLERS  handlers;
    struct kobject   *kobj;

    /* Some of the handlers require a write followed by a read from a single */
    /* application.  In order to prevent other apps from reading after the   */
    /* write and maybe causing trouble, save the PID on write and only allow */
    /* that PID to perform any subsequent reads.                             */

    pid_t             vda_pid;
    pid_t             fw_pid;
    pid_t             fs_pid;
    pid_t             mp_pid;
    pid_t             hw_pid;

    /* We also need to implement locks so only one read or write request can */
    /* be in progress at a time.                                             */

    spinlock_t        vda_lock;
    bool              vda_in_use;
    spinlock_t        fw_lock;
    bool              fw_in_use;
    spinlock_t        fs_lock;
    bool              fs_in_use;
    spinlock_t        mp_lock;
    bool              mp_in_use;
    spinlock_t        hw_lock;
    bool              hw_in_use;
    spinlock_t        nvr_lock;
    bool              nvr_in_use;

} ATTOCFG_HOST;

#define ATTO_DRVR_NONE           0

#define ATTO_DRVR_CELERITYFC     1
extern attocfg_register_callback celerityfc_attocfg_register;

#define ATTO_DRVR_ESASRAID       2
extern attocfg_register_callback esasraid_attocfg_register;

#define ATTO_DRVR_EXPRESS2       3
extern attocfg_register_callback express2_attocfg_register;

#define ATTO_DRVR_ESASHBA        4
extern attocfg_register_callback esashba_attocfg_register;

#define ATTO_DRVR_CELERITY8FC    5
extern attocfg_register_callback celerity8fc_attocfg_register;

#define ATTO_DRVR_ESAS2HBA       6
extern attocfg_register_callback esas2hba_attocfg_register;

#define ATTO_DRVR_CELERITYFCMP   7
extern attocfg_register_callback celerityfcmp_attocfg_register;

#define ATTO_DRVR_CELERITY8FCMP  8
extern attocfg_register_callback celerity8fcmp_attocfg_register;

#define ATTO_DRVR_ESAS2RAID      9
extern attocfg_register_callback esas2raid_attocfg_register;

#define ATTO_DRVR_FASTFRAME      10
extern attocfg_register_callback fastframe_attocfg_register;

#define ATTO_DRVR_ESAS3HBA       11
extern attocfg_register_callback esas3hba_attocfg_register;

#define ATTO_DRVR_CELERITY16FC   12
extern attocfg_register_callback celerity16fc_attocfg_register;

#define ATTO_DRVR_CELERITY16FCMP  13
extern attocfg_register_callback celerity16fcmp_attocfg_register;

#define ATTO_DRVR_ESAS4HBA       14
extern attocfg_register_callback esas4hba_attocfg_register;



typedef struct _attocfg_hba_driver
{
    int                      type;
    PATTOCFG_HOST            hosts;
    drvr_attocfg_unregister  attocfg_unregister;
} ATTOCFG_HBA_DRVR;

ATTOCFG_HBA_DRVR hba_drvr [] =
{
    {ATTO_DRVR_CELERITYFC,    NULL, NULL},
    {ATTO_DRVR_ESASRAID,      NULL, NULL},
    {ATTO_DRVR_EXPRESS2,      NULL, NULL},
    {ATTO_DRVR_ESASHBA,       NULL, NULL},
    {ATTO_DRVR_CELERITY8FC,   NULL, NULL},
    {ATTO_DRVR_ESAS2HBA,      NULL, NULL},
    {ATTO_DRVR_CELERITYFCMP,  NULL, NULL},
    {ATTO_DRVR_CELERITY8FCMP, NULL, NULL},
    {ATTO_DRVR_ESAS2RAID,     NULL, NULL},  
    {ATTO_DRVR_FASTFRAME,     NULL, NULL},
    {ATTO_DRVR_ESAS3HBA,      NULL, NULL},  
    {ATTO_DRVR_CELERITY16FC,  NULL, NULL},
    {ATTO_DRVR_CELERITY16FCMP,NULL, NULL},
    {ATTO_DRVR_ESAS4HBA,      NULL, NULL},
    {ATTO_DRVR_NONE,          NULL, NULL}
};


/****************************************************************************

    FUNCTION:   PATTOCFG_HOST attocfg_find_host_by_kobj (struct kobject *kobj)

    PURPOSE:    Searches the list of registered hosts for a matching kobject

****************************************************************************/

PATTOCFG_HOST attocfg_find_host_by_kobj (struct kobject *kobj)
{
    PATTOCFG_HBA_DRVR this_drvr;

    for (this_drvr = hba_drvr;
         this_drvr->type != ATTO_DRVR_NONE;
         this_drvr++)
    {
        PATTOCFG_HOST host;

        for (host = this_drvr->hosts;
             host;
             host = host->next)
        {
            if (host->kobj == kobj)
                return host;
        }
    }

    return NULL;
}


/* Callback handlers */

static ssize_t attocfg_read_default_nvram (
#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,34) || defined(ATTO_RHEL6)
                                           struct file *file,
#endif
                                           struct kobject *kobj,
#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,22)
                                           struct bin_attribute *bin_attr,
#endif
                                           char *buf,
                                           loff_t off,
                                           size_t count)
{
    PATTOCFG_HOST host = attocfg_find_host_by_kobj (kobj);

    if (host && host->handlers.hba_nvram_handler)
    {
        ssize_t res = (*host->handlers.hba_nvram_handler) (kobj, buf, off, count, ATTOCFG_DEFAULT_NVRAM);
        ATTO_LOG (KERN_DEBUG, ATTO_LOG_SYSFS, "default nvram read, host %p, result %d\n", host, (int) res);
        return res;
    }
    else
        return 0;
}


static ssize_t attocfg_read_live_nvram (
#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,34) || defined(ATTO_RHEL6)
                                        struct file *file,
#endif
                                        struct kobject *kobj,
#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,22)
                                        struct bin_attribute *bin_attr,
#endif
                                        char *buf,
                                        loff_t off,
                                        size_t count)
{
    PATTOCFG_HOST host = attocfg_find_host_by_kobj (kobj);

    if (host && host->handlers.hba_nvram_handler)
    {
        ssize_t res = (*host->handlers.hba_nvram_handler) (kobj, buf, off, count, ATTOCFG_READ_NVRAM);
        ATTO_LOG (KERN_DEBUG, ATTO_LOG_SYSFS, "live nvram read, host %p, result %d\n", host, (int) res);
        return res;
    }
    else
        return 0;
}


static ssize_t attocfg_write_live_nvram (
#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,34) || defined(ATTO_RHEL6)
                                         struct file *file,
#endif
                                         struct kobject *kobj,
#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,22)
                                         struct bin_attribute *bin_attr,
#endif
                                         char *buf,
                                         loff_t off,
                                         size_t count)
{
    PATTOCFG_HOST host = attocfg_find_host_by_kobj (kobj);

    if (host && host->handlers.hba_nvram_handler)
    {
        if (spin_trylock (&host->nvr_lock))
        {
            int result;

            if (host->nvr_in_use)
            {
                spin_unlock (&host->nvr_lock);
                ATTO_LOG (KERN_INFO, ATTO_LOG_SYSFS, "live nvram write failed (in use), host %p\n", host);
                return -EBUSY;
            }

            host->nvr_in_use = 1;
            spin_unlock (&host->nvr_lock);

            result = (*host->handlers.hba_nvram_handler) (kobj, buf, off, count, ATTOCFG_WRITE_NVRAM);

            spin_lock (&host->nvr_lock);
            host->nvr_in_use = 0;
            spin_unlock (&host->nvr_lock);

            ATTO_LOG (KERN_DEBUG, ATTO_LOG_SYSFS, "live nvram write, host %p, result %d\n", host, (int) result);

            return result;
        }

        ATTO_LOG (KERN_INFO, ATTO_LOG_SYSFS, "live nvram write failed (locked), host %p\n", host);

        return -EBUSY;
    }

    return 0;
}


/* Some of these handlers need to be "locked" - that is, we need to serialize */
/* access to the underlying handler to prevent simultaneous read and/or write */
/* operations.  In addition, we need to ensure that reads are only successful */
/* when performed by the same process that did the previous write.  This      */
/* function fulfills both requirements through the "handle_locked" macros.    */

ssize_t handle_locked_rw (PATTOCFG_HOST   host,
                          struct kobject *kobj,
                          char           *buf,
                          loff_t          off,
                          size_t          count,
                          int             operation,
                          hba_handler    *handler,
                          spinlock_t     *lock,
                          bool           *in_use,
                          pid_t          *pid,
                          int             write)
{
    if (host && *handler)
    {
        if (spin_trylock (lock))
        {
            ssize_t result;

            if (*in_use)
            {
                spin_unlock (lock);
                ATTO_LOG (KERN_INFO, ATTO_LOG_SYSFS, "locked %s failed (in_use), host %p, current->pid %d, using pid %d\n",
                          (write) ? "write" : "read", host, (int) current->pid, (int) (*pid));
                return -EBUSY;
            }

            if (!write && current->pid != *pid)
            {
                spin_unlock (lock);
                ATTO_LOG (KERN_INFO, ATTO_LOG_SYSFS, "locked read failed (pid mismatch), host %p, current->pid %d, using pid %d\n",
                          host, (int) current->pid, (int) (*pid));
                return -EFAULT;
            }

            (*in_use) = 1;
            spin_unlock (lock);

            ATTO_LOG (KERN_DEBUG, ATTO_LOG_SYSFS, "locked %s about to perform, host %p, current->pid %d\n",
                      (write) ? "write" : "read", host, (int) current->pid);

            result = (**handler) (kobj, buf, off, count, operation);

            ATTO_LOG (KERN_DEBUG, ATTO_LOG_SYSFS, "locked %s, result %d, host %p, current->pid %d\n",
                      (write) ? "write" : "read", (int) result, host, (int) current->pid);

            if (write && result >= 0)
            {
                ATTO_LOG (KERN_INFO, ATTO_LOG_SYSFS, "read lock for pid %d, host %p\n",
                          (int) (*pid), host);
                *pid = current->pid;
            }

            spin_lock (lock);
            (*in_use) = 0;
            spin_unlock (lock);

            return result;
        }

        ATTO_LOG (KERN_INFO, ATTO_LOG_SYSFS, "locked %s failed (locked), host %p, current->pid %d, using pid %d\n",
                  (write) ? "write" : "read", host, (int) current->pid, (int) (*pid));

        return -EBUSY;
    }

    return 0;
}

#define handle_locked_read(_ho, _ko, _bu, _of, _co, _op, _ha, _lo, _iu, _pi) \
        handle_locked_rw(_ho, _ko, _bu, _of, _co, _op, _ha, _lo, _iu, _pi, 0)

#define handle_locked_write(_ho, _ko, _bu, _of, _co, _op, _ha, _lo, _iu, _pi) \
        handle_locked_rw(_ho, _ko, _bu, _of, _co, _op, _ha, _lo, _iu, _pi, 1)


static ssize_t attocfg_read_fw (
#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,34) || defined(ATTO_RHEL6)
                                struct file *file,
#endif
                                struct kobject *kobj,
#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,22)
                                struct bin_attribute *bin_attr,
#endif
                                char *buf,
                                loff_t off,
                                size_t count)
{
    PATTOCFG_HOST host = attocfg_find_host_by_kobj (kobj);

    ATTO_LOG (KERN_DEBUG, ATTO_LOG_SYSFS, "read_fw, host %p, off %d, count %d", host, (int) off, (int) count);

    return handle_locked_read (host,
                               kobj, buf, off, count, ATTOCFG_READ_FW,
                               &host->handlers.hba_fw_handler,
                               &host->fw_lock,
                               &host->fw_in_use,
                               &host->fw_pid);
}


static ssize_t attocfg_write_fw (
#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,34) || defined(ATTO_RHEL6)
                                 struct file *file,
#endif
                                 struct kobject *kobj,
#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,22)
                                 struct bin_attribute *bin_attr,
#endif
                                 char *buf,
                                 loff_t off,
                                 size_t count)
{
    PATTOCFG_HOST host = attocfg_find_host_by_kobj (kobj);

    ATTO_LOG (KERN_DEBUG, ATTO_LOG_SYSFS, "write_fw, host %p, off %d, count %d", host, (int) off, (int) count);

    return handle_locked_write (host,
                                kobj, buf, off, count, ATTOCFG_WRITE_FW,
                                &host->handlers.hba_fw_handler,
                                &host->fw_lock,
                                &host->fw_in_use,
                                &host->fw_pid);
}

static ssize_t attocfg_read_vda (
#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,34) || defined(ATTO_RHEL6)
                                 struct file *file,
#endif
                                 struct kobject *kobj,
#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,22)
                                 struct bin_attribute *bin_attr,
#endif
                                 char *buf,
                                 loff_t off,
                                 size_t count)
{
    PATTOCFG_HOST host = attocfg_find_host_by_kobj (kobj);

    ATTO_LOG (KERN_DEBUG, ATTO_LOG_SYSFS, "read_vda, host %p, off %d, count %d", host, (int) off, (int) count);

    return handle_locked_read (host,
                               kobj, buf, off, count, ATTOCFG_READ_VDA,
                               &host->handlers.hba_vda_handler,
                               &host->vda_lock,
                               &host->vda_in_use,
                               &host->vda_pid);
}


static ssize_t attocfg_write_vda (
#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,34) || defined(ATTO_RHEL6)
                                  struct file *file,
#endif
                                  struct kobject *kobj,
#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,22)
                                  struct bin_attribute *bin_attr,
#endif
                                  char *buf,
                                  loff_t off,
                                  size_t count)
{
    PATTOCFG_HOST host = attocfg_find_host_by_kobj (kobj);

    ATTO_LOG (KERN_DEBUG, ATTO_LOG_SYSFS, "write_vda, host %p, off %d, count %d", host, (int) off, (int) count);

    return handle_locked_write (host,
                                kobj, buf, off, count, ATTOCFG_WRITE_VDA,
                                &host->handlers.hba_vda_handler,
                                &host->vda_lock,
                                &host->vda_in_use,
                                &host->vda_pid);
}


static ssize_t attocfg_read_fs (
#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,34) || defined(ATTO_RHEL6)
                                struct file *file,
#endif
                                struct kobject *kobj,
#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,22)
                                struct bin_attribute *bin_attr,
#endif
                                char *buf,
                                loff_t off,
                                size_t count)
{
    PATTOCFG_HOST host = attocfg_find_host_by_kobj (kobj);

    ATTO_LOG (KERN_DEBUG, ATTO_LOG_SYSFS, "read_fs, host %p, off %d, count %d", host, (int) off, (int) count);

    return handle_locked_read (host,
                               kobj, buf, off, count, ATTOCFG_READ_FS,
                               &host->handlers.hba_fs_handler,
                               &host->fs_lock,
                               &host->fs_in_use,
                               &host->fs_pid);
}


static ssize_t attocfg_write_fs (
#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,34) || defined(ATTO_RHEL6)
                                 struct file *file,
#endif
                                 struct kobject *kobj,
#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,22)
                                 struct bin_attribute *bin_attr,
#endif
                                 char *buf,
                                 loff_t off,
                                 size_t count)
{
    PATTOCFG_HOST host = attocfg_find_host_by_kobj (kobj);

    ATTO_LOG (KERN_DEBUG, ATTO_LOG_SYSFS, "write_fs, host %p, off %d, count %d", host, (int) off, (int) count);

    return handle_locked_write (host,
                                kobj, buf, off, count, ATTOCFG_WRITE_FS,
                                &host->handlers.hba_fs_handler,
                                &host->fs_lock,
                                &host->fs_in_use,
                                &host->fs_pid);
}


static ssize_t attocfg_read_mp (
#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,34) || defined(ATTO_RHEL6)
                                struct file *file,
#endif
                                struct kobject *kobj,
#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,22)
                                struct bin_attribute *bin_attr,
#endif
                                char *buf,
                                loff_t off,
                                size_t count)
{
    PATTOCFG_HOST host = attocfg_find_host_by_kobj (kobj);

    ATTO_LOG (KERN_DEBUG, ATTO_LOG_SYSFS, "read_mp, host %p, off %d, count %d", host, (int) off, (int) count);

    return handle_locked_read (host,
                               kobj, buf, off, count, ATTOCFG_READ_MP,
                               &host->handlers.hba_mp_handler,
                               &host->mp_lock,
                               &host->mp_in_use,
                               &host->mp_pid);
}


static ssize_t attocfg_write_mp (
#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,34) || defined(ATTO_RHEL6)
                                 struct file *file,
#endif
                                 struct kobject *kobj,
#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,22)
                                 struct bin_attribute *bin_attr,
#endif
                                 char *buf,
                                 loff_t off,
                                 size_t count)
{
    PATTOCFG_HOST host = attocfg_find_host_by_kobj (kobj);

    ATTO_LOG (KERN_DEBUG, ATTO_LOG_SYSFS, "write_mp, host %p, off %d, count %d", host, (int) off, (int) count);

    return handle_locked_write (host,
                                kobj, buf, off, count, ATTOCFG_WRITE_MP,
                                &host->handlers.hba_mp_handler,
                                &host->mp_lock,
                                &host->mp_in_use,
                                &host->mp_pid);
}


static ssize_t attocfg_read_hw (
#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,34) || defined(ATTO_RHEL6)
                                struct file *file,
#endif
                                struct kobject *kobj,
#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,22)
                                struct bin_attribute *bin_attr,
#endif
                                char *buf,
                                loff_t off,
                                size_t count)
{
    PATTOCFG_HOST host = attocfg_find_host_by_kobj (kobj);

    ATTO_LOG (KERN_DEBUG, ATTO_LOG_SYSFS, "read_hw, host %p, off %d, count %d", host, (int) off, (int) count);

    return handle_locked_read (host,
                               kobj, buf, off, count, ATTOCFG_READ_HW,
                               &host->handlers.hba_hw_handler,
                               &host->hw_lock,
                               &host->hw_in_use,
                               &host->hw_pid);
}


static ssize_t attocfg_write_hw (
#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,34) || defined(ATTO_RHEL6)
                                 struct file *file,
#endif
                                 struct kobject *kobj,
#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,22)
                                 struct bin_attribute *bin_attr,
#endif
                                 char *buf,
                                 loff_t off,
                                 size_t count)
{
    PATTOCFG_HOST host = attocfg_find_host_by_kobj (kobj);

    ATTO_LOG (KERN_DEBUG, ATTO_LOG_SYSFS, "write_hw, host %p, off %d, count %d", host, (int) off, (int) count);

    return handle_locked_write (host,
                                kobj, buf, off, count, ATTOCFG_WRITE_HW,
                                &host->handlers.hba_hw_handler,
                                &host->hw_lock,
                                &host->hw_in_use,
                                &host->hw_pid);
}


#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,36)
#define ATTOCFG_BIN_ATTR( _name, _mode, _read, _write )        \
    struct bin_attribute bin_attr_##_name = {                  \
        .attr  = { .name = __stringify(_name), .mode = _mode,  \
                   .owner = THIS_MODULE },                     \
        .size  = 0,                                            \
        .read  = _read,                                        \
        .write = _write }
#else
#define ATTOCFG_BIN_ATTR( _name, _mode, _read, _write )        \
    struct bin_attribute bin_attr_##_name = {                  \
        .attr  = { .name = __stringify(_name), .mode = _mode },\
        .size  = 0,                                            \
        .read  = _read,                                        \
        .write = _write }
#endif

/* Only root can read/write nvram and flash */

static ATTOCFG_BIN_ATTR (default_nvram,
                         S_IRUSR,
                         attocfg_read_default_nvram,
                         NULL);

static ATTOCFG_BIN_ATTR (live_nvram,
                         S_IRUSR | S_IWUSR,
                         attocfg_read_live_nvram,
                         attocfg_write_live_nvram);

static ATTOCFG_BIN_ATTR (fw,
                         S_IRUSR | S_IWUSR,
                         attocfg_read_fw,
                         attocfg_write_fw);

static ATTOCFG_BIN_ATTR (vda,
                         S_IRUSR | S_IWUSR,
                         attocfg_read_vda,
                         attocfg_write_vda);

static ATTOCFG_BIN_ATTR (fs,
                         S_IRUSR | S_IWUSR,
                         attocfg_read_fs,
                         attocfg_write_fs);

static ATTOCFG_BIN_ATTR (mp,
                         S_IRUSR | S_IWUSR,
                         attocfg_read_mp,
                         attocfg_write_mp);

static ATTOCFG_BIN_ATTR (hw,
                         S_IRUSR | S_IWUSR,
                         attocfg_read_hw,
                         attocfg_write_hw);

#ifdef CONFIG_PROC_FS
static int attocfg_proc_major = 0;

ssize_t attocfg_proc_write (struct file *fp, const char __user *buf,
                            size_t count, loff_t *data)
{
    ssize_t rez = -ENOMEM;
    char *page;

    if (count > 1024)
        return -EOVERFLOW;

    if (count < 6)
        return -EINVAL;

    page = (char *) __get_free_page (GFP_KERNEL);

    if (page)
    {
        rez = -EFAULT; /* Assume failure of copy... */

        if (copy_from_user (page, buf, count))
            goto ErrorExit;

        if (memcmp (page, "rescan", 6) != 0)
        {
            rez = -EINVAL;
            goto ErrorExit;
        }

        /* Somebody wrote "rescan" to us, so lets do that */

        rez = count;
        scan_for_hba_drivers ();
    }

ErrorExit:
    free_page ((unsigned long) page);
    return rez;
}

static struct file_operations attocfg_proc_fops =
{
    .write = attocfg_proc_write,
};

#endif



/****************************************************************************

    FUNCTION:   int attocfg_register_host (void *context,
                                           struct kobject *kobj,
                                           PATTOCFG_HANDLERS handlers)

    PURPOSE:    Callback for discovered HBA drivers to register its hosts

    RETURNS:    1 on success, 0 on error

****************************************************************************/

int attocfg_register_host (void *context,
                           struct kobject *kobj,
                           PATTOCFG_HANDLERS handlers)
{
    PATTOCFG_HBA_DRVR hba = context;
    PATTOCFG_HOST host;
    int error;

    host = vmalloc (sizeof (ATTOCFG_HOST));

    if (!host)
    {
        printk ("attocfg: Out of memory!\n");
        return 0;
    }

    ATTO_LOG (KERN_INFO, ATTO_LOG_INIT, "registering new host %p\n", host);

    /* Link the new guy in the chain. */

    memset (host, 0, sizeof (*host));

    host->driver = hba;
    host->kobj   = kobj;
    memcpy (&host->handlers, handlers, sizeof (*handlers));

    host->vda_pid = 0;
    host->fw_pid  = 0;
    host->fs_pid  = 0;
    host->mp_pid  = 0;
    host->hw_pid  = 0;

    spin_lock_init (&host->vda_lock);
    spin_lock_init (&host->fw_lock);
    spin_lock_init (&host->fs_lock);
    spin_lock_init (&host->mp_lock);
    spin_lock_init (&host->hw_lock);
    spin_lock_init (&host->nvr_lock);
    host->vda_in_use = 0;
    host->fw_in_use  = 0;
    host->fs_in_use  = 0;
    host->mp_in_use  = 0;
    host->hw_in_use  = 0;
    host->nvr_in_use = 0;

    if (hba->hosts == NULL)
        hba->hosts = host;
    else
    {
        PATTOCFG_HOST tmp;

        for (tmp = hba->hosts;
             tmp->next;
             tmp = tmp->next);

        tmp->next = host;
    }

    if (handlers->hba_nvram_handler)
    {
        if ((error = sysfs_create_bin_file (kobj, &bin_attr_default_nvram)) != 0)
            printk ("attocfg: Warning, sysfs_create_bin_file returned %d, "
                    "default NVRAM access will not work.\n", error);

        if ((error = sysfs_create_bin_file (kobj, &bin_attr_live_nvram)) != 0)
            printk ("attocfg: Warning, sysfs_create_bin_file returned %d, "
                    "live NVRAM access will not work.\n", error);
    }

    if (handlers->hba_fw_handler)
        if ((error = sysfs_create_bin_file (kobj, &bin_attr_fw)) != 0)
            printk ("attocfg: Warning, sysfs_create_bin_file returned %d, "
                    "firmware access will not work.\n", error);

    if (handlers->hba_vda_handler)
        if ((error = sysfs_create_bin_file (kobj, &bin_attr_vda)) != 0)
            printk ("attocfg: Warning, sysfs_create_bin_file returned %d, "
                    "VDA access will not work.\n", error);

    if (handlers->hba_fs_handler)
        if ((error = sysfs_create_bin_file (kobj, &bin_attr_fs)) != 0)
            printk ("attocfg: Warning, sysfs_create_bin_file returned %d, "
                    "FS access will not work.\n", error);

    if (handlers->hba_mp_handler)
        if ((error = sysfs_create_bin_file (kobj, &bin_attr_mp)) != 0)
            printk ("attocfg: Warning, sysfs_create_bin_file returned %d, "
                    "MP access will not work.\n", error);

    if (handlers->hba_hw_handler)
        if ((error = sysfs_create_bin_file (kobj, &bin_attr_hw)) != 0)
            printk ("attocfg: Warning, sysfs_create_bin_file returned %d, "
                    "HW access will not work.\n", error);

    return 1;
}


/* Structure and functions to handle async event notification. */

typedef struct AsyncEventQueue ASYNC_EVENT_Q, *PASYNC_EVENT_Q;
#define AE_MAX_LENGTH    0x100

struct AsyncEventQueue
{
    PASYNC_EVENT_Q next;
    int            length;
    int            port;
    unsigned char  data [AE_MAX_LENGTH];
};

spinlock_t      async_event_lock;
PASYNC_EVENT_Q  async_event_queue = NULL;
PASYNC_EVENT_Q  async_event_free = NULL;
void           *async_event_memory = NULL;
int             async_events_initialized = 0;

/* Arbitrary count of the max async events we can handle at once. */

#define ASYNC_EVENT_COUNT   64

#define ATTO_VDA_EVENT_PORT1   54414
#define ATTO_VDA_EVENT_PORT2   54415
#define ATTO_BB_EVENT_PORT     54416

struct socket *event_socket [3] = {NULL, NULL, NULL};


/****************************************************************************

    FUNCTION:   void send_async_event (PASYNC_EVENT_Q event)

    PURPOSE:    Send the specified data to the async event ports.  Cannot 
                be run from interrupt context!

****************************************************************************/

void send_async_event (PASYNC_EVENT_Q event)
{
    int res;
    mm_segment_t oldfs;
    struct iovec iov;
    struct msghdr msg;
    int sock_num;

    memset (&iov, 0, sizeof (iov));
    memset (&msg, 0, sizeof (msg));

    iov.iov_base = event->data; 
    iov.iov_len  = event->length;

    msg.msg_name       = 0; 
    msg.msg_namelen    = 0; 
#if LINUX_VERSION_CODE < KERNEL_VERSION(3,19,0)
    msg.msg_iov        = &iov; 
    msg.msg_iovlen     = 1; 
#else
    iov_iter_init (&msg.msg_iter, WRITE, &iov, 1, event->length);
#endif
    msg.msg_control    = NULL; 
    msg.msg_controllen = 0; 
    msg.msg_flags      = MSG_DONTWAIT | MSG_NOSIGNAL;

    oldfs = get_fs();

    set_fs (KERNEL_DS); 

    sock_num = event->port - ATTO_VDA_EVENT_PORT1;

Resend:
        if (event_socket [sock_num])

#if LINUX_VERSION_CODE < KERNEL_VERSION(4,1,0)
            res = sock_sendmsg (event_socket [sock_num],
                                &msg,
                                event->length);
#else
            res = sock_sendmsg (event_socket [sock_num],
                                &msg);
#endif
        else
            res = -ENOTSOCK;

    if (sock_num == 0)
    {
        /* VDA events sent to port ATTO_VDA_EVENT_PORT1 also */
        /* need to be sent to port ATTO_VDA_EVENT_PORT2.     */ 

        sock_num = 1;
        goto Resend;
    }

    set_fs (oldfs); 

    if (res)
    {
#ifdef ATTO_DEBUG
        /* Note: if there is no listener for the given socket, */
        /* you'll get -ECONNREFUSED (-111) from sock_sendmsg.  */

        printk ("attocfg: error sending event message (%d)\n", res);
#endif
    }
}


/****************************************************************************

    FUNCTION:   void handle_async_event_queue (unsigned long unused)

    PURPOSE:    Clean off the async event queue.  This is a task that does
                not run in interrupt context.

****************************************************************************/

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,20)
void handle_async_event_queue (void *unused)
#else
void handle_async_event_queue (struct work_struct *work)
#endif
{
    unsigned long flags;

    /* Take the events off the queue in order and send them. */

    spin_lock_irqsave (&async_event_lock, flags);

    while (1)
    {
        PASYNC_EVENT_Q curr;

        curr = async_event_queue;

        if (curr == NULL)
        {
            spin_unlock_irqrestore (&async_event_lock, flags);
            break;
        }

        async_event_queue = curr->next;

        spin_unlock_irqrestore (&async_event_lock, flags);

        send_async_event (curr);

        spin_lock_irqsave (&async_event_lock, flags);
        curr->next = async_event_free;
        async_event_free = curr;
    }
}


/****************************************************************************

    FUNCTION:   int init_async_event_queue (void)

    PURPOSE:    Initialize the async event queue

    RETURNS:    1 on success, 0 on failure

****************************************************************************/

int init_async_event_queue (void)
{
    unsigned long flags;
    PASYNC_EVENT_Q queue;
    int alloc_size = sizeof (ASYNC_EVENT_Q) * ASYNC_EVENT_COUNT;
    int i;

    if (async_events_initialized)
        return 1;

    queue = vmalloc (alloc_size);

    if (!queue)
    {
        printk ("attocfg: could not alloc %d bytes for async event queue\n",
                alloc_size);

        return 0;
    }

    spin_lock_irqsave (&async_event_lock, flags);

    /* Sanity check, all queues should be empty */

    if (async_event_free || async_event_queue)
    {
        printk ("attocfg: async event queue error during initialization (%p, %p)\n",
                async_event_free, async_event_queue);
        spin_unlock_irqrestore (&async_event_lock, flags);
        vfree (queue);
        return 0;
    }

    async_events_initialized = 1;
    async_event_memory = queue;

    /* Fill in the free async event queue */

    async_event_free = queue;

    for (i = 0; i < ASYNC_EVENT_COUNT - 1; i++, queue++)
        queue->next = queue + 1;

    queue->next = NULL;

    spin_unlock_irqrestore (&async_event_lock, flags);

    return 1;
}


/****************************************************************************

    FUNCTION:   int free_async_event_queue (void)

    PURPOSE:    Free (uninitialize) the async event queue

    RETURNS:    1 on success, 0 on failure

****************************************************************************/

int free_async_event_queue (void)
{
    unsigned long flags;
    void *addr_to_free;

    spin_lock_irqsave (&async_event_lock, flags);

    if (!async_events_initialized)
    {
        /* This is ok, we could get called even if the queue is uninited .*/
error_exit:
        spin_unlock_irqrestore (&async_event_lock, flags);
        return 0;
    }

    /* Sanity check, all queues should be empty */

    if (async_event_memory == NULL)
    {
        printk ("attocfg: async event queue memory NULL even though queue is initialized\n");
        goto error_exit;
    }

    /* Cannot vfree with interrupts disabled, so wait until we release spinlock. */

    addr_to_free = async_event_memory;

    async_event_memory = NULL;
    async_event_free   = NULL;
    async_event_queue  = NULL;
    async_events_initialized = 0;

    spin_unlock_irqrestore (&async_event_lock, flags);

    vfree (addr_to_free);

    return 1;
}


/****************************************************************************

    FUNCTION:   int fire_async_event (void *data, int len, int port)

    PURPOSE:    Queue the specified data to be sent out the specified port

    RETURNS:    1 on success, 0 on failure

****************************************************************************/

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,20)
DECLARE_WORK (async_event_task, handle_async_event_queue, NULL);
#else
DECLARE_WORK (async_event_task, handle_async_event_queue);
#endif

int fire_async_event (void *data, int len, int port)
{
    unsigned long flags;
    PASYNC_EVENT_Q event;

    if (len > AE_MAX_LENGTH)
    {
        printk ("attocfg: illegal async event length of %d\n", len);
        return 0;
    }

    spin_lock_irqsave (&async_event_lock, flags);

    if (!async_events_initialized)
    {
        spin_unlock_irqrestore (&async_event_lock, flags);
        printk ("attocfg: fire_async_event called with an uninitialized queue\n");
        return 0;
    }

    event = async_event_free;

    if (!event)
    {
        spin_unlock_irqrestore (&async_event_lock, flags);
        printk ("attocfg: out of async events\n");
        return 0;
    }

    async_event_free = event->next;

    event->next   = NULL;
    event->length = len;
    event->port   = port;
    memcpy (event->data, data, len);

    /* To preserve event ordering, place this at the end of the queue */

    if (async_event_queue == NULL)
        async_event_queue = event;
    else
    {
        PASYNC_EVENT_Q curr = async_event_queue;

        while (curr->next)
            curr = curr->next;

        curr->next = event;
    }

    spin_unlock_irqrestore (&async_event_lock, flags);

    schedule_work (&async_event_task);

    return 1;
}


/****************************************************************************

    FUNCTION:   int fire_vda_event (void *data, int len)

    PURPOSE:    Queue the specified data to be sent out the VDA event ports

    RETURNS:    1 on success, 0 on failure

****************************************************************************/

int fire_vda_event (void *data, int len)
{
    ATTO_LOG (KERN_INFO, ATTO_LOG_EVENT, "VDA async event firing (len %d)\n", len);

    return fire_async_event (data, len, ATTO_VDA_EVENT_PORT1);
}


/****************************************************************************

    FUNCTION:   int fire_bb_event (void *data, int len)

    PURPOSE:    Queue the specified data to be sent out the BB event port

    RETURNS:    1 on success, 0 on failure

****************************************************************************/

int fire_bb_event (void *data, int len)
{
    ATTO_LOG (KERN_INFO, ATTO_LOG_EVENT, "BB async event firing (len %d)\n", len);

    return fire_async_event (data, len, ATTO_BB_EVENT_PORT);
}


/****************************************************************************

    FUNCTION:   void cleanup_async_event_sockets (void)

    PURPOSE:    Cleans up the sockets for async event notification

****************************************************************************/

void cleanup_async_event_sockets (void)
{
    int i;

    for (i = 0; i < 3; i++)
    {
        if (event_socket [i])
        {
            sock_release (event_socket [i]);
            event_socket [i] = NULL;
            ATTO_LOG (KERN_INFO, ATTO_LOG_INIT, "event socket %d released\n", i);
        }
    }
}


/****************************************************************************

    FUNCTION:   int init_async_event_sockets (void)

    PURPOSE:    Initializes the sockets for async event notification

    RETURNS:    1 on success, 0 on failure

****************************************************************************/

int init_async_event_sockets (void)
{
    int sock_num;

    if (!init_async_event_queue ())
        return 0;

    for (sock_num = 0; sock_num < 3; sock_num++)
    {
        int res;
        struct sockaddr_in sin;

        if (event_socket [sock_num])
            continue;

        res = sock_create (AF_INET, SOCK_DGRAM, 0, &event_socket [sock_num]);

        if (res < 0)
        {
            printk ("attocfg: could not create event socket %d (%d)\n",
                    sock_num, res);
            cleanup_async_event_sockets ();
            return 0;
        }

        memset (&sin, 0, sizeof (sin));
        sin.sin_family = AF_INET;
        sin.sin_addr.s_addr = htonl (INADDR_LOOPBACK);
        sin.sin_port = htons (ATTO_VDA_EVENT_PORT1 + sock_num);

        res = event_socket [sock_num]->ops->connect (event_socket [sock_num],
                                                     (struct sockaddr *) &sin,
                                                     sizeof (sin),
                                                     0);

        if (res < 0)
        {
            printk ("attocfg:  could not bind event socket %d (%d)\n",
                    sock_num, res);
            cleanup_async_event_sockets ();
            return 0;
        }

        ATTO_LOG (KERN_INFO, ATTO_LOG_INIT, "event socket %d created\n", sock_num);
    }

    return 1;
}


/****************************************************************************

    FUNCTION:   void *get_reg_symbol_by_type (int type)
                void *put_reg_symbol_by_type (int type)

    PURPOSE:    get - References the registration function for the given type
                put - Releases the registration function for the given type

    ARGUMENTS:  The type of ATTO HBA driver to look for

    RETURNS:    Pointer to the driver's registration function

****************************************************************************/

void *get_put_reg_symbol_by_type (int type, int put)
{
    /* Unlike inter_module_get, symbol_get/put does not take a      */
    /* string as its argument. Instead, you must give it the actual */
    /* symbol you wish to get. That's the reason for the following  */
    /* goofy logic. Also, because of the way symbol_get is defined, */
    /* you can't use a #define for the symbol name here.            */

    if (type == ATTO_DRVR_CELERITYFC)
    {
        if (put)
        {
            symbol_put (celerityfc_attocfg_register);            
            return NULL;
        }
        else
            return symbol_get (celerityfc_attocfg_register);
    }
    else if (type == ATTO_DRVR_ESASRAID)
    {
        if (put)
        {
            symbol_put (esasraid_attocfg_register);            
            return NULL;
        }
        else
            return symbol_get (esasraid_attocfg_register);
    }
    else if (type == ATTO_DRVR_EXPRESS2)
    {
        if (put)
        {
            symbol_put (express2_attocfg_register);            
            return NULL;
        }
        else
            return symbol_get (express2_attocfg_register);
    }
    else if (type == ATTO_DRVR_ESASHBA)
    {
        if (put)
        {
            symbol_put (esashba_attocfg_register);            
            return NULL;
        }
        else
            return symbol_get (esashba_attocfg_register);
    }
    else if (type == ATTO_DRVR_CELERITY8FC)
    {
        if (put)
        {
            symbol_put (celerity8fc_attocfg_register);            
            return NULL;
        }
        else
            return symbol_get (celerity8fc_attocfg_register);
    }
    else if (type == ATTO_DRVR_CELERITY16FC)
    {
        if (put)
        {
            symbol_put (celerity16fc_attocfg_register);            
            return NULL;
        }
        else
            return symbol_get (celerity16fc_attocfg_register);
    }
    else if (type == ATTO_DRVR_ESAS2HBA)
    {
        if (put)
        {
            symbol_put (esas2hba_attocfg_register);            
            return NULL;
        }
        else
            return symbol_get (esas2hba_attocfg_register);
    }
    else if (type == ATTO_DRVR_CELERITYFCMP)
    {
        if (put)
        {
            symbol_put (celerityfcmp_attocfg_register);            
            return NULL;
        }
        else
            return symbol_get (celerityfcmp_attocfg_register);
    }
    else if (type == ATTO_DRVR_CELERITY8FCMP)
    {
        if (put)
        {
            symbol_put (celerity8fcmp_attocfg_register);            
            return NULL;
        }
        else
            return symbol_get (celerity8fcmp_attocfg_register);
    }
    else if (type == ATTO_DRVR_CELERITY16FCMP)
    {
        if (put)
        {
            symbol_put (celerity16fcmp_attocfg_register);            
            return NULL;
        }
        else
            return symbol_get (celerity16fcmp_attocfg_register);
    }
    else if (type == ATTO_DRVR_ESAS2RAID)
    {
        if (put)
        {
            symbol_put (esas2raid_attocfg_register);            
            return NULL;
        }
        else
            return symbol_get (esas2raid_attocfg_register);
    }
    else if (type == ATTO_DRVR_FASTFRAME)
    {
        if (put)
        {
            symbol_put (fastframe_attocfg_register);            
            return NULL;
        }
        else
            return symbol_get (fastframe_attocfg_register);
    }
    else if (type == ATTO_DRVR_ESAS3HBA)
    {
        if (put)
        {
            symbol_put (esas3hba_attocfg_register);
            return NULL;
        }
        else
            return symbol_get (esas3hba_attocfg_register);
    }
    else if (type == ATTO_DRVR_ESAS4HBA)
    {
        if (put)
        {
            symbol_put (esas4hba_attocfg_register);            
            return NULL;
        }
        else
            return symbol_get (esas4hba_attocfg_register);
    }


    printk ("attocfg: Bug in get_put_reg_symbol_by_type (%d)\n", type);
    return NULL;
}

#define get_reg_symbol_by_type(_t) get_put_reg_symbol_by_type (_t, 0)
#define put_reg_symbol_by_type(_t) get_put_reg_symbol_by_type (_t, 1)


/****************************************************************************

    FUNCTION:   void scan_for_hba_drivers (void)

    PURPOSE:    Scans for loaded ATTO HBA drivers and connects to them.

    ARGUMENTS:  none

****************************************************************************/

void scan_for_hba_drivers (void)
{
    PATTOCFG_HBA_DRVR this_drvr;

    ATTO_LOG (KERN_INFO, ATTO_LOG_INIT, "scanning for HBA drivers\n");

    /* Find ATTO HBA drivers. */

    for (this_drvr = hba_drvr;
         this_drvr->type != ATTO_DRVR_NONE;
         this_drvr++)
    {
        attocfg_register_callback register_drvr;

        if (this_drvr->attocfg_unregister)
            continue;

        register_drvr = (attocfg_register_callback) 
                         get_reg_symbol_by_type (this_drvr->type);

        if (register_drvr)
        {
            int num_registered;

            /* Attempt to register the HBA driver. */

            ATTOCFG_REGISTER reg;

            memset (&reg,
                    0,
                    sizeof (ATTOCFG_REGISTER));

            reg.version = ATTOCFG_VERSION;
            reg.context = this_drvr;
            reg.attocfg_register_host    = attocfg_register_host;
            reg.init_async_event_sockets = init_async_event_sockets;
            reg.fire_vda_event           = fire_vda_event;
            reg.fire_bb_event            = fire_bb_event;

            /* Note that the HBA driver may fail the registration */
            /* after registering some hosts.  This is perfectly   */
            /* ok; the hosts will get cleaned up in clean_module. */

            num_registered = (*register_drvr) (&reg);

            if (num_registered > 0)
            {
                /* Registered at least one, save the unregister callback. */

                this_drvr->attocfg_unregister = reg.attocfg_unregister;
            }
            else
            {

                /* Nothing registered, release the symbol & check for error. */
                
                put_reg_symbol_by_type (this_drvr->type);

                if (num_registered < 0)
                {
                    printk ("attocfg: registration with %d failed (%d)\n",
                            this_drvr->type, num_registered);

                    if (reg.version != ATTOCFG_VERSION)
                    {
                        printk ("attocfg: there appears to be a version "
                                "mismatch, you probably need to update "
                                "your ATTO driver(s)\n");
                    }
                }
            }
            
        }
    }
}


/****************************************************************************

    FUNCTION:   int attocfg_init (void)

    PURPOSE:    Called when the module loads.

    ARGUMENTS:  none

    RETURNS:    0 on success
                -1 on error

****************************************************************************/

static int __init attocfg_init (void)
{
#ifdef USE_ATTO_LOG
    atto_log_start = jiffies;
#endif

    ATTO_LOG (KERN_INFO, ATTO_LOG_INIT, "module init called\n");

    spin_lock_init (&async_event_lock);

    scan_for_hba_drivers ();

#ifdef CONFIG_PROC_FS
    /* Register as a char driver and stick a node under "/proc/attocfg" */

    ATTO_LOG (KERN_INFO, ATTO_LOG_INIT, "creating proc entry\n");

    attocfg_proc_major = register_chrdev (0, "attocfg", &attocfg_proc_fops);

    if (attocfg_proc_major > 0)
    {
        struct proc_dir_entry *pde;

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,26)
        pde = create_proc_entry ("attocfg", S_IWUSR, &proc_root);
#elif  LINUX_VERSION_CODE < KERNEL_VERSION(3,10,0)
        pde = create_proc_entry ("attocfg", S_IWUSR, NULL);
#else
        pde = proc_create("attocfg", 0, NULL, &attocfg_proc_fops);

        if (!pde)
        {
            printk ("attocfg: Proc entry creation failed\n");
            attocfg_proc_major = -1;
        }
#endif

#if  LINUX_VERSION_CODE < KERNEL_VERSION(3,10,0)
        if (!pde)
        {
            printk ("attocfg: Proc entry creation failed\n");
            attocfg_proc_major = -1;
        }
        else
            pde->proc_fops = &attocfg_proc_fops;
#endif
    }
    else
        printk ("attocfg: Unable to register proc entry (%d)\n", attocfg_proc_major);
#endif

    return 0;
}


/****************************************************************************

    FUNCTION:   void attocfg_exit (void)

    PURPOSE:    Called when module unloads.

    ARGUMENTS:  none

    RETURNS:    Nothing

****************************************************************************/

static void __exit attocfg_exit (void)
{
    PATTOCFG_HBA_DRVR this_drvr;

    ATTO_LOG (KERN_INFO, ATTO_LOG_INIT, "module exit called\n");

    for (this_drvr = hba_drvr;
         this_drvr->type != ATTO_DRVR_NONE;
         this_drvr++)
    {
        PATTOCFG_HOST host = this_drvr->hosts;

        /* Free registered hosts. */

        while (host)
        {
            PATTOCFG_HOST next = host->next;

            ATTO_LOG (KERN_INFO, ATTO_LOG_INIT, "removing host %p\n", host);

            if (host->handlers.hba_nvram_handler)
            {
                sysfs_remove_bin_file (host->kobj, &bin_attr_default_nvram);
                sysfs_remove_bin_file (host->kobj, &bin_attr_live_nvram);
            }

            if (host->handlers.hba_fw_handler)
                sysfs_remove_bin_file (host->kobj, &bin_attr_fw);

            if (host->handlers.hba_vda_handler)
                sysfs_remove_bin_file (host->kobj, &bin_attr_vda);

            if (host->handlers.hba_fs_handler)
                sysfs_remove_bin_file (host->kobj, &bin_attr_fs);

            if (host->handlers.hba_mp_handler)
                sysfs_remove_bin_file (host->kobj, &bin_attr_mp);

            if (host->handlers.hba_hw_handler)
                sysfs_remove_bin_file (host->kobj, &bin_attr_hw);

            vfree (host);
            host = next;
        }

        if (this_drvr->attocfg_unregister)
        {
            (*this_drvr->attocfg_unregister) ();
            this_drvr->attocfg_unregister = NULL;
            put_reg_symbol_by_type (this_drvr->type);
        }
    }

    free_async_event_queue ();
    cleanup_async_event_sockets ();

#ifdef CONFIG_PROC_FS
    if (attocfg_proc_major > 0)
    {
        ATTO_LOG (KERN_INFO, ATTO_LOG_INIT, "removing proc entry\n");

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,26)
        remove_proc_entry ("attocfg", &proc_root);
#else
        remove_proc_entry ("attocfg", NULL);
#endif

        unregister_chrdev (attocfg_proc_major, "attocfg");
        attocfg_proc_major = 0;
    }
#endif

    ATTO_LOG (KERN_INFO, ATTO_LOG_INIT, "module exit complete\n");
}

module_init(attocfg_init);
module_exit(attocfg_exit);
