


/****************************************************************************
;
; NAME: os.h
;
;
; DESCRIPTION:
;
;       Linux driver header
;
;
; REVISION HISTORY:
;
;       $Log: /pcidrv/source/shared/linux/driver/oscommon.h $
; 
; 61    4/12/16 5:33p Sschmitz
; Remove EXPRESS2 code.
; 
; 59    2/26/15 3:46p Jseba
; Updates for kernels 3.19 and 4.0
; 
; 58    7/21/14 11:25a Jseba
; Use proper signedness for module parameters (IR 14452)
; 
; 57    7/02/14 8:38a Pcullen
; Cannot set event_log_mask to 0xffffffff in newer kernels due to sign
; issue (IR 14380)
; 
; 56    4/08/14 2:08p Jseba
; Increase ATTO_DEFAULT_CMD_PER_LU to 32 for SAS HBAs
; 
; 55    4/01/14 10:30a Rcrispo
; 13007 performance opts. #include percpu.h
; 
; 54    9/25/13 11:27a Pcullen
; Added 12Gb ESASHBA4 Support
; 
; 53    7/17/13 9:10a Jseba
; Use generated/utsrelease.h for newer kernels
; 
; 52    7/10/13 11:15a Bgrove
; Use new proc api for compatability with 3.10 kernel - Previous checkin
; used oh.h from core tree by mistake.
; 
; 50    5/17/13 9:38a Pcullen
; Fix compile error for non-mp driver.
; 
; 49    1/10/13 2:15p Pcullen
; IR 8830: Linux hangs when drives spin-up
; Include kthread.h for kernel thread API.
; 
; 48    10/03/12 2:14p Jseba
; Don't include asm/system.h if it doesn't exist
; 
; 47    5/21/12 1:08p Pcullen
; IR 8282 - atfcnvr failure: kernel 2.6.35 should use the new ioctl
; structure.
; 
; 46    12/14/11 11:29a Jseba
; Use SCSI_MAX_SG_SEGMENTS if possible
; 
; 45    7/28/11 4:48p Jseba
; Support for ESAS3HBA; fix a build warning on SLES 11 SP1
; 
; 44    5/23/11 3:53p Jseba
; Fixes for 2.6.39
; 
; 43    2/14/11 2:40p Pcullen
; Add support for NPIV in Celerity8 driver.
; 
; 42    1/12/11 8:54a Jseba
; Fixes for newer kernels
; 
; 41    1/06/11 10:37a Jseba
; Updated copyright information
; 
; 40    12/21/10 4:13p Jseba
; Change default cmd_per_lun based on product type
; 
; 39    11/17/10 2:56p Jseba
; Fixes for Red Hat 6
; 
; 38    11/01/10 4:11p Mseier
; Added atto_target_reset declaration
; 
; 37    9/03/10 10:20a Jseba
; Added SG_TABLESIZE_MAX
; 
; 36    4/22/10 8:16a Pcullen
; Implementation of Linux SAS Transport
; 
; 35    3/23/10 11:47a Jseba
; Fixes for 2.6.33
; 
; 34    3/01/10 2:28p Pcullen
; Updates for Celerity 8Gb Multipathing: Added support for linux
; completion API (currently not used); Added LinuxScsiDone as a common
; completion point for all scsi commands.
; 
; 33    11/20/09 4:19p Pcullen
; Rudimentary Linux SAS Transport implementation
; 
; 32    10/30/09 9:06a Pcullen
; VMware 4 porting
; Necessary changes around linux kernel version definition to suite ESX4
; 
; 31    10/05/09 5:01p Jseba
; Removed all ATTO-specific data types
; 
; 30    10/02/09 3:18p Pcullen
; Fix compile error for fc transport in RH4
; 
; 29    8/06/09 1:29p Pcullen
; Provide more complete implementation of Linux FC Transport, including
; remote port api (rports)
; 
; 28    7/21/09 3:04p Jseba
; Add #defines for sgl_page_size and num_sg_list defaults
; 
; 27    5/11/09 2:14p Jseba
; Remove CompStatErr table
; 
; 26    2/05/09 12:34p Pcullen
; Initial checkin from VMware 3.5 porting
; 
; 25    11/17/08 11:02a Jseba
; Update CompStatErr table for ESAS2HBA
; 
; 24    10/08/08 10:16a Jseba
; ESASHBA2 is now ESAS2HBA
; 
; 23    9/17/08 2:35p Jseba
; Add MODULE_PARAM_STR (2.6 only); initial ESASHBA2 support
; 
; 22    4/24/08 11:35a Jseba
; Fix SUSE build issue with ESASHBA; embed version information with
; MODULE_VERSION; change LinuxPciUnmapSg
; 
; 21    3/19/08 1:21p Jseba
; Add atto_bios_param for 2.6
; 
; 20    3/05/08 1:52p Jseba
; Include oswrap.h
; 
; 19    2/19/08 9:42a Jseba
; Add some includes for ESASHBA only
; 
; 18    11/06/07 12:57p Jseba
; Define ATTO_RESCANS_ENABLED if its a 2.6 kernel and non-EXPRESS2 build
; 
; 17    9/04/07 2:36p Jseba
; Fix 2.4 builds
; 
; 16    8/06/07 3:25p Jseba
; Support for ESASHBA driver
; 
; 15    3/14/07 4:41p Jseba
; Only include config.h if ATTO_USE_CONFIG_H is defined
; 
; 14    12/06/06 4:40p Jseba
; Don't include atto_cfg.h for 2.4 kernels
; 
; 13    11/08/06 11:36a Jseba
; Include atto_cfg.h
; 
; 12    10/09/06 9:50a Jseba
; Add RS_SCSI_ERROR for ESASRAID
; 
; 11    9/29/06 4:30p Jseba
; Some 2.4 kernels actually know about MODULE_PARM_DESC
; 
; 10    9/27/06 9:44a Jseba
; Include <linux/utsrelease.h> if needed
; 
; 9     9/20/06 9:57a Jseba
; Moved CompStatErr definitions here from osutil.c; added EXPRESS2
; support
; 
; 8     8/28/06 11:19a Jseba
; Support for ESASRAID driver
; 
; 7     7/24/06 4:10p Jseba
; Add no-op MODULE_PARM_DESC for 2.4 builds; pull CELERITYFC_SG_SEGS
; 
; 6     3/21/05 10:28a Jseba
; Define MODULE_PARAM_INT and MODULE_PARAM_LONG for generic module
; paramter declarations
; 
; 5     11/19/04 11:20a Jseba
; 64-bit support;  sysfs support
; 
; 4     3/31/04 3:54p Jseba
; Initial support for 2.6 kernel
; 
; 3     12/09/03 9:52a Jseba
; Rename to celerityfc
; 
; 2     11/18/03 10:24a Jseba
; Add modversions.h here (instead of makefile)
; 
; 1     10/24/03 10:38a Jseba
; Initial entry
; 
;
; THIS PROGRAM AND THE INFORMATION CONTAINED HEREIN IS THE PROPERTY OF
; ATTO TECHNOLOGY, INC. AND SHALL NOT BE REPRODUCED, COPIED, OR USED IN
; WHOLE OR IN PART OTHER THAN AS PROVIDED FOR IN THE LICENSE AGREEMENT
; PURSUANT TO WHICH IT WAS FURNISHED.
;
; COPYRIGHT (c) ATTO TECHNOLOGY, INC. 10/24/03 - $JustDate:  4/12/16 $
; ALL RIGHTS RESERVED.
;
;***************************************************************************/

#ifndef _OS_H_
#define _OS_H_

#ifdef ATTO_USE_CONFIG_H
#include <linux/config.h>
#endif
#define EXPORT_SYMTAB

#ifndef LINUX_VERSION_CODE
#include <linux/version.h>
#ifdef __VMKLNX__
#define UTS_RELEASE "2.6.18"
#endif
#ifndef UTS_RELEASE
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,16)
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,36)
#include <generated/utsrelease.h>
#else
#include <linux/vermagic.h>
#endif
#else
#include <linux/utsrelease.h>
#endif
#endif
#endif

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,5,0)
#ifdef __VMKERNEL_MODULE__
/* DO NOT include modversions.h for vmware */
#else 
#include <linux/modversions.h>
#endif
#endif 

#include <linux/kernel.h>
#include <linux/kthread.h>
#include <linux/ctype.h>
#include <linux/percpu.h>

#include <asm/page.h>
#include <asm/io.h>
#include <asm/irq.h>
#include <asm/segment.h>
#include <asm/uaccess.h>
#include <asm/byteorder.h>
#include <asm/pgtable.h>
#include <linux/types.h>
#include <linux/string.h>
#include <linux/errno.h>
#include <linux/ioport.h>
#include <linux/delay.h>
#include <linux/timer.h>
#include <linux/sched.h>
#include <linux/pci.h>
#include <linux/proc_fs.h>
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,5,0)
#include <linux/blk.h>
#include <linux/tqueue.h>
#else
#include <linux/moduleparam.h>
#include <linux/blkdev.h>
#include <linux/workqueue.h>
#endif
#include <linux/vmalloc.h>
#include <linux/interrupt.h>
#define __KERNEL_SYSCALLS__
#ifndef __VMKLNX__
#include <linux/unistd.h>
#endif
#ifdef ATTO_USE_SMP_LOCK_H
#include <linux/smp_lock.h>
#endif
#include <linux/spinlock.h>
#include <linux/module.h>
#include <linux/init.h> /* Linux module initialization */
#ifdef ATTO_USE_ASM_SYSTEM_H
#include <asm/system.h>
#endif

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,5,0)
#include <asm/div64.h>
#include <sd.h>
#include <scsi.h>
#include <hosts.h>
#if defined (ESASHBA) || defined (ESAS2HBA) || defined (ESAS3HBA) || defined (ESAS4HBA)
#include <linux/hdreg.h>
#include <linux/libata-compat.h>
#endif
#include "oswrap.h"

#else

#if defined (ESASHBA) || defined (ESAS2HBA) || defined (ESAS3HBA) || defined (ESAS4HBA)
#include <linux/hdreg.h>
#ifdef ATTO_USE_SCSIREQUEST_H
#include <scsi/scsi_request.h>
#endif
#ifdef ATTO_USE_SCSIREQUEST_H_IN_SRC_TREE
#include "/usr/src/linux/include/scsi/scsi_request.h"
#endif
#endif

#include <scsi/scsi.h>
#include <scsi/scsi_host.h>
#include <scsi/scsi_cmnd.h>
#include <scsi/scsi_device.h>
#include <scsi/scsi_eh.h>
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,9)
#include <scsi/scsi_tcq.h>
#endif


/* ATTO_USE_LINUX_COMPLETION - determine whether to compile in code */
/* based on the Linux Completion api (completion.h). The was first  */
/* introduced in kernel 2.4.7. If the api is available for the      */
/* current kernel, then ATTO_COMPLETION is defined. If not defined  */
/* a log message is sent to the system log file indicating that the */
/* completion API is not available.                                 */
#undef ATTO_COMPLETION
#ifdef ATTO_USE_LINUX_COMPLETION
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,4,7)
#warning Linux Completion API not defined for your kernel. Turn off ATTO_USE_LINUX_COMPLETION
#else
#define ATTO_COMPLETION
#include <linux/completion.h>
#endif /* LINUX_VERSION_CODE < KERNEL_VERSION(2,4,7) */
#endif /* ATTO_USE_LINUX_COMPLETION */


#include "oswrap.h"
#include "attover.h"
#include "attolog.h"

typedef struct scsi_host_template Scsi_Host_Template;
typedef struct scsi_device        Scsi_Device;
typedef struct scsi_cmnd          Scsi_Cmnd;

#define SCSI_DATA_UNKNOWN       (DMA_BIDIRECTIONAL)
#define SCSI_DATA_WRITE         (DMA_TO_DEVICE)
#define SCSI_DATA_READ          (DMA_FROM_DEVICE)
#define SCSI_DATA_NONE          (DMA_NONE)
#define scsi_to_pci_dma_dir(scsi_dir)   ((int)(scsi_dir))

#endif

void LinuxPciUnmapSg (void *_cmd);

void LinuxScsiDone (void *_cmd);

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0)
#include "atto_cfg.h"
#endif

/* Some macros to get necessary data from Scsi_Cmnds */

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,5,0)

#define CMD_HOST(c)     (c)->host
#define CMD_TARG(c)     (c)->target
#define CMD_LUN(c)      (c)->lun
#define CMD_TAGS(c)     (c)->device->tagged_queue

#else

#define CMD_HOST(c)     (c)->device->host
#define CMD_TARG(c)     (c)->device->id
#define CMD_LUN(c)      (c)->device->lun
#define CMD_TAGS(c)     (c)->device->tagged_supported

#endif

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0)

#define MODULE_PARAM_UINT(_n)               \
module_param (_n, uint, S_IRUGO | S_IRUSR);

#define MODULE_PARAM_ULONG(_n)              \
module_param (_n, ulong, S_IRUGO | S_IRUSR);

#define MODULE_PARAM_SINT(_n)               \
module_param (_n, int, S_IRUGO | S_IRUSR);

#define MODULE_PARAM_SLONG(_n)              \
module_param (_n, long, S_IRUGO | S_IRUSR);

#define MODULE_PARAM_STR(_n)                \
module_param_string (_n, _n, ATTO_PARAM_STR_LEN, S_IRUGO | S_IRUSR);

#else
#define MODULE_PARAM_INT(_n)    MODULE_PARM(_n, "i")
#define MODULE_PARAM_LONG(_n)   MODULE_PARM(_n, "l")
#ifndef MODULE_PARM_DESC
#define MODULE_PARM_DESC(_a, _b)
#endif
#endif /* LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0) */


/* Device Attributes */
/* These macros are used to hide the differences across kernel versions.    */
/* Each attribute that is readable needs a 'show' fn. Each attribute that   */
/* is writeable needs a 'store' fn. These must follow the naming convention */
/* of name##_show and name##_store. Default declarations                    */
/* for showing/storing hex and decimal values are defined as macros below.  */
#define ATTO_DEV_ATTR_ULONG(name, default, desc) \
    unsigned long name = default; \
    MODULE_PARAM_ULONG (name); \
    MODULE_PARM_DESC (name, desc);

#define ATTO_DEV_ATTR_UINT(name, default, desc) \
    unsigned int name = default; \
    MODULE_PARAM_UINT (name); \
    MODULE_PARM_DESC (name, desc);


#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,26)
#define ATTO_DEV_ATTR_T struct device_attribute
#define ATTO_DEV_ATTR_R(name) static DEVICE_ATTR(name, S_IRUGO, name##_show, NULL)
#define ATTO_DEV_ATTR_RW(name) static DEVICE_ATTR(name, S_IRUGO | S_IWUSR, name##_show, name##_store)
#define ATTO_DEV_ATTR_NAME(name) dev_attr_##name

#define ATTO_DEV_ATTR_SHOW_DEC(name) \
    static ssize_t name##_show(struct device *dev, struct device_attribute *attr, char *buf) \
    { \
        return snprintf(buf, PAGE_SIZE, "%d\n", name); \
    }

#define ATTO_DEV_ATTR_STORE_DEC(name) \
    static ssize_t name##_store(struct device *dev, struct device_attribute *attr, const char *buf, size_t count) \
    { \
        int val = 0; \
        if (!isdigit(buf[0])) \
            return -EINVAL; \
        if (sscanf(buf, "%i", &val) != 1) \
            return -EINVAL; \
        name = val; \
        return strlen(buf); \
    }

#define ATTO_DEV_ATTR_SHOW_HEX(name) \
    static ssize_t name##_show(struct device *dev, struct device_attribute *attr, char *buf) \
    { \
        return snprintf(buf, PAGE_SIZE, "0x%08lx\n", name); \
    }

#define ATTO_DEV_ATTR_STORE_HEX(name) \
    static ssize_t name##_store(struct device *dev, struct device_attribute *attr, const char *buf, size_t count) \
    { \
        ulong val = 0; \
        if ((count < 2) || (buf[0] != '0') || (buf[1] != 'x')) \
            return -EINVAL; \
        if (sscanf(buf, "%lx", &val) != 1) \
            return -EINVAL; \
        name = val; \
        return strlen(buf); \
    }

#elif LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,12)

#define ATTO_DEV_ATTR_T struct class_device_attribute
#define ATTO__DEV_ATTR_R(name) static CLASS_DEVICE_ATTR(name, S_IRUGO, name##_show, NULL)
#define ATTO_DEV_ATTR_RW(name) static CLASS_DEVICE_ATTR(name, S_IRUGO | S_IWUSR, name##_show, name##_store)
#define ATTO_DEV_ATTR_NAME(name) class_device_attr_##name

#define ATTO_DEV_ATTR_SHOW_DEC(name) \
    static ssize_t name##_show(struct class_device *cdev, char *buf) \
    { \
        return snprintf(buf, PAGE_SIZE, "%d\n", name); \
    }

#define ATTO_DEV_ATTR_STORE_DEC(name) \
    static ssize_t name##_store(struct class_device *cdev, const char *buf, size_t count) \
    { \
        int val = 0; \
        if (!isdigit(buf[0])) \
            return -EINVAL; \
        if (sscanf(buf, "%i", &val) != 1) \
            return -EINVAL; \
        name = val; \
        return strlen(buf); \
    }

#define ATTO_DEV_ATTR_SHOW_HEX(name) \
    static ssize_t name##_show(struct class_device *cdev, char *buf) \
    { \
        return snprintf(buf, PAGE_SIZE, "0x%08lx\n", name); \
    }

#define ATTO_DEV_ATTR_STORE_HEX(name) \
    static ssize_t name##_store(struct class_device *cdev, const char *buf, size_t count) \
    { \
        ulong val = 0; \
        if ((count < 2) || (buf[0] != '0') || (buf[1] != 'x')) \
            return -EINVAL; \
        if (sscanf(buf, "%lx", &val) != 1) \
            return -EINVAL; \
        name = val; \
        return strlen(buf); \
    }

#endif /* No device attribute support prior to 2.6.12 */


#define DEFINED_NUM_TO_STR(num)   NUM_TO_STR(num)
#define NUM_TO_STR(num)           #num

/* Some module parameter defaults differ between drivers. */

#if defined (ESAS3HBA)
#define ATTO_DEFAULT_SGL_PAGE_SIZE 204
#define ATTO_DEFAULT_CMD_PER_LUN   32
#elif defined (ESAS2HBA)
#define ATTO_DEFAULT_SGL_PAGE_SIZE 512
#define ATTO_DEFAULT_CMD_PER_LUN   32
#elif defined (ESAS4HBA)
#define ATTO_DEFAULT_SGL_PAGE_SIZE 512
#define ATTO_DEFAULT_CMD_PER_LUN   32
#elif defined (ESASHBA)
#define ATTO_DEFAULT_SGL_PAGE_SIZE 384
#define ATTO_DEFAULT_CMD_PER_LUN   7
#elif defined (ESASRAID2)
#define ATTO_DEFAULT_SGL_PAGE_SIZE 384
#define ATTO_DEFAULT_CMD_PER_LUN   64
#elif defined (ESASRAID)
#define ATTO_DEFAULT_SGL_PAGE_SIZE 128
#define ATTO_DEFAULT_CMD_PER_LUN   64
#else
#define ATTO_DEFAULT_SGL_PAGE_SIZE 128
#define ATTO_DEFAULT_CMD_PER_LUN   16
#endif

#ifdef CELERITYFC
#define ATTO_DEFAULT_NUM_SG_LISTS 256
#else
#define ATTO_DEFAULT_NUM_SG_LISTS 1024
#endif

#ifdef FASTFRAME
#define ATTO_SG_TABLESIZE_MAX   254
#else /* All other drivers have no SG tablesize limitation. */
#ifdef SCSI_MAX_SG_SEGMENTS
#define ATTO_SG_TABLESIZE_MAX   SCSI_MAX_SG_SEGMENTS
#else
#define ATTO_SG_TABLESIZE_MAX   SG_ALL
#endif
#endif

#define GetPciDevFromHostData(_host)  (*(struct pci_dev **)(((unsigned char *) (*((void **)(_host)))) + global_pci_dev_offset))

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0)
#define ATTO_RESCANS_ENABLED
#endif

/* SCSI functions */

int atto_init_device (Scsi_Host_Template *sht, struct pci_dev *pcid);
int atto_detect (Scsi_Host_Template *);
int atto_release (struct Scsi_Host *);
const char *atto_info (struct Scsi_Host *);
int atto_ioctl_handler (void *hostdata, int cmd, void *arg);
int atto_ioctl (Scsi_Device *dev, int cmd, void *arg);
#ifdef __VMKERNEL_MODULE__
/* atto_npiv_api_handler() is defined in atto_npiv.c. */
extern int atto_npiv_api_handler(void *hostdata, int cmd, void *arg);
#endif
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,37)
int atto_queuecommand (Scsi_Cmnd *cmd, void (*done)(Scsi_Cmnd *));
#else
int atto_queuecommand (struct Scsi_Host *host, struct scsi_cmnd *cmd);
#endif
int atto_abort (Scsi_Cmnd *);
int atto_reset (Scsi_Cmnd *, unsigned int);
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,5,0)
int atto_proc_info (char *, char **, off_t, int, int, int);
int atto_bios_param (Disk *, kdev_t, int []);
#else
#if LINUX_VERSION_CODE < KERNEL_VERSION(3,10,0)
int atto_proc_info (struct Scsi_Host *, char *, char **, off_t, int, int);
#else
int atto_show_info(struct seq_file *m, struct Scsi_Host *sh);
int atto_write_info(struct Scsi_Host *sh, char *buf, int len);
#endif
int atto_bios_param (struct scsi_device *sdev, struct block_device *bdev,
                     sector_t capacity, int geometry []);
int atto_slave_alloc (Scsi_Device *dev);
int atto_slave_configure (Scsi_Device *dev);
void atto_slave_destroy (Scsi_Device *dev);
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,33) && LINUX_VERSION_CODE < KERNEL_VERSION(3,19,0)) || defined(ATTO_RHEL6) || defined(ATTO_SLES11SP1)
int atto_change_queue_depth (Scsi_Device *dev, int depth, int reason);
#else
int atto_change_queue_depth (Scsi_Device *dev, int depth);
#endif
#if LINUX_VERSION_CODE < KERNEL_VERSION(3,19,0)
int atto_change_queue_type (Scsi_Device *dev, int type);
#endif
#endif
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,35)
int atto_proc_ioctl (struct inode *inode, struct file *fp,
                     unsigned int cmd, unsigned long arg);
#else
long atto_proc_ioctl (struct file *fp, unsigned int cmd, unsigned long arg);
#endif

/* SCSI error handler (eh) functions */

int atto_eh_abort (Scsi_Cmnd *cmd);
int atto_device_reset (Scsi_Cmnd *cmd);
int atto_host_reset (Scsi_Cmnd *cmd);
int atto_bus_reset (Scsi_Cmnd *cmd);
int atto_target_reset (Scsi_Cmnd *cmd);
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,27)
enum blk_eh_timer_return atto_eh_timed_out (Scsi_Cmnd *cmd);
#endif

#endif /* _OS_H_ */
