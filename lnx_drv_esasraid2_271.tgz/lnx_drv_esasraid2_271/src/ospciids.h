


/****************************************************************************
;
; NAME: ospciids.c
;
;
; DESCRIPTION:
;
;       PCI identifiers for ATTO ESASRAID 6Gb devices
;
;
; REVISION HISTORY:
;
;       $Log: /EsasRaid2/Linux/driver/ospciids.h $
; 
; 1     5/25/12 12:54p Jseba
; Initial submission
; 
; 
; THIS PROGRAM AND THE INFORMATION CONTAINED HEREIN IS THE PROPERTY OF
; ATTO TECHNOLOGY, INC. AND SHALL NOT BE REPRODUCED, COPIED, OR USED IN
; WHOLE OR IN PART OTHER THAN AS PROVIDED FOR IN THE LICENSE AGREEMENT
; PURSUANT TO WHICH IT WAS FURNISHED.
;
; COPYRIGHT (c) ATTO TECHNOLOGY, INC. 10/24/03 - $JustDate:  5/25/12 $
; ALL RIGHTS RESERVED.
;
;***************************************************************************/

static struct pci_device_id
atto_pci_table [] = {
    { ATTO_VENDOR_ID, 0x0049, ATTO_VENDOR_ID, 0x0049,  0, 0,        0 },
    { ATTO_VENDOR_ID, 0x0049, ATTO_VENDOR_ID, 0x004A,  0, 0,        0 },
    { ATTO_VENDOR_ID, 0x0049, ATTO_VENDOR_ID, 0x004B,  0, 0,        0 },
    { ATTO_VENDOR_ID, 0x0049, ATTO_VENDOR_ID, 0x004C,  0, 0,        0 },
    { ATTO_VENDOR_ID, 0x0049, ATTO_VENDOR_ID, 0x004D,  0, 0,        0 },
    { ATTO_VENDOR_ID, 0x0049, ATTO_VENDOR_ID, 0x004E,  0, 0,        0 },
    { 0, 0, 0, 0, 0, 0, 0 }  /* The required last entry */
};

