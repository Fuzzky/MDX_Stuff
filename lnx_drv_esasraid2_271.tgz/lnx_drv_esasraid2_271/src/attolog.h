
#ifndef ATTOLOG_H
#define ATTOLOG_H

#ifdef USE_ATTO_LOG
extern unsigned long atto_log_mask;
extern unsigned long atto_log_start;

#ifndef KERN_WARN
#define KERN_WARN KERN_WARNING
#endif

/* Log Flags - bitmask */
#define ATTO_LOG_NONE  0x00000000 /* none                       */
#define ATTO_LOG_INIT  0x00000001 /* initialization messages    */
#define ATTO_LOG_TASKM 0x00000002 /* task management messages   */
#define ATTO_LOG_NPIV  0x00000004 /* virtual port messages      */
#define ATTO_LOG_XPORT 0x00000008 /* SCSI Transport (fc,sas)    */
#define ATTO_LOG_CORE  0x00000010 /* atto core messages         */
#define ATTO_LOG_SCSI  0x00000020 /* scsi mid-layer interfacing */
#define ATTO_LOG_PCI   0x00000040 /* PCI driver interface       */
#define ATTO_LOG_RPORT 0x00000080 /* remote port messages       */
#define ATTO_LOG_TARG  0x00000100 /* target messages            */
#define ATTO_LOG_IOCTL 0x00000200 /* ioctl messages             */
#define ATTO_LOG_TOPOL 0x00000400 /* SAS Topology message       */
#define ATTO_LOG_MP_ERROR 0x00001000 /* Multipathing error messages    */
#define ATTO_LOG_MP_WARN  0x00002000 /* Multipathing warning messages  */
#define ATTO_LOG_MP_INFO  0x00004000 /* Multipathing info messages     */
#define ATTO_LOG_MP_DEBUG 0x00008000 /* Multipathing debug messages    */
#define ATTO_LOG_MP_DISC  0x00010000 /* Multipathing discovery detail  */
#define ATTO_LOG_MP_ACT   0x00020000 /* Multipathing activation detail */
#define ATTO_LOG_MP (ATTO_LOG_MP_ERROR | ATTO_LOG_MP_WARN | ATTO_LOG_MP_INFO | ATTO_LOG_MP_DEBUG)
#define ATTO_LOG_EVENT 0x00040000 /* attocfg async event        */
#define ATTO_LOG_SYSFS 0x00080000 /* attocfg sysfs access       */
#define ATTO_LOG_DEBUG 0x40000000 /* debug messages             */
#define ATTO_LOG_ALL   0xffffffff /* all events                 */

/****************************************************************************

    FUNCTION:   ATTO_LOG (level, flag, fmt, arg...

    PURPOSE:    Send messages to the system log based on level and log mask

    ARGUMENTS:  level - kernel log level (see kernel.h). Messages with level
                        KERN_ERR or lower (more important) are ALWAYS printed
                flag - flag(s) which must be set in the mask (atto_log_mask)
                       for the message to be printed.
                fmt - printf style format of message
                arg - variable arg list

    RETURNS:    Nothing

****************************************************************************/

#define ATTO_LOG(level, flag, fmt, arg...)                               \
    do {                                                                 \
        { if ( (flag & atto_log_mask) || (level[1] <= '3') )             \
                printk(level "%s: " fmt, ATTO_DRVR_NAME, ##arg); }       \
    } while (0)


/****************************************************************************

    FUNCTION:   ATTO_DEV_LOG (level, flag, dev, fmt, arg...

    PURPOSE:    Send messages to the system log based on level and log mask

    ARGUMENTS:  level - kernel log level (see kernel.h). Messages with level
                        KERN_ERR or lower (more important) are ALWAYS printed
                flag - flag(s) which must be set in the mask (atto_log_mask)
                       for the message to be printed.
                dev - pointer to the device (struct device) doing the logging
                fmt - printf style format of message
                arg - variable arg list

    RETURNS:    Nothing

****************************************************************************/

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,30)
#define dev_name(_d)  (_d)->bus_id
#endif

#define _ATTO_DEV_LOG(level, flag, dev, fmt, arg...)          \
    do {                                                      \
        { if ( (flag & atto_log_mask) || (level[1] <= '3') )  \
                printk (level "%s %s %s: " fmt,               \
                        ATTO_DRVR_NAME,                       \
                        (dev)->driver ? (dev)->driver->name : \
                        ((dev)->bus ? (dev)->bus->name : ""), \
                        dev_name (dev), ##arg); }             \
    } while (0)

#define ATTO_DEV_LOG(level, flag, dev, fmt, arg...)           \
    do {                                                      \
        if (dev)                                              \
            _ATTO_DEV_LOG(level, flag, dev, fmt, ##arg);      \
        else                                                  \
            ATTO_LOG(level, flag,fmt, ##arg);                 \
    } while (0)

#else /* !USE_ATTO_LOG */

#define ATTO_LOG(level, flag, fmt, arg...)
#define ATTO_DEV_LOG(level, flag, dev, fmt, arg...)

#endif /* USE_ATTO_LOG */



#endif /* ATTOLOG_H */
