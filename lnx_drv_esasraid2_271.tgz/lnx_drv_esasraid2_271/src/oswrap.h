


/****************************************************************************
;
; NAME: oswrap.h
;
;
; DESCRIPTION:
;
;       Linux interface wrap definitions
;
;
; REVISION HISTORY:
;
;       $Log: /pcidrv/source/shared/linux/driver/oswrap.h $
; 
; 95    6/10/16 3:10p Mharbison
; multipath: offline missing devices that receive I/O requests
; 
; Once offline, the OS doesn't send down any more commands, failing them
; on its own.  This seems to work on Fedora 16, and cuts down on the
; rediculous number of retries when commands are failed with check
; conditions alone.  When a cable is unplugged, the first I/O fails with
; -EIO, subsequent open(2) fails with -ENXIO.  Once the cable is
; reattached, I/O can be performed again.  The first command after an
; unplug is again -EIO.
; 
; On boot with an emulated disk, the first open(2) attempt gets -ENXIO,
; likely because the OS tries to read the partition table before this
; point.  Whatever the case, these show in the configtool, but not in
; `lsblk`.  Offlining also avoids the issue where reads on the 512 byte
; disk return EOF, and writes return -ENOSPC.
; 
; 94    6/08/16 10:51a Jseba
; Pass pointer to ioctl to OsGetIoctlSize (IR 16261)
; 
; 93    4/18/16 11:25a Mharbison
; oswrap: add an unquoted driver name macro on Linux
; 
; This will be used to build family specific symbol names, without a lot
; of #ifdef conditionals.  The previous quoted value is still needed for
; log messages.
; 
; 92    4/12/16 5:33p Sschmitz
; Remove EXPRESS2 code.
; 
; 91    4/12/16 2:24p Mharbison
; logging: call vprintk() instead of vsprintf() + printk() on Linux
; 
; The other users of the scratch buffer can probably be eliminated as
; well by declaring the scratch buffer locally.
; 
; 90    4/12/16 1:42p Mharbison
; multipath: allow the SfDebug mask to be configured on Linux
; 
; Support for this mask is conditionally compiled into the core module by
; setting ENABLE_ATTO_DEBUG=1 in the make command, but the driver layer
; makefile doesn't pay any attention to that.  Since the modparam logic
; needs to live in the driver layer, detect whether or not the core was
; built with SfDebug support, and tailor driver conditionals accordingly.
; 
; The sysfs node '/sys/bus/pci/drivers/$driver/module/parameters/atto_sfl
; ib_mask'
; is created by the kernel (at least on Fedora 16), so don't bother with
; that.  (Yes, existing *_log_mask file code is probably useless.)
; Unfortunately, it is
; readonly and printed in decimal instead of hex.
; 
; We could leave the parameter always compiled in and do nothing with it,
; but that would leave no easy way to tell if the driver supports the
; logging, and it seems better to fail fast if the parameter is
; configured, and the driver
; doesn't support it.
; 
; 89    3/22/16 4:40p Mharbison
; ioctl: drop direct references to errno.h in the core Linux driver
; 
; The compiler is usually forced to ignore system headers in the core
; modules, for portability to other platforms.  This was introduced when
; cleaning up the sysfs MP handlers, and broke VmWare builds.  No idea
; why the header isn't being excluded on Linux.
; 
; 88    2/24/16 12:39p Bgrove
; Driver name change for VMware Thunderbolt support
; 
; 87    10/29/15 11:20a Bgrove
; Don't fall back to legacy interrupts when MSI-X interrupts are enabled
; but only one queue is allocated (IR 15727).   Also fixed bug where ESXi
; could not write to diagnostic partition when MSI-X interrupts were
; enabled.
; 
; 86    7/01/15 12:47p Bgrove
; Added EsasRaid2 MSI support
; 
; 84    3/19/15 9:31a Bgrove
; Fix preprocessor macro definintion for IFF_CELERITY8FC
; 
; 83    2/11/15 11:03a Jseba
; For SAS adapters, enable initiator mode if initiator_phy_mask is
; non-zero
; 
; 82    1/30/15 3:14p Pcullen
; MP Map LUNs to LUNs - renamed function to report devices to the kernel;
; function now handles add, remove and rescan.
; 
; 81    7/21/14 11:26a Jseba
; Use proper signedness for module parameters (IR 14452); enable
; MSI/MSI-X for CELERITY8FC (IR 14367)
; 
; 80    2/17/14 1:07p Bgrove
; Added LUNRESET IODM event for SAS devices
; 
; 79    2/06/14 4:23p Bgrove
; VMware 5.5 support, including multiqueue and IODM
; 
; 78    11/07/13 10:02a Bgrove
; VSA IOCTL Support
; 
; 77    10/24/13 9:00a Pcullen
; Increase the granularit of MP logging by adding more log levels and
; allowing core statements to be logged at a certain level.
; 
; 76    9/25/13 11:27a Pcullen
; Added 12Gb ESASHBA4 Support
; 
; 75    9/20/13 10:50a Pcullen
; Remove MSI support from Celerity8 family.
; 
; 74    8/21/13 2:12p Bgrove
; Fix read operations in 3.10+ kernels
; 
; 73    5/21/13 10:55a Pcullen
; Add _scst_connect functions to kernel space for celerity and fastframe
; families.
; 
; 72    5/17/13 9:36a Pcullen
; IR 9097: Indicate to scsi mid layer that we are handling the command if
; the timer expires.
; 
; 71    3/28/13 9:35a Pcullen
; IR 8989: Linux kernel 3.7 compile issue - remove workqueue API usage.
; 
; 70    2/25/13 11:22a Pcullen
; PM Fixes: Support for MSI-X implies support for MSI; Added macro for
; cond compilation of Celerity8 and only Celerity8 code.
; 
; 69    1/17/13 10:41a Jseba
; Added support for custom stacks and MSI with Celerity
; 
; 68    1/10/13 2:06p Pcullen
; IR 8830: Linux hangs when drives spin-up
; Added declaration of OsRescanWaiting to check for work in the DSCN
; queue.
; 
; 67    1/03/13 3:19p Jseba
; Pass CPU number to OsStartCommand
; 
; 66    7/13/12 11:02a Pcullen
; Added MP logging via attolog statements
; 
; 65    4/27/12 1:22p Pcullen
; ClryFC16 support; MSI-X support
; 
; 64    3/06/12 5:36p Jseba
; Re-enable MSI support for FastFrame
; 
; 63    1/09/12 4:22p Pcullen
; IR7845	Kernel Panic in CentOS 5.3
; IR7864	Need to be able to report enclosure IDs and slot information in
; SAS transport layer.
; 
; 62    1/06/12 11:39a Jseba
; Back out MSI support for FastFrame
; 
; 61    11/30/11 10:19a Pcullen
; Updates for ESXi 5.0 esas2hba driver.
; 
; 60    11/14/11 11:33a Pcullen
; Added support for get_bay_identifier is SAS Transport for ESAS2HBA
; only.
; 
; 59    9/16/11 3:02p Jseba
; MSI support for FastFrame and ESAS3HBA
; 
; 58    7/28/11 4:49p Jseba
; Support for ESAS3HBA
; 
; 57    6/20/11 1:57p Pcullen
; Fix for IR7505 and associated kernel panics during driver removal.
; Also, instrumented Linux code with attolog statements.
; 
; 56    4/22/11 8:52a Pcullen
; Changes for ESXi 5 RC celerity8fc driver; includes fix for IR7577.
; 
; 55    4/20/11 1:13p Mseier
; Added IS_VIRTUAL ATTO Transport Action
; 
; 54    2/14/11 2:38p Pcullen
; Add support for NPIV in Celerity8 driver.
; 
; 53    1/06/11 10:37a Jseba
; Updated copyright information
; 
; 52    11/17/10 2:58p Jseba
; Add FastFrame NIC and target mode support
; 
; 51    9/08/10 9:37a Jseba
; Added FastFrame support
; 
; 50    6/18/10 10:32a Pcullen
; Added hw node to sysfs
; 
; 49    4/22/10 8:16a Pcullen
; Implementation of Linux SAS Transport
; 
; 48    4/14/10 1:31p Mseier
; Updates for ESASRAID2 project.
; 
; 47    3/01/10 2:33p Pcullen
; Updates for Celerity 8Gb Multipathing: Added MP routines for BH work
; and ioctl handling.
; 
; 46    12/17/09 2:22p Pcullen
; Added reset param to OsAllowChangeNotification to indicate whether to
; clear the adapter ScanState array or not.
; 
; 45    11/20/09 4:19p Pcullen
; Rudimentary Linux SAS Transport implementation
; 
; 44    10/06/09 2:40p Jseba
; Added bind_to_phy support (3gb SAS only)
; 
; 43    10/05/09 5:03p Jseba
; Removed all ATTO-specific data types; removed osioctl.h; consolidated
; ATTO_CORE_REV values into a single value for all products
; 
; 42    7/22/09 2:55p Jseba
; Fix ATTO_MAX_ID for drivers where the maximum valid ID is configurable
; 
; 41    6/30/09 4:44p Pcullen
; Added OsTransport call to get target SAS address
; 
; 40    5/11/09 2:13p Jseba
; Add error values to SCSICMD_OFFSETS
; 
; 39    2/05/09 12:34p Pcullen
; Initial checkin from VMware 3.5 porting
; 
; 38    11/05/08 2:45p Jseba
; OsAbortTarget is now OsAbortCommand
; 
; 37    10/07/08 4:51p Jseba
; ESAS2HBA support
; 
; 36    9/17/08 2:37p Jseba
; Remove OsDebugHeader; initial ESASHBA2 support
; 
; 35    8/14/08 3:59p Jseba
; Add SCSICMD_FLAGS_USE_CMD_PTR for 2.6.26 
; 
; 34    7/14/08 3:23p Jseba
; Add power management code
; 
; 33    5/27/08 4:23p Jseba
; Add OsDebugPrint so wrapper can pass debug information to the core; add
; a scsicmd_off flag to specify whether the sense_buffer is a pointer;
; bump CORE_REVs
; 
; 32    4/24/08 11:38a Jseba
; Bump core revs
; 
; 31    4/17/08 4:52p Jseba
; CELERITY8FC is now CELERITY8FC
; 
; 30    3/05/08 1:53p Jseba
; CELERITYFC8 changes
; 
; 29    11/27/07 5:06p Jseba
; Add OsAllowChangeNotification
; 
; 28    11/06/07 1:00p Jseba
; OsCleanup now returns index of adapter that was cleaned up; bump
; CORE_REVs for all families
; 
; 27    10/16/07 10:02a Jseba
; Added OsGetNextScanId and SCAN_STATE defines
; 
; 26    9/21/07 3:12p Jseba
; Cleaned up DEBUG_HEADER
; 
; 25    8/21/07 10:42a Jseba
; Removed unused OS core functions
; 
; 24    8/15/07 2:52p Jseba
; Use OsLikely/Unlikely
; 
; 23    8/06/07 3:29p Jseba
; Support for ESASHBA driver; remove wrapper structures in favor of
; direct access via structure offsets (see LinuxExchangeOffsets); new
; OsStartCommand prototype
; 
; 22    11/14/06 2:31p Jseba
; Add "fs" handlers for ESASRAID FS_API
; 
; 21    10/09/06 9:48a Jseba
; Added OsGetNvramSize instead of hard-coded NVRAM size; added
; OsReadVda/OsWriteVda for ESASRAID; added ATTO error codes; bump
; CELERITYFC core revision
; 
; 20    9/27/06 9:43a Jseba
; Don't use cmd->data_cmnd
; 
; 19    9/22/06 5:24p Jseba
; Remove ATTO_MAX_CMDS, ATTO_CMD_PER_LUN, and ATTO_SG_SEGS; use new
; OsStartCommand return values
; 
; 18    9/20/06 10:28a Jseba
; Support for EXPRESS2; OsStartCommand no longer returns a status -
; failed commands will be completed via LinuxCompleteRequest
; 
; 17    8/28/06 11:19a Jseba
; Support for ESASRAID driver
; 
; 16    7/24/06 4:15p Jseba
; Scrap GlobalFlags; increase default max commands to 128; bump core rev
; 
; 15    1/03/06 10:27a Jseba
; Add OsGetAdapterHost; bump CELERITYFC_CORE_REV
; 
; 14    8/04/05 11:56a Jseba
; Bump core rev for 2.13 release
; 
; 13    3/07/05 5:17p Jseba
; Bump core rev
; 
; 12    1/25/05 11:30a Jseba
; Bump CELERITYFC_CORE_REV for 2.00 release
; 
; 11    12/28/04 9:53a Jseba
; Add os_minor_version to tell core what kernel version we are running
; 
; 10    11/29/04 3:46p Sschmitz
; Bump CELERITYMEM_CORE_REV for 1.40 release
; 
; 9     11/19/04 11:27a Jseba
; sysfs support; bump core revision
; 
; 8     10/15/04 2:33p Jseba
; Bump CELERITYFC_CORE_REV for 1.31 release
; 
; 7     6/29/04 3:01p Jseba
; Add OsDebugHeader; bump CoreRev
; 
; 6     3/31/04 3:54p Jseba
; Initial support for 2.6 kernel
; 
; 5     2/04/04 9:41a Jseba
; Added CELERITYFC_MAX_ID and CELERITYFC_MAX_LUN
; 
; 4     12/10/03 3:22p Jseba
; Change CELERITYFC_LONGNAME
; 
; 3     12/09/03 9:52a Jseba
; Rename to celerityfc
; 
; 2     11/18/03 10:26a Jseba
; Add SCSICMPLTW structure; reduce EPCIFC3_MAX_CMDS to 63
; 
; 1     10/24/03 10:38a Jseba
; Initial entry
; 
;
; THIS PROGRAM AND THE INFORMATION CONTAINED HEREIN IS THE PROPERTY OF
; ATTO TECHNOLOGY, INC. AND SHALL NOT BE REPRODUCED, COPIED, OR USED IN
; WHOLE OR IN PART OTHER THAN AS PROVIDED FOR IN THE LICENSE AGREEMENT
; PURSUANT TO WHICH IT WAS FURNISHED.
;
; COPYRIGHT (c) ATTO TECHNOLOGY, INC. 10/24/03 - $JustDate:  6/10/16 $
; ALL RIGHTS RESERVED.
;
;***************************************************************************/

#ifndef _OSWRAP_H_
#define _OSWRAP_H_

#define ATTO_CORE_REV       16

#ifdef CELERITYFC
#ifdef _MP_
#define ATTO_DRVR_RAWNAME  celerityfcmp
#define ATTO_LONGNAME      "ATTO Celerity Multipathing Fibre Channel Adapter"
#else
#define ATTO_DRVR_RAWNAME  celerityfc
#define ATTO_LONGNAME      "ATTO Celerity Fibre Channel Adapter"
#endif
#endif

#ifdef ESASRAID
#define ATTO_DRVR_RAWNAME  esasraid
#define ATTO_LONGNAME      "ATTO ExpressSAS RAID Adapter"
#define initiator_mode      1
#endif

#ifdef ESASHBA
#define ATTO_DRVR_RAWNAME  esashba
#define ATTO_LONGNAME      "ATTO ExpressSAS Adapter"
#define initiator_mode      1
#define BIND_TO_PHY_SUPPORT
#endif

#ifdef CELERITY8FC
#define CELERITYFC
#ifdef _MP_
#define ATTO_DRVR_RAWNAME  celerity8fcmp
#define ATTO_LONGNAME      "ATTO Celerity 8Gb Multipathing Fibre Channel Adapter"
#else
#define ATTO_DRVR_RAWNAME  celerity8fc
#define ATTO_LONGNAME      "ATTO Celerity 8GB Fibre Channel Adapter"
#define ATTO_MSI_SUPPORT
#define ATTO_MSIX_SUPPORT
#endif
#endif

#ifdef CELERITY16FC
#define CELERITYFC
#define CELERITY8FC
#ifdef _MP_
#ifdef THUNDERLINK
#define ATTO_DRVR_RAWNAME  thunderlink16fcmp
#define ATTO_LONGNAME      "ATTO ThunderLink 16Gb Multipathing Fibre Channel Adapter"
#else
#define ATTO_DRVR_RAWNAME  celerity16fcmp
#define ATTO_LONGNAME      "ATTO Celerity 16Gb Multipathing Fibre Channel Adapter"
#endif
#else
#ifdef THUNDERLINK
#define ATTO_DRVR_RAWNAME  thunderlink16fc
#define ATTO_LONGNAME      "ATTO ThunderLink 16Gb Fibre Channel Adapter"
#else
#define ATTO_DRVR_RAWNAME  celerity16fc
#define ATTO_LONGNAME      "ATTO Celerity 16GB Fibre Channel Adapter"
#endif
#endif
#define ATTO_MSI_SUPPORT
#define ATTO_MSIX_SUPPORT
#endif

#ifdef ESAS2HBA
#define ESASHBA
#define ATTO_DRVR_RAWNAME  esas2hba
#define ATTO_LONGNAME      "ATTO ExpressSAS 6GB Adapter"
#ifdef TARGET_MODE
#define initiator_mode      ((target_mode) ? (multimode_ports | initiator_phy_mask) : 1)
#else
#define initiator_mode      1
#endif
#endif

#ifdef ESAS3HBA
#define ESASHBA
#define ATTO_DRVR_RAWNAME  esas3hba
#define ATTO_LONGNAME      "ATTO ExpressSAS 6GB Adapter"
#define ATTO_MSI_SUPPORT
#ifdef TARGET_MODE
#define initiator_mode      ((target_mode) ? (multimode_ports | initiator_phy_mask) : 1)
#else
#define initiator_mode      1
#endif
#endif

#ifdef ESAS4HBA
#define ESASHBA
#define ATTO_DRVR_RAWNAME  esas4hba
#define ATTO_LONGNAME      "ATTO ExpressSAS 12GB Adapter"
#define ATTO_MSI_SUPPORT
#define ATTO_MSIX_SUPPORT
#ifdef TARGET_MODE
#define initiator_mode      ((target_mode) ? (multimode_ports | initiator_phy_mask) : 1)
#else
#define initiator_mode      1
#endif
#endif


#ifdef CELERITYFC
#define MAX_LOGINS_DEFAULT 256
#endif

#ifdef ATTO_USE_NPIV
/* The number of vports can't exceed the number of adapters (MAX_ADAPTERS) */
/* and it should be much smaller than that value, a good rule is 1/2.      */
#define MAX_NPIV_VPORTS_DEFAULT 16
#define MAX_NPIV_LOGINS_DEFAULT 32
#define VPORT_DISC_WAIT_TIME_DEFAULT 10000 /* msecs */
#define VPORT_INIT_RETRIES_DEFAULT 10
#endif

#define ATTO_MAX_LUN       255
#if defined(CELERITYFC)
#if defined (_MP_)
#define ATTO_MAX_ID       (max_luns - 1)
#elif defined (ATTO_USE_NPIV)
#define ATTO_MAX_ID       (max_logins - 1 + max_npiv_vports * max_npiv_logins)
#else
#define ATTO_MAX_ID       (max_logins - 1)
#endif /* _MP_ */
#elif defined(ESASHBA)
#define ATTO_MAX_ID       (num_targets - 1)
#else
#define ATTO_MAX_ID        255
#endif

#ifdef ESASRAID2
#define ATTO_DRVR_RAWNAME  esas2raid
#define ATTO_LONGNAME      "ATTO ExpressSAS 6GB RAID Adapter"
#define ATTO_MSI_SUPPORT
#define initiator_mode      1
#endif

#ifdef FASTFRAME
#ifdef _MP_
#define ATTO_DRVR_RAWNAME  fastframemp
#define ATTO_LONGNAME      "ATTO FastFrame Multipathing Fibre Channel over Ethernet Adapter"
#else
#define ATTO_DRVR_RAWNAME  fastframe
#define ATTO_LONGNAME      "ATTO FastFrame Fibre Channel over Ethernet Adapter"
#endif
#define ATTO_MSI_SUPPORT
#endif


#define ATTO_STRINGIFY2(x) #x
#define ATTO_STRINGIFY(x)  ATTO_STRINGIFY2(x)

#define ATTO_DRVR_NAME  ATTO_STRINGIFY( ATTO_DRVR_RAWNAME )


/* Support for MSI-X implies support for MSI */
#if defined (ATTO_MSIX_SUPPORT)
#define ATTO_MSI_SUPPORT
#endif

/* If and only if (IFF) celerity8fc product family. This is needed since */
/* Celerity 16 also defined celerity 8. Use this conditional for code    */
/* that is only required for Celerity 8 product family.                  */
#if (defined(CELERITY8FC) && !defined(CELERITY16FC))
#define IFF_CELERITY8FC 
#endif

/* Wrappers for Linux structures */

typedef struct _pci_resource_wrapper
{
    unsigned long start;
    unsigned long end;
} PCIRW, *PPCIRW;

#define PCIDW_RESOURCE_COUNT   5

typedef struct _pci_dev_wrapper
{
    void *original;
    PCIRW resource [PCIDW_RESOURCE_COUNT];
    unsigned char bus_number;
    unsigned int devfn;
    unsigned int irq;
    unsigned short device;
    unsigned short vendor;

} PCIDW, *PPCIDW;

typedef struct _scsi_host_wrapper
{
    void *original;
    unsigned short host_no;
    int os_minor_version;
} SHW, *PSHW;

typedef struct _scsi_cmd_offsets
{
    unsigned int    scsi_done_offset;
    unsigned int    cmd_len_offset;
    unsigned int    sense_buffer_offset;
    unsigned int    data_dir_offset;
    unsigned int    cmnd_offset;
    unsigned int    req_bufflen_offset;
    unsigned int    req_buffer_offset;
    unsigned int    use_sg_offset;
    unsigned int    sense_buffer_size;
    unsigned int    data_dir_unknown;
    unsigned int    data_dir_write;
    unsigned int    data_dir_read;
    unsigned int    data_dir_none;
    unsigned int    tag_value_head;
    unsigned int    tag_value_simple;
    unsigned int    tag_value_ordered;
    unsigned int    flags;
#define SCSICMD_FLAGS_USE_SENSE_PTR  0x00000001
#define SCSICMD_FLAGS_USE_CMD_PTR    0x00000002

    int             error_success;
    int             error_abort;
    int             error_error;
    int             error_no_connect;
    int             error_reset;
    int             error_busy;
} SCSICMD_OFFSETS, *PSCSICMD_OFFSETS;

extern unsigned int use_transport_layer;


#ifdef ESASHBA

#define ATTO_PROTO_INIT_SSP  0x00000001
#define ATTO_PROTO_INIT_STP  0x00000002
#define ATTO_PROTO_INIT_SMP  0x00000004
#define ATTO_PROTO_INIT_SATA 0x00000008
#define ATTO_PROTO_TARG_SSP  0x00000100
#define ATTO_PROTO_TARG_STP  0x00000200
#define ATTO_PROTO_TARG_SMP  0x00000400
#define ATTO_PROTO_TARG_SATA 0x00000800
#define ATTO_IS_EXPANDER     0x80000000

#define ATTO_LINKRATE_UNKNOWN 0x00
#define ATTO_LINKRATE_1_5GB   0x08
#define ATTO_LINKRATE_3GB     0x09
#define ATTO_LINKRATE_6GB     0x0A
#define ATTO_LINKRATE_12GB    0x0B

#define ATTO_INVALID_TARGET_ID 0xFFFF

/* The following structures are used in both the driver and the core */
/* therefore they use primitive C types. These structures represent  */
/* (possibly slimmed down versions of) SMP objects.                  */

typedef struct _esas_expander_info
{
    unsigned char    VendorId[8];
    unsigned char    ProductId[16];
    unsigned char    Revision[4];
    unsigned char    ComponentVendor[8];
    unsigned short   ComponentId;
    unsigned char    ComponentRev;
    unsigned char    NumSlots;
    unsigned char    NumPhys;
} ESAS_EXPANDER_INFO, *PESAS_EXPANDER_INFO;

typedef struct _esas_phy_info
{
    /* IN */
    unsigned char      PhyId;

    /* IN/OUT */
    unsigned long long SasAddress;

    /* OUT */
    unsigned char      AttachedDeviceType;        /* spec                */
    unsigned char      AttachedReason;            /* spec                */
    unsigned char      NegotiatedLogicalLinkRate; /* ATTO_LINKRATE_XXX   */
    unsigned char      AttachedInitiatorProto;    /* ATTO_PROTO_INIT_XXX */
    unsigned char      AttachedTargetProto;       /* ATTO_PROTO_TARG_XXX */
    unsigned long long AttachedSasAddress;        /* spec                */
    unsigned char      AttachedPhyId;             /* spec                */
    unsigned char      AttachedFlags;             /* spec                */
    unsigned char      ProgrammedMinLinkRate;     /* ATTO_LINKRATE_XXX   */
    unsigned char      ProgrammedMaxLinkRate;     /* ATTO_LINKRATE_XXX   */
    unsigned char      HardwareMinLinkRate;       /* ATTO_LINKRATE_XXX   */
    unsigned char      HardwareMaxLinkRate;       /* ATTO_LINKRATE_XXX   */
    
} ESAS_PHY_INFO, *PESAS_PHY_INFO;

typedef struct _esas_smp_task
{
    unsigned long long SasAddress;

    void               *Request;
    int                RequestLen;
    void               *Response;
    int                ResponseLen;

    unsigned char      Result;       /* SMP Response Result */
} ESAS_SMP_TASK, *PESAS_SMP_TASK;

#endif /* ESASHBA */

#ifdef ATTO_MSIX_SUPPORT
typedef struct
{
    unsigned short entry;
    unsigned int   vector;
} MSIX_ENTRY, *PMSIX_ENTRY;

#endif /* ATTO_MSIX_SUPPORT */

#ifdef ATTO_USE_NPIV

/* Port States */
#define ATTO_NPIV_STATE_UNKNOWN      0
#define ATTO_NPIV_STATE_ACTIVE       1
#define ATTO_NPIV_STATE_DISABLED     2
#define ATTO_NPIV_STATE_LINKDOWN     3
#define ATTO_NPIV_STATE_INITIALIZING 4
#define ATTO_NPIV_STATE_NO_FABRIC    5
#define ATTO_NPIV_STATE_FAB_RSRC     6
#define ATTO_NPIV_STATE_LOGGINGOUT   7
#define ATTO_NPIV_STATE_REJECT_WWN   8
#define ATTO_NPIV_STATE_FAILED       9

extern void LinuxSetVPortState (void *_shost, int newState);


#endif /* ATTO_USE_NPIV */

/* OsTransport actions */

enum AttoTransportActions
{
ATTO_TRANSPORT_TARG_WWNN,
ATTO_TRANSPORT_TARG_WWPN,
ATTO_TRANSPORT_TARG_PORTID,
ATTO_TRANSPORT_PORTID,
ATTO_TRANSPORT_PTYPE,
ATTO_TRANSPORT_PTYPE_LPORT,
ATTO_TRANSPORT_PTYPE_NLPORT,
ATTO_TRANSPORT_PTYPE_PTP,
ATTO_TRANSPORT_PTYPE_NPORT,
ATTO_TRANSPORT_PTYPE_UNKNOWN,
ATTO_TRANSPORT_PSTATE,
ATTO_TRANSPORT_PSTATE_ONLINE,
ATTO_TRANSPORT_PSTATE_OFFLINE,
ATTO_TRANSPORT_WWNN,
ATTO_TRANSPORT_WWPN,
ATTO_TRANSPORT_SPEED,
ATTO_TRANSPORT_SSPEED,
ATTO_TRANSPORT_CLASS,
ATTO_TRANSPORT_FRAME_SIZE,
ATTO_TRANSPORT_ACTIVE_FC4,
ATTO_TRANSPORT_SUPPORTED_FC4,
ATTO_TRANSPORT_FABRIC_NAME,
ATTO_TRANSPORT_GET_SYM_NAME,
ATTO_TRANSPORT_GETSTATS,
ATTO_TRANSPORT_SSLR,
ATTO_TRANSPORT_TXF_COUNT,
ATTO_TRANSPORT_TXW_COUNT,
ATTO_TRANSPORT_RXF_COUNT,
ATTO_TRANSPORT_RXW_COUNT,
ATTO_TRANSPORT_LIP_COUNT,
ATTO_TRANSPORT_NOS_COUNT,
ATTO_TRANSPORT_EF_COUNT,
ATTO_TRANSPORT_DF_COUNT,
ATTO_TRANSPORT_LF_COUNT,
ATTO_TRANSPORT_LSYNC_COUNT,
ATTO_TRANSPORT_LSIG_COUNT,
ATTO_TRANSPORT_PSPE_COUNT,
ATTO_TRANSPORT_ITXW_COUNT,
ATTO_TRANSPORT_ICRC_COUNT,
ATTO_TRANSPORT_RESETSTATS,
ATTO_TRANSPORT_LIP,

ATTO_TRANSPORT_DEVICE_IS_DIRECT_ATTACHED,
ATTO_TRANSPORT_DEVICE_IS_VIRTUAL,
ATTO_TRANSPORT_DEVICE_GET_ATTACHED_TARGET_ID,
ATTO_TRANSPORT_DEVICE_GET_SAS_ADDR,
ATTO_TRANSPORT_DEVICE_GET_DEVICE_TYPE,
ATTO_TRANSPORT_DEVICE_GET_PHY_ID,
ATTO_TRANSPORT_DEVICE_GET_OWNER,
ATTO_TRANSPORT_DEVICE_GET_EXP_INFO,
ATTO_TRANSPORT_DEVICE_GET_PROTO,
ATTO_TRANSPORT_DEVICE_GET_SLOT_NUM,

/* SAS Host Attributes */
ATTO_TRANSPORT_HOST_SAS_ADDRESS,
ATTO_TRANSPORT_HOST_NUM_PHYS,
ATTO_TRANSPORT_HOST_GET_PHY_MASK,

/* Host PHY Attributes */
ATTO_TRANSPORT_HOST_PHY_DISCOVER,

/* SAS SMP Commands */
ATTO_TRANSPORT_SMP_DISCOVER,
ATTO_TRANSPORT_SMP_TASK,
};



/* Other functions */

void LinuxPrint (const char *fmt, ...);

/* Functions that live in the core driver */

int OsInitAdapter (PSHW shw, void *context, PPCIDW pcidw, int index);
int OsHostReset (void *Context);
int OsBusReset (void *Context);
int OsDeviceReset (void *Context, int target, int lun);
int OsTargetReset (void *Context, int target, int lun);
int OsAbortCommand (void *Context, void *cmd);
int OsCmdHandled (void *Context, int target, void *cmd);
int OsCleanup (void *host);
int OsWorkAllowed (int index);
int OsInProcInfo (char *buffer, int len, int host);
int OsOutProcInfo (void *buffer, char **start, int offset, int len, int host);
char *OsDriverInfo (void *Context);
int OsGetIoctlSize (int cmd, void *arg);
int OsIoctl (void *Context, int cmd, void *ioctl_data);
int OsAccessNvram (int Operation, void *Context, void *buf);
#define ATTO_NVRAM_GET_SIZE   0
#define ATTO_NVRAM_READ       1
#define ATTO_NVRAM_WRITE      2
#define ATTO_NVRAM_DEFAULT    3
int OsGetCoreRev (void);
void OsUninitAdapters (void);
void OsDebugString (char *);
int OsReadFw (void *Context, char *buf, long off, int count);
int OsWriteFw (void *Context, char *buf, long off, int count);
int OsReadVda (void *Context, char *buf, long off, int count);
int OsWriteVda (void *Context, char *buf, long off, int count);
int OsReadVsa (void *Context, char *buf, long off, int count);
int OsWriteVsa (void *Context, char *buf, long off, int count);
int OsReadFs (void *Context, char *buf, long off, int count);
int OsWriteFs (void *Context, char *buf, long off, int count);
int OsReadVersion (char *buf);
void *OsGetAdapterHost (int index);
int OsGetNextScanId (int index, unsigned char *ScanState, unsigned char *ScanType);
int OsRescanWaiting (int index);
void OsAllowChangeNotification (int index, int Allow, int reset);
int OsStartCommand (void *hostdata, void *original_cmd, unsigned int target,
                    unsigned int lun, unsigned int tag, int cpu_id);
int OsSuspend (void *host);
int OsResume (void *host);
void OsSetupIoqueue(void *pdev, void *context);
#ifdef __VMKLNX__
int OsSetupPollHandler(void *host, int irq, void *context);
#endif

unsigned long long OsTransport (int host_no, enum AttoTransportActions action, unsigned int value, void *ptr);

#ifdef ATTO_USE_NPIV
extern int OsInitVport (unsigned long long node_name,
                        unsigned long long port_name,
                        void *_PhysAdapCtxt, void *_VirtAdapCtxt, PSHW Shw,
                        int *Instance);

extern int OsDisableVport (void *_VirtAdapCtxt,  int Enable);

extern int OsDeleteVport (void *_VirtAdapCtxt);
extern int OsVportReady (void *_VirtAdapCtxt);
extern int IsVirtualAdapter (void *_AdapterCtxt);
#endif


#ifdef SF_DEBUG
unsigned long OsSfDbgGetMask( void );
void OsSfDbgSetMask( unsigned long mask );
#endif

#ifdef _MP_

enum AttoDeviceAction
{
    ATTO_DEVICE_ACTION_UNDEFINED = 0,
    ATTO_DEVICE_ACTION_ADD,
    ATTO_DEVICE_ACTION_REMOVE,
    ATTO_DEVICE_ACTION_RESCAN,
    ATTO_DEVICE_ACTION_ONLINE,
    ATTO_DEVICE_ACTION_OFFLINE,
    ATTO_DEVICE_ACTION_LAST
};

int OsMpWorkRoutine (int index);
int OsMpWorkPending (int index);
int OsReadMp (void *Context, char *buf, long off, int count);
int OsWriteMp (void *Context, char *buf, long off, int count);
#endif

int OsReadHw (void *Context, char *buf, long off, int count);
int OsWriteHw (void *Context, char *buf, long off, int count);

#ifdef ATTO_AS_STACK_SUPPORT
int OsAsProcHandler (void *buffer, int len, int offset, int write);
#endif


#ifdef TARGET_MODE
#if defined (CELERITY16FC)
int celerity16fc_target_connect (int host, int cmd, void *_ioctl);
int celerity16fc_scst_connect (int index, int command, void *ptr);
#elif defined (CELERITY8FC)
int celerity8fc_target_connect (int host, int cmd, void *_ioctl);
int celerity8fc_scst_connect (int index, int command, void *ptr);
#elif defined (CELERITYFC)
int celerityfc_target_connect (int host, int cmd, void *_ioctl);
int celerityfc_scst_connect (int index, int command, void *ptr);
#elif defined (ESAS2HBA)
int esas2hba_target_connect (int host, int cmd, void *_ioctl);
#elif defined (ESAS3HBA)
int esas3hba_target_connect (int host, int cmd, void *_ioctl);
#elif defined (ESAS4HBA)
int esas4hba_target_connect (int host, int cmd, void *_ioctl);
#elif defined (FASTFRAME)
int fastframe_target_connect (int host, int cmd, void *_ioctl);
int fastframe_scst_connect (int index, int command, void *ptr);
#endif
#endif

#ifdef FASTFRAME
int fastframe_network_connect (int host, void *buff);
#endif

/* Return values for OsStartCommand: */
#define OSSC_SUCCESS      (0)
#define OSSC_SEL_TIMEOUT  (-1)
#define OSSC_BUSY         (-2)

/* Device states for device state change notifications */
#define ATTO_DEVICE_STATE_UNKNOWN         0x00
#define ATTO_DEVICE_STATE_PRESENT         0x01
#define ATTO_DEVICE_STATE_NOT_PRESENT     0x02
#define ATTO_DEVICE_STATE_ACTIVE          0x03
#define ATTO_DEVICE_STATE_ACTIVE_INFO     0x04
#define ATTO_DEVICE_STATE_ACTIVE_LOCATION 0x05
#define ATTO_DEVICE_STATE_INACTIVE        0x06
#define ATTO_DEVICE_STATE_LUN_CHANGE      0x07

/* Device types for device state change notifications */
#define ATTO_DEVICE_TYPE_UNKNOWN     0x00
#define ATTO_DEVICE_TYPE_TARGET      0x01
#define ATTO_DEVICE_TYPE_EXPANDER    0x02

/* Backward compatibility required by ESAS3HBA using old SAS transport */
#define ATTO_DEVICE_TYPE_END_DEVICE ATTO_DEVICE_TYPE_TARGET



/* Other needed defines */

#define ATTO_MAX_DEVICES       32
#define ATTO_VENDOR_ID         0x117C
#define LSI_VENDOR_ID          0x1000

#define OSIOCTL_ALL_DONE       0
#define OSIOCTL_COPY_BACK      1

#define ATTONODE_NAME         "ATTONode"

/* ATTO error codes, use LinuxGetErrno to */
/* translate to native system error codes */

#define ATTO_BUSY            -1
#define ATTO_NO_DEVICE       -2
#define ATTO_NOT_IMPLMNTD    -3
#define ATTO_INVALID_ARG     -4
#define ATTO_OUT_OF_MEMORY   -5
#define ATTO_EFBIG           -6
#define ATTO_ENOSPC          -7

/* Max length for string parameters */

#define ATTO_PARAM_STR_LEN   1024

/* Debug output as printk calls */

#define DEBUG_HEADER  ATTO_DRVR_NAME ": "

#ifndef ATTO_DEBUG
#define DEBUG_ALL(a)
#define DEBUG_LOUD(a)
#else
#define DEBUG_ALL(a)  printk a
#ifndef ATTO_DEBUG_LOUD
#define DEBUG_LOUD(a)
#else
#define DEBUG_LOUD(a) printk a
#endif
#endif

void OsDebugPrint (char *fmt, ...);

#define OsLikely(_exp)      __builtin_expect (!! (_exp), 1)
#define OsUnlikely(_exp)    __builtin_expect (!! (_exp), 0)
#define OsPrefetch(_ptr)    __builtin_prefetch (_ptr)

/* Use these macro's in core code so they can be compiled-out.   */
/* If you want 'em in, define USE_ATTO_LOG in the core makefile. */
#ifdef USE_ATTO_LOG
#define LINUX_LOG(fmt, arg...) LinuxLog(fmt, ##arg)
#define LINUX_DEV_LOG(_host, fmt, arg...) LinuxDevLog(_host, fmt, ##arg)
#define LINUX_LOG_MP(flag, fmt, arg...) LinuxLogMp(flag, fmt, ##arg);
#else
#define LINUX_LOG(_fmt, arg...)
#define LINUX_DEV_LOG(_host, fmt, arg...)
#define LINUX_LOG_MP(flag, fmt, arg...)
#endif /* USE_ATTO_LOG */

/* Use these levels in LINUX_LOG_MP calls.  There are re-defined here */
/* as attolog.h is not suitable for inclusion in core code. But, note */
/* they MUST be the same values as their counterparts from attolog.h. */
#define MP_ERROR 0x00001000
#define MP_WARN  0x00002000
#define MP_INFO  0x00004000
#define MP_DEBUG 0x00008000
#define MP_DISC  0x00010000
#define MP_ACT   0x00020000


#define ATTO_IODM_RSCN 1
#define ATTO_IODM_LNKUP 2
#define ATTO_IODM_LNKDOWN 3
#define ATTO_IODM_LUNRESET 4

#endif /* _OSWRAP_H_ */
