


/****************************************************************************
;
; NAME: osutil.c
;
;
; DESCRIPTION:
;
;       Linux utility wrap functions
;
;
; REVISION HISTORY:
;
;       $Log: /pcidrv/source/shared/linux/driver/osutil.c $
; 
; 144   6/10/16 3:10p Mharbison
; multipath: offline missing devices that receive I/O requests
; 
; Once offline, the OS doesn't send down any more commands, failing them
; on its own.  This seems to work on Fedora 16, and cuts down on the
; rediculous number of retries when commands are failed with check
; conditions alone.  When a cable is unplugged, the first I/O fails with
; -EIO, subsequent open(2) fails with -ENXIO.  Once the cable is
; reattached, I/O can be performed again.  The first command after an
; unplug is again -EIO.
; 
; On boot with an emulated disk, the first open(2) attempt gets -ENXIO,
; likely because the OS tries to read the partition table before this
; point.  Whatever the case, these show in the configtool, but not in
; `lsblk`.  Offlining also avoids the issue where reads on the 512 byte
; disk return EOF, and writes return -ENOSPC.
; 
; 143   6/08/16 10:49a Jseba
; Added LinuxCopyFromUser (IR 16261)
; 
; 142   5/05/16 4:46p Bgrove
; Fix LinuxPrint implementation for VMware
; 
; VMKAPI does not include vprintk, which Matt added to the LinuxPrint
; implementation in a recent change.   For VMware, we now use the old
; Linux Print implementation.
; 
; 141   4/12/16 2:29p Mharbison
; logging: add missing 'va_end()' calls for each 'va_start()'
; 
; The C standard requires this, even though va_end() is typically a noop.
; 
; 140   4/12/16 2:24p Mharbison
; logging: call vprintk() instead of vsprintf() + printk() on Linux
; 
; The other users of the scratch buffer can probably be eliminated as
; well by declaring the scratch buffer locally.
; 
; 139   3/22/16 4:57p Mharbison
; linux: offline SCSI devices prior to removing them (IR16235)
; 
; While mapping and unmapping MP targets, we hit one case where some of
; the LUNs and paths disappeared, but then things ground to a halt.
; Eventually, a stack trace (with a debug kernel) appeared in
; /var/log/messages, indicating a stuck task:
; 
;    INFO: task celerity16fcmp2:1679 blocked for more than 120 seconds.
;    Call Trace:
;     ? mod_timer+0x12e/0x240
;       schedule_timeout+0x265/0x330
;     ? wait_for_common+0x4f/0x180
;     ? wait_for_common+0x4f/0x180
;       wait_for_common+0x12b/0x180
;     ? default_wake_function+0x0/0x20
;       wait_for_completion+0x1d/0x20
;       blk_execute_rq+0x99/0x100
;       scsi_execute+0xe8/0x180
;       scsi_execute_req+0x9b/0x110
;       sd_sync_cache+0xe6/0x140 [sd_mod]
;     ? __dev_printk+0x35/0x80
;       sd_shutdown+0x64/0x110 [sd_mod]
;       sd_remove+0x79/0xc0 [sd_mod]
;       __device_release_driver+0x75/0xf0
;       device_release_driver+0x2d/0x40
;       bus_remove_device+0xbd/0x130
;       device_del+0x12d/0x1e0
;       __scsi_remove_device+0xc5/0xd0
;       scsi_remove_device+0x35/0x50
;       LinuxUpdateDevice+0x17e/0x5d0 [celerity16fcmp]
;       MpMapDevices+0x27d/0xac5 [celerity16fcmp]
;     ...
; 
; The reason for the preprocessor guard is a mystery- the SDEV_XXX
; identifiers were never macros, so this wasn't a check for kernel
; support.  It isn't clear how this ever worked, since it has been like
; this for 6+ years.
; 
; It may be the case that SDEV_DEL is more appropriate than SDEV_OFFLINE,
; in the case of surprise removal.  Cargo culting some of
; the in-tree drivers[1] including esasraid[2] seems to indicate that
; OFFLINE is OK, but there is a lack of documentation and this code path
; may not be well tested for the in-tree drivers.
; 
; [1] http://lxr.free-electrons.com/source/drivers/ata/libata-scsi.c?v=4.
; 4#L3856
; [2] http://lxr.free-electrons.com/source/drivers/scsi/esas2r/esas2r_mai
; n.c?v=4.4#L1738
; 
; 138   3/22/16 4:40p Mharbison
; ioctl: drop direct references to errno.h in the core Linux driver
; 
; The compiler is usually forced to ignore system headers in the core
; modules, for portability to other platforms.  This was introduced when
; cleaning up the sysfs MP handlers, and broke VmWare builds.  No idea
; why the header isn't being excluded on Linux.
; 
; 137   7/29/15 3:29p Bgrove
; Fir for 4.1+ kernels.   Remove IRQF_DISABLE, which was a no-op in
; recent kernels.
; 
; 135   4/22/15 11:55a Bgrove
; Rename driver os.h to oscommon.h to eliminate duplicate filename
; 
; 134   4/22/15 11:45a Bgrove
; Use unique names for FC and SAS transport layers
; 
; 133   4/03/15 10:21a Bgrove
; Use NUMA aware allocation functions for vectors and rq bufs.
; 
; 132   2/26/15 3:46p Jseba
; Don't spew errors about a missing async event handler by default
; 
; 131   1/30/15 3:14p Pcullen
; MP Map LUNs to LUNs - renamed function to report devices to the kernel;
; function now handles add, remove and rescan.
; 
; 130   11/05/14 10:22a Jseba
; Additional debug for LinuxClaimIrqVector
; 
; 129   9/25/14 4:11p Bgrove
; Pass number of IO queues to function that implements VMware multiqueue
; support
; 
; 128   5/29/14 4:15p Bgrove
; Add null checks for Completion API wrapper funcs.
; 
; 127   4/04/14 12:45p Bgrove
; Modify LinuxGetOnlineCPUCount to work with VMware
; 
; 126   4/04/14 11:36a Bgrove
; Initialize completion structure to avoid errors when resets are
; generated outside of the os layer.
; 
; 125   4/01/14 10:31a Rcrispo
; 13007 Performance opts. Added  LinuxGetOnlineCPUCount.
; 
; 124   3/28/14 2:55p Bgrove
; Enable multiqueue implementation even if IODM is disabled
; 
; 123   2/28/14 3:20p Jseba
; Fix force_low_dma for non-Celerity8 drivers
; 
; 122   2/27/14 9:58a Pcullen
; Corrected the kernel version when the return value from
; scsi_add_device() changed.
; 
; 121   2/18/14 9:54a Pcullen
; Linux MP modifications from NetApp & HP certification testing.
; 
; 120   2/18/14 9:04a Pcullen
; force_low_dma is only for 8Gb Celerity.
; 
; 119   2/18/14 8:51a Pcullen
; Use 64 bit DMA mask for dynamic allocation, but 32 bit for coherent.
; Added force_low_dma module parameter to override 64 bit mask back to 32
; bit for odd memory configurations. (IR 9893)
; 
; 118   2/17/14 1:06p Bgrove
; Added logging for multiqueue, IODM even for SAS devices
; 
; 117   2/12/14 2:09p Bgrove
; Fixes for IODM support in VMWare 5.5
; 
; 116   2/06/14 4:37p Bgrove
; VMWare 5.5 support, including multiqueue and IODM
; 
; 115   1/15/14 1:52p Jseba
; Fixes for older kernels
; 
; 114   12/19/13 10:51a Jseba
; Fix compile errors with older kernels (IR 9817)
; 
; 113   11/13/13 11:25a Bgrove
; Fix types for 64-bit  modulus / divide funcs
; 
; 112   11/12/13 4:02p Bgrove
; Fix for 64-bit math functions on 32-bit Linux.   Functions are used by
; VSA processing.
; 
; 111   11/07/13 10:02a Bgrove
; VSA IOCTL Support
; 
; 110   10/24/13 9:00a Pcullen
; Increase the granularit of MP logging by adding more log levels and
; allowing core statements to be logged at a certain level.
; 
; 109   9/25/13 11:27a Pcullen
; Added 12Gb ESASHBA4 Support
; 
; 108   8/21/13 2:12p Bgrove
; Fix read operations in 3.10+ kernels
; 
; 107   7/31/13 11:37a Jseba
; LinuxGet/ReleaseReqBuffer now copy the entire contents of the request
; buffer
; 
; 106   5/30/13 9:05a Pcullen
; Another modification of the device listing in our proc file for Hitachi
; (IR 8703)
; 
; 105   5/17/13 9:35a Pcullen
; IR 9268: kernel panic when unloading driver. Ensure the worker thread
; is stopped before stopping the HW layer.
; 
; 104   3/28/13 9:35a Pcullen
; IR 8989: Linux kernel 3.7 compile issue - remove workqueue API usage.
; 
; 103   2/25/13 11:21a Pcullen
; PM Fixes:  Fixed bug in LinuxSetDmaMask to that param is actually used;
; Added DPC suspend/resume functions.
; 
; 102   1/18/13 9:15a Pcullen
; Compile the new SAS transport code for ESASHBA3.
; 
; 101   1/17/13 3:23p Pcullen
; IR 8307: Change order of devices in driver proc file.
; 
; 100   1/17/13 10:40a Jseba
; Added LinuxWaitOnTimeout and support for custom stacks; fix spinlocks
; on non-SMP kernels
; 
; 99    1/10/13 2:08p Pcullen
; IR 8830: Linux hangs when drives spin-up
; Run LinuxRescanHostRoutine in a separate thread to avoid system
; contention on the shared workqueue.
; 
; 98    11/16/12 1:46p Pcullen
; Fixed missing dev parameter in ATTO_DEV_LOG stmt.
; 
; 97    10/03/12 2:15p Jseba
; Fix calls to kmap/kunmap_atomic for kernels 3.0.0 and higher
; 
; 96    9/19/12 11:12a Pcullen
; Initial check-in for celerity16 esx 5.1 build
; 
; 95    9/14/12 1:00p Pcullen
; IR 8589 - Make errors when attempting to install driver in SUSE 10. The
; 2.6.16 kernel in SUSE 10 does not define a 'bool' type. The pci_device
; also does not contain msi/msix_enabled.
; 
; 94    7/13/12 11:02a Pcullen
; Added MP logging via attolog statements
; 
; 93    5/21/12 1:06p Pcullen
; Only use IRQF_DISABLED for kernel 2.6.18+
; 
; 92    5/17/12 10:55a Pcullen
; IR 8281 - call pci_disable_device() when unregistering the PCI device.
; This decrements the pci_dev enable_cnt and also disables the interrupt
; line.
; 
; 91    5/08/12 2:05p Pcullen
; The cpu field in struct request is only available with 2.6.28+
; 
; 90    5/04/12 1:05p Pcullen
; Added LinuxGetRequestedCPU to get the requested cpu from the struct
; request of the scsi command.
; 
; 89    4/30/12 12:47p Pcullen
; Fixed compiler warnings when not using ATTO_LOG
; 
; 88    4/27/12 1:19p Pcullen
; MSI-X support: claim/release multiple irq vectors. Added more logging
; around irq claiming.
; 
; 87    3/14/12 9:48a Pcullen
; Fix for IR8108: ESX PSOD when using direct attached SATA drives.
; 
; 86    1/31/12 1:29p Bgrove
; Added macro for DMA_BIT_MASK for pre-2.6.24 kernels.
; Conditionalized code that uses pci_enable_device_mem for pre-2.6.25
; kernels.
; 
; 85    1/24/12 9:12a Jseba
; Switched to dma* functions for coherent memory allocation and DMA mask
; setting; fixed faulty physical memory addresses on some 32-bit kernel
; (IR7987)
; 
; 84    1/09/12 4:22p Pcullen
; IR7845        Kernel Panic in CentOS 5.3
; IR7864        Need to be able to report enclosure IDs and slot information in
; SAS transport layer.
; 
; 83    11/10/11 10:43a Jseba
; Fix SAS ports for SLES 10 SP 3+
; 
; 82    10/26/11 3:15p Pcullen
; Minor fixes to logging commands
; 
; 81    9/16/11 3:02p Jseba
; Added LinuxEnableMsi, LinuxDisableMsi, LinuxBugOn, LinuxWarnOn, and a
; share flag to LinuxClaimIrq
; 
; 80    7/28/11 4:55p Jseba
; Support for FastFrame transport layer and ESAS3HBA
; 
; 79    6/20/11 1:57p Pcullen
; Fix for IR7505 and associated kernel panics during driver removal.
; Also, instrumented Linux code with attolog statements.
; 
; 78    5/23/11 3:54p Jseba
; Fixes for 2.6.39
; 
; 77    4/22/11 8:52a Pcullen
; Changes for ESXi 5 RC celerity8fc driver; includes fix for IR7577.
; 
; 76    2/14/11 2:38p Pcullen
; Add support for NPIV in Celerity8 driver.
; 
; 75    9/08/10 9:36a Jseba
; Replaced LinuxGetSgDma with LinuxGetPhysAddrFromSgc, which includes
; support for chained scatter/gather lists; added LinuxGetRegionSize;
; modified LinuxWaitOn to poll the conditional in case
; wait_event_interruptible() returns an error
; 
; 74    8/09/10 4:38p Mseier
; sas_remove_host function is only used if kernel version is 2.6.18 or
; higher, instead of 2.6.14 or higher.  This resolves a conflict where a
; kernel between 2.6.14 and 2.6.17 would call sas_remove_host but not
; include the linux kernel file where it is defined (this happens in SUSE
; 10.2).
; 
; 73    6/15/10 10:05a Mseier
; Updated ESASRAID VDA events to use new async event naming scheme.
; 
; 72    6/01/10 12:54p Mseier
; Added support for slot binding and bad block reporting
; 
; 71    5/27/10 4:20p Pcullen
; Esas2hba port to VMware 4.x; added LinuxCmdGetDumpActive function.
; 
; 70    5/10/10 1:30p Pcullen
; Fixed conditional compilation on transport usage so that older (RH4)
; kernel don't attempt to use it.
; 
; 69    4/22/10 8:16a Pcullen
; Implementation of Linux SAS Transport
; 
; 68    4/14/10 1:31p Mseier
; Updates for ESASRAID2 project.
; 
; 67    3/01/10 2:31p Pcullen
; Updates for Celerity 8Gb Multipathing: Added support for linux
; completion API; Added LinuxScsiDone as common completion point for all
; scsi commands; Updated BH work API for new kernels and generalized it
; for more than just rescanning host - MP needs BH to process dev
; changes.
; 
; 66    12/17/09 3:28p Jseba
; Define use_transport_layer only if ATTO_USE_TRANSPORT is also defined
; 
; 65    11/20/09 4:19p Pcullen
; Rudimentary Linux SAS Transport implementation
; 
; 64    10/30/09 9:23a Pcullen
; VMware 4 porting
; Added inclusion of oscommon.h for VMware4 builds.
; Removed legacy ESX 3.5 changes.
; 
; 63    10/12/09 3:31p Jseba
; Added LinuxInRecovery to detect when the SCSI error handler is pending
; or running
; 
; 62    10/05/09 5:01p Jseba
; Removed all ATTO-specific data types
; 
; 61    8/06/09 1:29p Pcullen
; Provide more complete implementation of Linux FC Transport, including
; remote port api (rports)
; 
; 60    5/11/09 2:14p Jseba
; Add error values to SCSICMD_OFFSETS; change LinuxCompleteRequest to use
; error value from core instead of translating through the CompStatErr
; table
; 
; 59    3/18/09 8:20a Jseba
; Fixes for 2.6.24
; 
; 58    2/26/09 8:15a Jseba
; Fixed LinuxPciMap/UnmapSingle for >= 2.6.25
; 
; 57    2/11/09 9:48a Jseba
; Use a global, lockable scratch buffer instead of allocating large
; buffers on the stack when needed; minor formatting cleanups
; 
; 56    2/05/09 12:34p Pcullen
; Initial checkin from VMware 3.5 porting
; 
; 55    11/05/08 2:44p Jseba
; Make sure LinuxGetReqBuffer is properly kmapping the buffer, and add
; LinuxReleaseReqBuffer
; 
; 54    10/20/08 10:29a Jseba
; Fix compilation error on kernels 2.6.22 and older
; 
; 53    10/16/08 9:04a Jseba
; Added LinuxPciFindDevice, LinuxPciReleaseDevice, and LinuxGetBridgePdev
; 
; 52    10/07/08 4:50p Jseba
; Fix LinuxGetReqBuffer for 2.6.25
; 
; 51    9/30/08 10:14a Jseba
; Fix a bug in LinuxRescanHostRoutine that could lead to invalid
; outstanding references to the driver
; 
; 50    9/17/08 2:36p Jseba
; Add LinuxSscanf and LinuxGetReqBuffer; remove OsDebugHeader calls
; 
; 49    8/14/08 3:59p Jseba
; Add SCSICMD_FLAGS_USE_CMD_PTR for 2.6.26 
; 
; 48    7/14/08 3:22p Jseba
; Null timer pointer when killing it; change LinuxGetCurrentTimeMs to use
; do_gettimeofday to avoid jiffie wrap-around problems
; 
; 47    5/27/08 4:22p Jseba
; Add OsDebugPrint so wrapper can pass debug information to the core; add
; a scsicmd_off flag to specify whether the sense_buffer is a pointer 
; 
; 46    5/21/08 4:03p Jseba
; Add pci_set_consistent_dma_mask so Celerity can allocate memory over
; the 4GB barrier
; 
; 45    4/24/08 11:37a Jseba
; Fixes for kernel 2.6.25; change LinuxPciUnmapSg
; 
; 44    2/25/08 11:56a Jseba
; Removed LinuxGetSgDmaAddr
; 
; 43    2/19/08 10:58a Jseba
; Remove 64-bit pci_set_consistent_dma_mask call - we don't want
; consistent memory of the 4GB barrier
; 
; 42    1/23/08 2:15p Jseba
; Fix builds when ATTO_RESCANS_ENABLED is not defined
; 
; 41    1/08/08 9:19a Jseba
; Fix builds for older kernels
; 
; 40    1/07/08 3:45p Jseba
; Fix ESASRAID for 2.4 kernels
; 
; 39    11/27/07 5:05p Jseba
; Rework LinuxRescanHostRoutine to only add devices that do not already
; exist; remove atto_allow_rescans
; 
; 38    11/09/07 3:33p Jseba
; Fix LinuxDivideQwords for 2.4 builds
; 
; 37    11/06/07 12:58p Jseba
; Rework rescan code (change_notification=1) to fix problems with older
; kernels
; 
; 36    10/23/07 9:49a Jseba
; Don't call scsi_scan_target if SCAN_WILD_CARD is not defined
; 
; 35    10/17/07 4:13p Jseba
; Fixed rescan code for 2.6.9 and earlier
; 
; 34    10/16/07 10:01a Jseba
; Instead of using scsi_scan_host to rescan for new devices, use
; scsi_remove_device when devices are removed, and scsi_scan_target when
; devices are added
; 
; 33    9/21/07 3:11p Jseba
; Cleaned up print statements
; 
; 32    8/27/07 11:09a Jseba
; Use new flags for request_irq on newer kernel
; 
; 31    8/21/07 10:41a Jseba
; Changed LinuxRemoveDevice/LinuxAddDevice to LinuxRescanHost and
; implemented it
; 
; 30    8/06/07 3:27p Jseba
; Simplified LinuxCompleteRequest and LinuxDpcInit; use
; tasklet_hi_schedule for DPCs; removed LinuxPciMapSg (it is now done by
; this layer, not the core); added LinuxGetCurrentTimeUs and
; LinuxDivideQwords; added LinuxExchangeOffsets to allow core to directly
; access elements of command and SGL structures
; 
; 29    2/01/07 5:01p Jseba
; Added a workaround for a SCSI Tape driver bug in 2.4 kernels on x86_64
; platforms in LinuxPciMapSg/LinuxPciUnmapSg.
; 
; 28    11/08/06 11:36a Jseba
; Fix interruptible_sleep_on problem - kernel needs to be locked; move
; VDA event notification socket code to attocfg
; 
; 27    10/09/06 10:18a Jseba
; Use LinuxGetErrno for all drivers, not just ESASRAID
; 
; 26    10/09/06 9:49a Jseba
; Fix the waitqueue functions to pre-allocate and initialize the queue,
; and gave them more accurate names;  added LinuxGetErrno to translate
; ATTO error codes to Linux errno
; 
; 25    10/04/06 10:25a Jseba
; Restore LinuxMemMap/LinuxMemUnmap for use by celeritymem driver
; 
; 24    9/27/06 9:58a Jseba
; Remove unused LinuxCompareExchangeDword/Pointer
; 
; 23    9/22/06 5:21p Jseba
; Move pci_set_drvdata call from LinuxUnregisterScsiHost to new
; LinuxUnregisterPci; don't call cond_resched() if in interrupt context
; 
; 22    9/20/06 10:20a Jseba
; Move CompStatErr definitions to os.h; removed locking from
; LinuxCompleteRequest and added LinuxLockIo/UnlockIo for core to handle
; locking itself; removed LinuxClaimRegion and LinuxMemMap stuff,
; replaced with LinuxMapRegions/UnMapRegions
; 
; 21    9/14/06 11:36a Jseba
; ESASRAID async event support
; 
; 20    8/28/06 11:16a Jseba
; Support for ESASRAID driver; New LinuxMemMap/LinuxMemUnmap
; 
; 19    7/24/06 4:11p Jseba
; Conditionalize cond_resched call for 2.6 kernel only
; 
; 18    1/03/06 10:22a Jseba
; Remove deprecated "intermodule" functions; use conditional in
; LinuxSleepOn; fix bugs when initiator_mode==0 or !CONFIG_SMP; add
; LinuxYield
; 
; 17    8/04/05 11:52a Jseba
; Conditional out spinlock routines on uniprocessor systems; add
; LinuxGetKernelVersion.
; 
; 16    3/21/05 10:28a Jseba
; Remove LinuxLockIo/LinuxUnlockIo - just do the locking directly when
; necessary
; 
; 15    1/25/05 10:48a Jseba
; Added translations for RS_SEL2 and RS_ADDR_ERR
; 
; 14    12/28/04 3:45p Jseba
; Modify LinuxMemMap/Unmap to allow old-style usage
; 
; 13    12/28/04 9:51a Jseba
; Improved PCI initialization functions; misc. cleanup
; 
; 12    12/09/04 12:28p Jseba
; Use jiffies instead of do_gettimeofday for LinuxGetCurrentTimeMs - the
; resolution is good enough, and the overhead is much lower.
; 
; 11    11/29/04 3:48p Sschmitz
; Fix type mismatch in debug statement.
; 
; 10    11/19/04 11:22a Jseba
; 64-bit support; sysfs support
; 
; 9     7/16/04 2:12p Jseba
; Fixes for non-SMP systems (where spinlocks are NOPs)
; 
; 8     6/29/04 2:58p Jseba
; Modification so this module can be shared with celeritymem driver.
; 
; 7     6/16/04 1:12p Jseba
; Comment out unused declarations
; 
; 6     6/16/04 11:41a Jseba
; Use tasklets for DPC; make disable/enable IRQ a NOP for 2.6 kernel
; 
; 5     3/31/04 3:54p Jseba
; Initial support for 2.6 kernel
; 
; 4     12/10/03 3:22p Jseba
; Add LinuxDisableIrq & LinuxEnableIrq
; 
; 3     12/09/03 9:52a Jseba
; Rename to celerityfc
; 
; 2     11/18/03 10:24a Jseba
; Improved LinuxCompleteRequest
; 
; 1     10/24/03 10:38a Jseba
; Initial entry
; 
; 
;
;
; THIS PROGRAM AND THE INFORMATION CONTAINED HEREIN IS THE PROPERTY OF
; ATTO TECHNOLOGY, INC. AND SHALL NOT BE REPRODUCED, COPIED, OR USED IN
; WHOLE OR IN PART OTHER THAN AS PROVIDED FOR IN THE LICENSE AGREEMENT
; PURSUANT TO WHICH IT WAS FURNISHED.
;
; COPYRIGHT (c) ATTO TECHNOLOGY, INC. 2003
; ALL RIGHTS RESERVED.
;
;***************************************************************************/


#include "oscommon.h"
#ifdef __VMKLNX__
#ifdef IODM
#include <vmklinux_9/vmklinux_iodm.h>
#endif
#ifdef ATTO_VMK_50
#include "vmklinux_scsi.h"
#endif /* ATTO_VMK_50 */
#endif
#include "oswrap.h"

#ifdef ATTO_USE_TRANSPORT
#if defined(CELERITYFC) || defined(FASTFRAME)
#include "ostransportfc.h"
#else
#include "ostransportsas.h"
#endif
#endif

#ifdef IFF_CELERITY8FC
extern int force_low_dma;
#endif


#ifdef ATTO_AS_STACK_SUPPORT
uint32_t AS_RegisterHwIntf (void *param1, void *param2);
uint32_t AS_UnregisterHwIntf (void *param);
int third_party_stack = 0x00000001;
/* Uncomment following line for debug messages */
/* int third_party_stack = 0x80000001; */
int stack_max_targets = 512;
int stack_max_inits = 512;
int stack_max_tgt_cmds = 512;
void as_target_state_change (int index, int TargetId, int NewState);
#else
int third_party_stack = 0;
int stack_max_targets = 0;
int stack_max_inits = 0;
int stack_max_tgt_cmds = 0;
#endif

int global_pci_dev_offset;

#if (LINUX_VERSION_CODE < KERNEL_VERSION(2,6,24))
#define DMA_BIT_MASK(n) (((n) == 64) ? ~0ULL : ((1ULL<<(n))-1))
#endif

/* Allocate a global, lockable scratch buffer for routines */
/* that need some space to scribble large chunks of data.  */

#ifdef DEFINE_SPINLOCK
DEFINE_SPINLOCK (scratch_buffer_lock);
#else
static spinlock_t scratch_buffer_lock = SPIN_LOCK_UNLOCKED;
#endif
static char scratch_buffer [1024];

static inline struct device *dev_from_pdev (void *_pdev)
{
    struct pci_dev *pdev = (struct pci_dev *) _pdev;

    return &pdev->dev;
}


unsigned long LinuxLockIo (void)
{
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,5,0)
    unsigned long flags;
    spin_lock_irqsave (&io_request_lock, flags);
    return flags;
#else
    return 0;
#endif
}


void LinuxUnlockIo (unsigned long flags)
{
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,5,0)
    spin_unlock_irqrestore (&io_request_lock, flags);
#endif
}       

void OsDebugPrint (char *fmt, ...)
{
    unsigned long flags;
    va_list ap;

    va_start (ap, fmt);

    spin_lock_irqsave (&scratch_buffer_lock, flags);

    vsprintf (scratch_buffer, fmt, ap);

    va_end(ap);

    OsDebugString (scratch_buffer);

    spin_unlock_irqrestore (&scratch_buffer_lock, flags);
}

void LinuxScsiDone(void *_cmd)
{
    Scsi_Cmnd *cmd = (Scsi_Cmnd *) _cmd;

#ifdef _MP_
    /* If multipathing and the command timed-out (possible during */
    /* failover/failback), the scsi layer (2.6.27+) will call our */
    /* eh_timed_out fn which will reset the timer. However, the scsi */
    /* layer will set DID_TIME_OUT in the command->result.  Now, when we */
    /* successfully complete the command, we need to clear that error */
    /* condition or the scsi layer will begin error escalation resets. */
    if (host_byte(cmd->result) == DID_TIME_OUT)
        cmd->result = DID_OK << 16;
#endif

    /* Complete the command to the OS.    */
    cmd->scsi_done (cmd);
}


void LinuxCompleteRequest (void *_cmd, int scsi_stat, int error, int resid)
{
    Scsi_Cmnd *cmd = (Scsi_Cmnd *) _cmd;

    cmd->result = ((error << 16) | (scsi_stat & STATUS_MASK));

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,24)
    cmd->resid = resid;
#else
    scsi_set_resid (cmd, resid);
#endif

    LinuxScsiDone (cmd);
}


unsigned long LinuxGetPhysAddrFromSgc (void *_sglist, unsigned long long *addr)
{
    struct scatterlist **sglist = (struct scatterlist **) _sglist;
    unsigned long       len    = sg_dma_len (*sglist);

    (*addr) = sg_dma_address (*sglist);

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,24) || defined (VMKLNX_VMKSGARRAY_SUPPORTED)
    (*sglist) = sg_next (*sglist);
#else
    (*sglist)++;
#endif

    return len;
}

unsigned long LinuxGetPhysAddrFromSgel (void *_sgel, unsigned long long *addr)
{
    struct scatterlist **sgel = (struct scatterlist **) _sgel;
    unsigned long       len    = sg_dma_len (*sgel);

    (*addr) = sg_dma_address (*sgel);
    
    return len;
}

void LinuxGetNextSgel (void *_sgel)
{
    struct scatterlist **sgel = (struct scatterlist **) _sgel;

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,24) || defined (VMKLNX_VMKSGARRAY_SUPPORTED)
    (*sgel) = sg_next (*sgel);
#else
    (*sgel)++;
#endif

}


void LinuxStallExecution (u32 Delay)
{
    while (Delay)
    {
        if (Delay < 1000)
        {
            udelay (Delay);
            barrier ();
            return;
        }
        else
        {
            mdelay (1);
            barrier ();
            Delay -= 1000;
        }
    }
}


int LinuxSprintf (char *str, const char *format, ...)
{
    va_list ap;
    int ret;

    va_start (ap, format);

    ret = vsprintf (str, format, ap);
    va_end(ap);

    return ret;
}


int LinuxVsprintf (char *str, const char *format, va_list ap)
{
    return vsprintf (str, format, ap);
}


int LinuxSscanf (char *str, const char *format, ...)
{
    int ret = 0;

#ifndef __VMKLNX__
    /* Apparently there is no vsscanf in the vmklinux api? */
    va_list ap;

    va_start (ap, format);

    ret = vsscanf (str, format, ap);
    va_end(ap);
#endif

    return ret;
}


void LinuxPrint (const char *fmt, ...)
{
     va_list ap;
#ifdef __VMKLNX__ 
     /* VMKLNX does not include vprintk, so we use the old implementation of LinuxPrint() */
     unsigned long flags;

     va_start (ap, fmt);
 
     spin_lock_irqsave (&scratch_buffer_lock, flags);

     vsprintf (scratch_buffer, fmt, ap);

     printk (scratch_buffer);

     spin_unlock_irqrestore (&scratch_buffer_lock, flags);
#else
    va_start (ap, fmt);

    vprintk (fmt, ap);

    va_end(ap);
#endif
}

void LinuxLog (char *fmt, ...)
{
    unsigned long flags;
    va_list ap;

    va_start (ap, fmt);

    spin_lock_irqsave (&scratch_buffer_lock, flags);

    vsprintf (scratch_buffer, fmt, ap);

    va_end(ap);

    ATTO_LOG (KERN_INFO, ATTO_LOG_CORE, "%s", scratch_buffer);

    spin_unlock_irqrestore (&scratch_buffer_lock, flags);
}

void LinuxDevLog (void *_host, char *fmt, ...)
{
    unsigned long flags;
    va_list ap;
    struct Scsi_Host *shost;

    if (_host == NULL)
        return;

    shost = (struct Scsi_Host *)_host;

    va_start (ap, fmt);

    spin_lock_irqsave (&scratch_buffer_lock, flags);

    vsprintf (scratch_buffer, fmt, ap);

    va_end(ap);

    ATTO_DEV_LOG (KERN_INFO, ATTO_LOG_CORE, &(shost->shost_gendev),
              "%s", scratch_buffer);

    spin_unlock_irqrestore (&scratch_buffer_lock, flags);
}

void LinuxLogMp (unsigned long flag, char *fmt, ...)
{
    unsigned long flags;
    va_list ap;

    va_start (ap, fmt);

    spin_lock_irqsave (&scratch_buffer_lock, flags);

    vsprintf (scratch_buffer, fmt, ap);

    va_end(ap);

    ATTO_LOG (KERN_INFO, flag, "%s", scratch_buffer);

    spin_unlock_irqrestore (&scratch_buffer_lock, flags);
}


int LinuxPciReadConfig (void *_pdev, int where, void *ptr, int size)
{
    struct pci_dev *pdev = (struct pci_dev *) _pdev;

    switch (size)
    {
    case 1: return pci_read_config_byte  (pdev, where, (u8 *)  ptr);
    case 2: return pci_read_config_word  (pdev, where, (u16 *) ptr);
    case 4: return pci_read_config_dword (pdev, where, (u32 *) ptr);
    }

    return 0;
}


int LinuxPciWriteConfig (void *_pdev, int where, u32 val, int size)
{
    struct pci_dev *pdev = (struct pci_dev *) _pdev;

    switch (size)
    {
    case 1: return pci_write_config_byte  (pdev, where, (u8)  val);
    case 2: return pci_write_config_word  (pdev, where, (u16) val);
    case 4: return pci_write_config_dword (pdev, where, (u32) val);
    }

    return 0;
}


void *LinuxPciAllocConsistentNode (void *_pdev, int size, unsigned long long *bus_addr, int cpu)
{
    void *result;
    int orig_node = dev_to_node(dev_from_pdev(_pdev));
    int node;

    node = cpu_to_node(cpu);
    set_dev_node(dev_from_pdev (_pdev), node);

    ATTO_LOG (KERN_INFO, ATTO_LOG_PCI,
              "dma_alloc_coherent called; size:%d bus_addr:%p,node:%d\n",
              size, bus_addr, node);

    /* Some 32-bit kernels (eg. RHEL5.7) do not overwrite the high DWORD  */
    /* of the physical address, so make sure that it is zeroed out first. */

    (*bus_addr) = 0;
    result = dma_alloc_coherent(dev_from_pdev (_pdev),
                                (size_t) size,
                                (dma_addr_t *) bus_addr,
                                GFP_KERNEL);

    set_dev_node(dev_from_pdev (_pdev), orig_node);

    if (result == NULL)
    {
        result = dma_alloc_coherent(dev_from_pdev (_pdev),
                                (size_t) size,
                                (dma_addr_t *) bus_addr,
                                GFP_KERNEL);
    }
    return result;
}


void *LinuxPciAllocConsistent (void *_pdev, int size, unsigned long long *bus_addr)
{
    ATTO_LOG (KERN_INFO, ATTO_LOG_PCI,
              "pci_alloc_consistent called; size:%d bus_addr:%p\n",
              size, bus_addr);

    /* Some 32-bit kernels (eg. RHEL5.7) do not overwrite the high DWORD  */
    /* of the physical address, so make sure that it is zeroed out first. */

    (*bus_addr) = 0;

    return dma_alloc_coherent(dev_from_pdev (_pdev),
                              (size_t) size,
                              (dma_addr_t *) bus_addr,
                              GFP_KERNEL);
}


void LinuxPciFreeConsistent (void *_pdev, int size, void *cpu_addr, unsigned long long bus_addr)
{
    dma_free_coherent (dev_from_pdev (_pdev),
                       (size_t) size, cpu_addr,
                       (dma_addr_t) bus_addr);

}


void LinuxUnMapRegions (void *_pdev, int *bars, int num_bars, void **maps)
{
    struct pci_dev *pdev = (struct pci_dev *) _pdev;
    int cur_bar;

    for (cur_bar = 0; cur_bar < num_bars; cur_bar++)
    {
        if (maps [cur_bar])
            iounmap (maps [cur_bar]);

        maps [cur_bar] = NULL;

#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,0)
        pci_release_region (pdev, bars [cur_bar]);
#endif
    }

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0)
    pci_release_regions (pdev);
#endif
}


int LinuxMapRegions (void *_pdev, char *name, int *bars, int num_bars, void **maps)
{
    struct pci_dev *pdev = (struct pci_dev *) _pdev;
    int cur_bar;

    /* First make sure the maps are cleared */

    for (cur_bar = 0; cur_bar < num_bars; cur_bar++)
        maps [cur_bar] = NULL;

    /* Reserve all requested regions */

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0)
    if (pci_request_regions (pdev, name))
    {
        printk (DEBUG_HEADER "Unable to reserve MMIO regions.\n");

        return 0;
    }
#else
    for (cur_bar = 0; cur_bar < num_bars; cur_bar++)
    {
        int error;

        if ((error = pci_request_region (pdev, bars [cur_bar], name)) != 0)
        {
            printk (DEBUG_HEADER "Unable to reserve MMIO region (%d, %d), error %d.\n",
                    cur_bar, bars [cur_bar], error);

            /* Release previously reserved regions */

            while (--cur_bar > -1)
                pci_release_region (pdev, bars [cur_bar]);

            return 0;
        }
    }
#endif

    /* Now, map everything */

    for (cur_bar = 0; cur_bar < num_bars; cur_bar++)
    {
        unsigned long reg  = pci_resource_start (pdev, bars [cur_bar]);
        unsigned int  size = pci_resource_len (pdev, bars [cur_bar]);

        if ((maps [cur_bar] = ioremap (reg, size)) == NULL)
        {
            printk (DEBUG_HEADER "Mem region at %lx (size %u, %d [%d]) unavailable - already in use?\n",
                    reg, size, bars [cur_bar], cur_bar);

            /* Unmap and release previous maps */

            LinuxUnMapRegions (_pdev, bars, num_bars, maps);

            return 0;
        }
    }
        
    return 1;
}


int LinuxGetRegionSize (void *_pdev, int bar)
{
    struct pci_dev *pdev = (struct pci_dev *) _pdev;

    return pci_resource_len (pdev, bar);
}


void *LinuxMemMap (void *_pdev, char *name, unsigned long reg, u32 size)
{
    void *rez;
    struct pci_dev *pdev = (struct pci_dev *) _pdev;

    if (pdev)
        if (pci_request_regions (pdev, name))
        {
            printk (DEBUG_HEADER "Unable to reserve MMIO regions.\n");

            return NULL;
        }

    if ((rez = ioremap (reg, size)) == NULL)
    {
        printk (DEBUG_HEADER "Mem region at %p (size %d) unavailable - already in use?\n",
                (void *) reg, size);
    }

    return rez;
}


void LinuxMemUnmap (void *_pdev, void *reg)
{
    struct pci_dev *pdev = (struct pci_dev *) _pdev;

    if (pdev)
        pci_release_regions (pdev);

    iounmap (reg);
}


int LinuxClaimIrq (void *context, void *_pdev, char *name, void *isr, int shared)
{
    struct pci_dev *pdev = (struct pci_dev *) _pdev;
    unsigned long   flags=0;

    ATTO_LOG (KERN_INFO, ATTO_LOG_INIT,
              "LinuxClaimIrq irq=%d (%p, %p, %s, %p, %d)\n",
              pdev->irq, context, _pdev, name, isr, shared);

#if LINUX_VERSION_CODE < KERNEL_VERSION(4,1,0)
    if (shared)
        flags = IRQF_DISABLED | IRQF_SHARED;
    else
        flags = IRQF_DISABLED;
#else
    if (shared)
        flags = IRQF_SHARED;    
#endif

    if (request_irq (pdev->irq,
                     isr,
                     flags,
                     name,
                     context))
    {
        printk (DEBUG_HEADER "Unable to request IRQ %02X.\n", pdev->irq);
        return 0;
    }

    ATTO_LOG (KERN_INFO, ATTO_LOG_INIT,
              "Claimed IRQ %d flags:0x%lx\n", pdev->irq, flags);

    return 1;
}

int LinuxClaimIrqVector (void *context, void *_pdev, int irq, char *name, void *isr)
{
    unsigned long flags = 0;
    int result = 0;
#ifdef USE_ATTO_LOG
    struct pci_dev *pdev = (struct pci_dev *) _pdev;
#endif

    ATTO_DEV_LOG (KERN_INFO, ATTO_LOG_INIT, &pdev->dev,
              "LinuxClaimIrqVector irq=%d (%p, %p, %s, %p)\n",
              irq, context, _pdev, name, isr);

#if LINUX_VERSION_CODE < KERNEL_VERSION(4,1,0)
    flags = IRQF_DISABLED;
#endif

    result = request_irq (irq,
                          isr,
                          flags,
                          name,
                          context);

    if (result)
    {
        printk (DEBUG_HEADER "Unable to request IRQ %02X (error %d)\n", irq, result);
        return 0;
    }

    ATTO_DEV_LOG (KERN_INFO, ATTO_LOG_INIT, &pdev->dev,
                  "Claimed IRQ %d flags:0x%lx\n", irq, flags);

    return 1;
}


int LinuxEnableMsi (void *_pdev)
{
    int rc;

    struct pci_dev *pdev = (struct pci_dev *) _pdev;

    ATTO_DEV_LOG (KERN_INFO, ATTO_LOG_PCI, &pdev->dev,
                  "irq before enable msi: %d\n", pdev->irq);
    rc = pci_enable_msi (pdev);
    ATTO_DEV_LOG (KERN_INFO, ATTO_LOG_PCI, &pdev->dev,
                  "irq after enable msi: %d\n", pdev->irq);

    return rc;
}


void LinuxDisableMsi (void *_pdev)
{
    struct pci_dev *pdev = (struct pci_dev *) _pdev;

    pci_disable_msi (pdev);
}

#ifdef ATTO_MSIX_SUPPORT
int LinuxEnableMsix (void *_pdev, MSIX_ENTRY entries[], int nentries)
{
    struct msix_entry *msix_entries;
    int i;
    int rc;
    struct pci_dev *pdev = (struct pci_dev *) _pdev;

    ATTO_DEV_LOG (KERN_INFO, ATTO_LOG_PCI, &pdev->dev,
                  "LinuxEnableMsix: enabling %d vectors\n", nentries);

    msix_entries = vmalloc (sizeof (struct msix_entry) * nentries);
    if (msix_entries == NULL)
    {
        ATTO_LOG (KERN_INFO, ATTO_LOG_PCI, "LinuxEnableMsix: not enough memory!");
        return -ENOMEM;
    }

    for (i = 0; i < nentries; i++)
    {
        msix_entries[i].entry = entries[i].entry;
    }

    rc = pci_enable_msix (pdev, msix_entries, nentries);

    if (rc == 0)
    {
        for (i = 0; i < nentries; i++)
        {
            /* This isolates the core from the changing size of the vector */
            /* in struct msix_entry.                                       */
            entries[i].vector = (unsigned int) msix_entries[i].vector;

            ATTO_DEV_LOG (KERN_INFO, ATTO_LOG_PCI, &pdev->dev,
                          "MSI-X[%d] entry:%d vector:%d\n", i, entries[i].entry, entries[i].vector);
        }
    }

    ATTO_DEV_LOG (KERN_INFO, ATTO_LOG_PCI, &pdev->dev,
                  "pci_enable_msix(): %d\n", rc);

    vfree (msix_entries);

    return rc;
}

void LinuxDisableMsix (void *_pdev)
{
    struct pci_dev *pdev = (struct pci_dev *) _pdev;

    ATTO_DEV_LOG (KERN_INFO, ATTO_LOG_PCI, &pdev->dev,
                  "pci_disable_msix() called\n");

    pci_disable_msix (pdev);
}

#ifdef __VMKLNX__
int LinuxGetNumIoqueue (int nentries)
{
    return vmklnx_scsi_get_num_ioqueue(nentries);
}

int LinuxRegisterIoqueue (void *_pdev, MSIX_ENTRY entries[], int nentries, int max_eq_max)
{
    int i, vmkentries;
    struct vmklnx_scsi_ioqueue_info q_info[max_eq_max];
    struct pci_dev *pdev = (struct pci_dev *) _pdev;
    struct Scsi_Host *host = pci_get_drvdata (pdev);

    vmkentries = vmklnx_scsi_get_num_ioqueue(nentries);
    
    if (vmkentries <= 1)
        return 0;

    for (i = 0; i < vmkentries; i++)
    {
        q_info[i].q_vector =  entries[i].vector;
        q_info[i].q_handle = (void *)(uint64_t) i;
    }

    vmklnx_scsi_register_ioqueue(host, vmkentries, q_info);
    
    ATTO_DEV_LOG (KERN_INFO, ATTO_LOG_PCI, &pdev->dev,
                  "multiqueue enabled with %d queues\n", vmkentries);

    return 1;
}
#endif /* __VMKLNX__ */
#endif /* ATTO_MSIX_SUPPORT */

int LinuxGetProcessorId (void)
{
    return smp_processor_id();
}

int LinuxGetRequestedCPU (void *_cmd)
{
#if LINUX_VERSION_CODE >=  KERNEL_VERSION(2,6,28)
    Scsi_Cmnd *cmd = (Scsi_Cmnd *) _cmd;

    return cmd->request->cpu;
#else
    return smp_processor_id();
#endif
}


void LinuxBugOn (void)
{
    BUG_ON (1);
}


void LinuxWarnOn (void)
{
    WARN_ON (1);
}



int LinuxRegisterPollHandler (void *_shost, unsigned int irq, void *isr, void *context)
{
#ifdef ATTO_VMK_50
    struct Scsi_Host *shost = (struct Scsi_Host *) _shost;

    vmklnx_scsi_register_poll_handler (shost, irq, isr, context);

#endif

    return 0;

}

int LinuxLogIodmEvent (void *_shost, unsigned int event, unsigned long long data)
{
#ifdef IODM
    struct Scsi_Host *shost = (struct Scsi_Host *) _shost;

    switch (event)
    {
    case ATTO_IODM_RSCN:
        vmklnx_iodm_event(shost, IODM_RSCN, NULL, data);
        break;
    case ATTO_IODM_LNKUP:
        vmklnx_iodm_event(shost, IODM_LINKUP, NULL, 0);
        break;
    case ATTO_IODM_LNKDOWN:
        vmklnx_iodm_event(shost, IODM_LINKDOWN, NULL, 0);
        break;
    case ATTO_IODM_LUNRESET:
        vmklnx_iodm_event(shost, IODM_LUNRESET, NULL, 0);
        break;
    }

#endif

    return 0;

}

void LinuxReleaseIrq (void *context, void *_pdev)
{
    struct pci_dev *pdev = (struct pci_dev *) _pdev;

    ATTO_DEV_LOG (KERN_INFO, ATTO_LOG_PCI, &pdev->dev,
                  "free_irq(%d) called\n", pdev->irq);

    free_irq (pdev->irq, context);
}    

void LinuxReleaseIrqVector (void *context, void *_pdev, int irq)
{
#ifdef USE_ATTO_LOG
    struct pci_dev *pdev = (struct pci_dev *) _pdev;
#endif

    ATTO_DEV_LOG (KERN_INFO, ATTO_LOG_PCI, &pdev->dev,
                  "free_irq(%d) called\n", irq);

    synchronize_irq (irq);
    free_irq (irq, context);
}    

void LinuxPciUnmapSg (void *_cmd)
{
    Scsi_Cmnd *cmd = (Scsi_Cmnd *) _cmd;

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,25)
    void *hostdata           = CMD_HOST(cmd)->hostdata;
    int nents                = cmd->use_sg;
    struct scatterlist *list = (struct scatterlist *) cmd->request_buffer;
    struct pci_dev *pdev     = GetPciDevFromHostData (hostdata);
    int dir                  = scsi_to_pci_dma_dir (cmd->sc_data_direction);

#ifdef ATTO_USE_KERNEL24_SCSI_TAPE_WORKAROUND
    /* See comment in atto_queuecommand for why this workaround is here. */

    int i;

    for (i = 0; i < nents; i++, list++)
        pci_unmap_single (pdev, list->dma_address, list->length, dir);

#else /* NOT ATTO_USE_KERNEL24_SCSI_TAPE_WORKAROUND */

    pci_unmap_sg (pdev, list, nents, dir);

#endif /* NOT ATTO_USE_KERNEL24_SCSI_TAPE_WORKAROUND */
#else /* LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,25) */
    scsi_dma_unmap (cmd);
#endif
}

unsigned long long LinuxPciMapSingle (void *_pdev, void *_cmd)
{
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,25)
    /* This should never happen anymore with the new SCSI DMA stuff. */

    printk (DEBUG_HEADER "LinuxPciMapSingle called, that shouldn't happen!\n");

    return 0;
#else /* LINUX_VERSION_CODE < KERNEL_VERSION(2,6,25) */
    Scsi_Cmnd *cmd = (Scsi_Cmnd *) _cmd;
    struct pci_dev *pdev = (struct pci_dev *) _pdev;

    return pci_map_single (pdev,
                           cmd->request_buffer,
                           cmd->request_bufflen,
                           scsi_to_pci_dma_dir (cmd->sc_data_direction));
#endif /* LINUX_VERSION_CODE < KERNEL_VERSION(2,6,25) */
}

void LinuxPciUnmapSingle (void *_pdev, void *_cmd, unsigned long long bus_addr)
{
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,25)
    printk (DEBUG_HEADER "LinuxPciUnmapSingle called, that shouldn't happen!\n");
#else /* LINUX_VERSION_CODE < KERNEL_VERSION(2,6,25) */
    struct pci_dev *pdev = (struct pci_dev *) _pdev;
    Scsi_Cmnd *cmd = (Scsi_Cmnd *) _cmd;
    pci_unmap_single (pdev,
                      bus_addr,
                      cmd->request_bufflen,
                      scsi_to_pci_dma_dir (cmd->sc_data_direction));
#endif /* LINUX_VERSION_CODE < KERNEL_VERSION(2,6,25) */
}


int LinuxStartTimer (u32 context, void *_timer, u32 millisecs, void (*fn)(unsigned long))
{
    struct timer_list **timer = (struct timer_list **) _timer;

    /* If this is the first call to this function, */
    /* we need to allocate some space for it.      */

    if (!(*timer))
        if (((*timer) = vmalloc (sizeof (struct timer_list))) == NULL)
        {
            printk (DEBUG_HEADER "Unable to allocate timer_list.\n");
            return 0;
        }

    init_timer ((*timer));

    (*timer)->function = fn;
    (*timer)->data     = context;
    (*timer)->expires  = jiffies + (HZ * millisecs) / 1000;

    add_timer ((*timer));

    return 1;
}


void LinuxKillTimer (void *_timer)
{
    struct timer_list **timer = (struct timer_list **) _timer;

    if (*timer)
    {
        del_timer_sync (*timer);
        vfree (*timer);
        (*timer) = NULL;
    }
}


void *LinuxAlloc (u32 size)
{
    void *rez;

    rez = vmalloc (size);

    if (rez)
        memset (rez, 0, size);

    return rez;
}


void *LinuxAllocNode (u32 size, u32 node)
{
    void *rez;

    rez = kmalloc_node (size, 0, node);

    if (rez)
        memset (rez, 0, size);

    return rez;
}


void LinuxFree (void *addr)
{
    if (addr)
        vfree (addr);
}


void LinuxFreeNode (void *addr)
{
    if (addr)
        kfree(addr);
}


void *LinuxIoRemap (u32 offset, u32 size)
{
    return ioremap (offset, size);
}


void LinuxIoUnmap (void *addr)
{
    iounmap (addr);
}


unsigned long long LinuxGetCurrentTimeSecs (void)
{
    struct timeval Now;

    do_gettimeofday (&Now);

    return ((unsigned long long)(Now.tv_sec));
}


unsigned int LinuxGetCurrentTimeMs (void)
{
    struct timeval Now;

    do_gettimeofday (&Now);

    return Now.tv_sec * 1000L + (Now.tv_usec / 1000L);
}


unsigned long long LinuxGetCurrentTimeUs (void)
{
    struct timeval Now;

    do_gettimeofday (&Now);

    return (unsigned long long) Now.tv_sec * 1000000L + (unsigned long long) Now.tv_usec;
}


int LinuxWaitInit (void **_queue)
{
    wait_queue_head_t **queue = (wait_queue_head_t **) _queue;

    if (*queue)
    {
        printk (DEBUG_HEADER "LinuxWaitInit called twice for same wait_queue!\n");
        vfree (*queue);
    }

    if (((*queue) = vmalloc (sizeof (wait_queue_head_t))) == NULL)
        return 0;

    init_waitqueue_head (*queue);

    return 1;
}


int LinuxWaitOn (void **_queue, int *conditional)
{
    wait_queue_head_t **queue = (wait_queue_head_t **) _queue;

    if (!(*queue))
    {
        printk (DEBUG_HEADER "LinuxWaitOn called for invalid wait_queue!\n");
        return 0;
    }

    /* Sometimes wait_event_interruptible constantly returns an error          */
    /* (-ERESTARTSYS), ususally when closing ConfigTool while user commands    */
    /* are outstanding.  In this case we simply have to poll for completion.   */

    while (!(*conditional))
    {
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,11)
        wait_event_interruptible (**queue, (*conditional));
#else
        lock_kernel ();
        interruptible_sleep_on_timeout (*queue, 1);
        unlock_kernel ();
#endif
    };

    return 1;
}


int LinuxWaitOnTimeout (void **_queue, int *conditional, int timeout_ms)
{
    wait_queue_head_t **queue = (wait_queue_head_t **) _queue;
    int timeout_jiffies = msecs_to_jiffies (timeout_ms);

    if (!(*queue))
    {
        printk (DEBUG_HEADER "LinuxWaitOnTimeout called for invalid wait_queue!\n");
        return 0;
    }

    /* Sometimes wait_event_interruptible constantly returns an error          */
    /* (-ERESTARTSYS), ususally when closing ConfigTool while user commands    */
    /* are outstanding.  In this case we simply have to poll for completion.   */

    while (!(*conditional))
    {
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,11)
        timeout_jiffies = wait_event_interruptible_timeout (**queue, (*conditional), timeout_jiffies);

        if (timeout_jiffies == 0)
            return 0;
#else
        lock_kernel ();
        interruptible_sleep_on_timeout (*queue, 1);
        unlock_kernel ();
        if (timeout_jiffies-- == 0)
            return 0;
#endif
    };

    return 1;
}


void LinuxWaitWake (void **_queue)
{
    wait_queue_head_t **queue = (wait_queue_head_t **) _queue;

    if (!(*queue))
    {
        printk (DEBUG_HEADER "LinuxWaitWake called for invalid wait_queue!\n");
        return;
    }

    wake_up_interruptible (*queue);
}


void LinuxWaitFree (void **_queue)
{
    if (*_queue)
    {
        vfree (*_queue);
        (*_queue) = NULL;
    }
}

#ifdef ATTO_RESCANS_ENABLED

static struct task_struct * atto_thread [ATTO_MAX_DEVICES];
static wait_queue_head_t atto_waitq [ATTO_MAX_DEVICES];

void LinuxRescanHostRoutine (int index)
{
    struct Scsi_Host *sh = (struct Scsi_Host *) OsGetAdapterHost (index);

    if (sh)
    {
        unsigned int id = -1;
        unsigned char state, type;

#ifdef ATTO_AS_STACK_SUPPORT
        if ((id = OsGetNextScanId (index, &state, &type)) != -1)
            as_target_state_change (index, id, state);
#else
        ATTO_DEV_LOG (KERN_INFO, ATTO_LOG_TARG, &(sh->shost_gendev),
                  "LinuxRescanHostRoutine index:%d\n", index);

        if ((id = OsGetNextScanId (index, &state, &type)) != -1)
        {
            int lun;
            struct scsi_device *scsi_dev;
            ATTO_DEV_LOG (KERN_INFO, ATTO_LOG_TARG, &(sh->shost_gendev),
                          "  scan %d:%d:%d\n", id, state, type);

#if defined (ATTO_RPORTS) || defined (ATTO_SAS_PORTS)
            if (use_transport_layer)
            {
#if defined (ATTO_RPORTS)
                switch (state)
                {
                case ATTO_DEVICE_STATE_PRESENT:
                    attotrans_add_rport(sh, id);
                    break;
                case ATTO_DEVICE_STATE_NOT_PRESENT:
                    attotrans_remove_rport(sh, id);
                    break;
                case ATTO_DEVICE_STATE_LUN_CHANGE:
                    attotrans_scan_rport(sh, id);
                    break;
                default:
                    break;
                }
#elif defined (ATTO_SAS_PORTS)
                mutex_lock (&esas_topology[index].sas_topology_mutex);

                switch (state)
                {
                case ATTO_DEVICE_STATE_PRESENT:
                    ATTO_DEV_LOG (KERN_INFO, ATTO_LOG_TOPOL,
                                  &(sh->shost_gendev),
                                  "PRESENT 0x%04x 0x%02x\n",
                                  id, type);
                    esas_topology_add_device (&esas_topology[index], id, type);
                    break;
                case ATTO_DEVICE_STATE_NOT_PRESENT:
                    ATTO_DEV_LOG (KERN_INFO, ATTO_LOG_TOPOL,
                                  &(sh->shost_gendev),
                                  "NOT_PRESENT 0x%04x 0x%02x\n",
                                  id, type);
                    esas_topology_remove_device (&esas_topology[index], id);
                    break;
                case ATTO_DEVICE_STATE_LUN_CHANGE:
                    ATTO_DEV_LOG (KERN_INFO, ATTO_LOG_TOPOL,
                                  &(sh->shost_gendev),
                                  "LUN_CHANGE 0x%04x 0x%02x\n",
                                  id, type);
                    esas_topology_scan_device (&esas_topology[index], id);
                    break;
                case ATTO_DEVICE_STATE_ACTIVE:
                    ATTO_DEV_LOG (KERN_INFO, ATTO_LOG_TOPOL,
                                  &(sh->shost_gendev),
                                  "ACTIVE 0x%04x 0x%02x\n",
                                  id, type);
                    esas_topology_activate_device (&esas_topology[index], id);
                    break;
                case ATTO_DEVICE_STATE_ACTIVE_INFO:
                    ATTO_DEV_LOG (KERN_INFO, ATTO_LOG_TOPOL,
                                  &(sh->shost_gendev),
                                  "ACTIVE_INFO 0x%04x 0x%02x\n",
                                  id, type);
                    esas_topology_validate_device (&esas_topology[index], id);
                    break;
                case ATTO_DEVICE_STATE_ACTIVE_LOCATION:
                    ATTO_DEV_LOG (KERN_INFO, ATTO_LOG_TOPOL,
                                  &(sh->shost_gendev),
                                  "ACTIVE_LOCATION 0x%04x 0x%02x\n",
                                  id, type);
                    esas_topology_remove_device (&esas_topology[index], id);
                    esas_topology_add_device (&esas_topology[index], id, type);
                    
                    break;
                case ATTO_DEVICE_STATE_INACTIVE:
                    ATTO_DEV_LOG (KERN_INFO, ATTO_LOG_TOPOL,
                                  &(sh->shost_gendev),
                                  "INACTIVE 0x%04x 0x%02x\n",
                                  id, type);
                    esas_topology_deactivate_device (&esas_topology[index], id);
                    break;
                default:
                    break;
                }

                mutex_unlock (&esas_topology[index].sas_topology_mutex);

#endif /* defined (ATTO_SAS_PORTS) */
                /* Reschedule this task to pick up any other notifications. */

                return;
            }
#endif /* ATTO_RPORTS || ATTO_SAS_PORTS */

            if ( state == ATTO_DEVICE_STATE_NOT_PRESENT
            || state == ATTO_DEVICE_STATE_LUN_CHANGE)
            {
                int found = 0;

                for (lun = 0; lun < ATTO_MAX_LUN; lun++)
                {
                    scsi_dev = scsi_device_lookup (sh, 0, id, lun);

                    if (scsi_dev)
                    {
                        found = 1;

                        /* XXX: SDEV_DEL instead? */
                        scsi_device_set_state (scsi_dev, SDEV_OFFLINE);

                        ATTO_DEV_LOG (KERN_INFO, ATTO_LOG_TARG,
                                      &(scsi_dev->sdev_gendev),
                                      "scsi_remove_device() called for 0:%d:%d\n",
                                      id, lun);
                        scsi_remove_device (scsi_dev);
                        ATTO_DEV_LOG (KERN_INFO, ATTO_LOG_TARG,
                                      &(scsi_dev->sdev_gendev),
                                      "scsi_device_put() called\n");
                        scsi_device_put (scsi_dev);
                    }
                }
                if (!found)
                {
                    ATTO_DEV_LOG (KERN_INFO, ATTO_LOG_TARG,
                                  &(sh->shost_gendev),
                                  "No LUNs found for target %d\n", id);
                }
            }
            if (state == ATTO_DEVICE_STATE_PRESENT
            ||  state == ATTO_DEVICE_STATE_LUN_CHANGE)
            {
                for (lun = 0; lun < ATTO_MAX_LUN; lun++)
                {
                    int ret = 0;

                    scsi_dev = scsi_device_lookup (sh, 0, id, lun);

                    if (scsi_dev)
                    {
                        ATTO_DEV_LOG (KERN_INFO, ATTO_LOG_TARG,
                                      &(scsi_dev->sdev_gendev),
                                      "scsi device already exists\n");
                        scsi_device_put (scsi_dev);
                    }
                    else
                    {
                        ATTO_DEV_LOG (KERN_INFO, ATTO_LOG_TARG,
                                      &(sh->shost_gendev),
                                      "scsi_add_device() called for 0:%d:%d\n",
                                      id, lun);
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,14) && !defined (__VMKLNX__)
                        scsi_dev = scsi_add_device (sh, 0, id, lun);
                        if (IS_ERR(scsi_dev))
                        {
#else
                        ret = scsi_add_device (sh, 0, id, lun);
                        if (ret)
                        {
#endif
                            ATTO_DEV_LOG (KERN_ERR, ATTO_LOG_TARG,
                                          &(sh->shost_gendev),
                                          "scsi_add_device failed with %d\n",
                                          ret);
                        }
                    }
                }
            }
#endif /* ATTO_AS_STACK_SUPPORT */
        }
    }
}

static int atto_check_work (int index)
{
    if ((OsWorkAllowed(index) && (OsRescanWaiting(index)))
#ifdef _MP_
     || OsMpWorkPending(index)
#endif
     || kthread_should_stop())
        return 1;
    else
        return 0;
}

/* This is the "main" routine for the adapter worker thread. */
static int atto_do_work (void *_data)
{
    int index = (int)((long)_data);
    struct Scsi_Host *sh;
    int ret;

    if ((index < 0) || (index >= ATTO_MAX_DEVICES))
        return 0;

    sh = (struct Scsi_Host *) OsGetAdapterHost (index);

    set_user_nice(current, -20);

    ATTO_DEV_LOG(KERN_INFO, ATTO_LOG_INIT, &(sh->shost_gendev),
                 "worker thread running\n");

    while (!kthread_should_stop())
    {

        ret = wait_event_interruptible(atto_waitq[index], atto_check_work(index) || kthread_should_stop());

        if (ret)
            break;

#ifdef _MP_

        /* Multipathing code does additional work besides handling rescans. */
        /* It will call LinuxAddRemoveTarget as necessary. OsMpWorkRoutine  */
        /* will return -1 if there's nothing else to do, otherwise it       */
        /* returns the number of milliseconds to wait before calling again. */
        /* This helps in throttling commands during MP discovery/activation.*/

        if (OsMpWorkPending(index))
        {
            ret = OsMpWorkRoutine (index);
            /* We can spend a lot of time in MP work routine, and go right */
            /* back into it after a short delay. So, give up the cpu here  */
            /* so we don't get caught by the watchdog.                     */
            schedule();
            if (ret > 0)
                mdelay(ret);
        }
#endif

        if ((OsWorkAllowed(index)) && (OsRescanWaiting(index)))
        {
            LinuxRescanHostRoutine (index);
        }
    }

    atto_thread[index] = NULL;

    ATTO_DEV_LOG(KERN_INFO, ATTO_LOG_INIT, &(sh->shost_gendev),
                 "worker thread stopping\n");

    return 0;
}


#ifdef _MP_

void LinuxUpdateDevice (void *_sh, unsigned int tid, int lun, enum AttoDeviceAction action)
{
    struct Scsi_Host *sh = _sh;
    struct scsi_device *sdev = scsi_device_lookup (sh, 0, tid, lun);

    switch (action)
    {
    case ATTO_DEVICE_ACTION_ONLINE:
        if (sdev)
        {
            ATTO_DEV_LOG (KERN_INFO, ATTO_LOG_SCSI, &(sdev->sdev_gendev),
                          "scsi_device_set_state(ONLINE, %d,%d) called\n", tid, lun);
            scsi_device_set_state( sdev, SDEV_RUNNING );
        }
        break;

    case ATTO_DEVICE_ACTION_OFFLINE:
        if (sdev)
        {
            ATTO_DEV_LOG (KERN_INFO, ATTO_LOG_SCSI, &(sdev->sdev_gendev),
                          "scsi_device_set_state(OFFLINE, %d,%d) called\n", tid, lun);
            scsi_device_set_state( sdev, SDEV_OFFLINE );
        }
        break;

    case ATTO_DEVICE_ACTION_RESCAN:
        if (sdev)
        {
            ATTO_DEV_LOG (KERN_INFO, ATTO_LOG_SCSI, &(sh->shost_gendev),
                          "scsi_rescan_device(%d,%d) called\n", tid, lun);
            scsi_rescan_device(&(sdev->sdev_gendev));
        }
        break;

    case ATTO_DEVICE_ACTION_ADD:
        if (sdev)
        {
            ATTO_DEV_LOG (KERN_ERR, ATTO_LOG_SCSI, &(sh->shost_gendev),
                          "Attempt to add existing device (%d,%d)\n",
                          tid, lun);
        }
        else
        {
            ATTO_DEV_LOG (KERN_INFO, ATTO_LOG_SCSI, &(sh->shost_gendev),
                          "scsi_add_device(%d,%d) called\n", tid, lun);
            scsi_add_device (sh, 0, tid, lun);
        }
        break;
   
    case ATTO_DEVICE_ACTION_REMOVE:
        if (!sdev)
        {
            ATTO_DEV_LOG (KERN_ERR, ATTO_LOG_SCSI, &(sh->shost_gendev),
                          "Attempt to remove non-existent device (%d,%d)\n",
                          tid, lun);
        }
        else
        {
            ATTO_DEV_LOG (KERN_INFO, ATTO_LOG_SCSI, &(sdev->sdev_gendev),
                          "scsi_device_set_state(SDEV_OFFLINE) called\n");

            /* XXX: SDEV_DEL instead? */
            scsi_device_set_state (sdev, SDEV_OFFLINE);

            ATTO_DEV_LOG (KERN_INFO, ATTO_LOG_SCSI, &(sdev->sdev_gendev),
                          "scsi_remove_device() called\n");
            scsi_remove_device (sdev);
        }
        break;

    default:
        ATTO_DEV_LOG (KERN_INFO, ATTO_LOG_TARG, &(sdev->sdev_gendev),
                      "Unhandled device action: %d\n", action);

        break;
    }

    if (sdev)
        scsi_device_put (sdev);

}

#endif /* _MP_ */

#endif /* ATTO_RESCANS_ENABLED */

void LinuxScheduleWork (unsigned int index)
{
#ifdef ATTO_RESCANS_ENABLED
    if (index >= ATTO_MAX_DEVICES)
    {
        printk (DEBUG_HEADER "LinuxScheduleWork tried to use an invalid index.\n");
        return;
    }

    if ( OsWorkAllowed(index) )
    {
        wake_up (&atto_waitq[index]);
    }

#else
    printk (DEBUG_HEADER "LinuxScheduleWork called for 2.4 kernel.\n");
#endif
}


static struct tasklet_struct atto_tasklet [ATTO_MAX_DEVICES];

void *LinuxDpcInit (unsigned int index, void *callback)
{
    if (index >= ATTO_MAX_DEVICES)
    {
        printk (DEBUG_HEADER "LinuxDpcInit tried to initialize an invalid index.\n");
        return NULL;
    }

    memset (&atto_tasklet [index], 0, sizeof (struct tasklet_struct));

    tasklet_init (&atto_tasklet [index],
                  (void (*)(unsigned long)) callback,
                  (unsigned long) index);

    return &atto_tasklet [index];
}


void LinuxDpcQueue (void *dpc_context)
{
    tasklet_hi_schedule (dpc_context);
}

void LinuxDpcStop (unsigned int index)
{
    if (index >= ATTO_MAX_DEVICES)
    {
        printk (DEBUG_HEADER "LinuxDpcStop tried to stop an invalid index.\n");
        return;
    }

    /* Remove the tasklet from the queue. If it's currently scheduled */
    /* this function will wait for it to complete.                    */
    tasklet_kill (&atto_tasklet [index]);

    return;
}

void LinuxWorkerStart(unsigned int index)
{
#ifdef ATTO_RESCANS_ENABLED
    init_waitqueue_head(&atto_waitq[index]);
    atto_thread [index] = kthread_run (atto_do_work, (void *)((long) index),
                                       "%s%d", ATTO_DRVR_NAME, index);
#endif
}

void LinuxWorkerStop(unsigned int index)
{
#ifdef ATTO_RESCANS_ENABLED
    /* NOTE: kthread_stop() will request that the thread should stop */
    /* and then wait until it does. No additional sync is needed.    */
    if (atto_thread[index] != NULL)
        kthread_stop (atto_thread[index]);
#endif /* ATTO_RESCANS_ENABLED */
}




void LinuxDisableIrq (unsigned int irq)
{
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,5,0)
    disable_irq (irq);
#endif
}


void LinuxEnableIrq (unsigned int irq)
{
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,5,0)
    enable_irq (irq);
#endif
}


void LinuxUnregisterScsiHost (void *_host)
{
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0)
    struct Scsi_Host *host = _host;

    if (host)
    {
#if defined (ATTO_USE_TRANSPORT) && LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,12) \
         && (defined (CELERITYFC) || defined (FASTFRAME))
        if (use_transport_layer)
        {
            ATTO_DEV_LOG (KERN_INFO, ATTO_LOG_XPORT, &(host->shost_gendev),
                          "fc_remove_host() called\n");
            fc_remove_host (host);
        }
#elif defined (ESASHBA) && defined (ATTO_USE_TRANSPORT) && (LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,18) || defined (ATTO_SLES10SP34))
        if (use_transport_layer)
        {
            ATTO_DEV_LOG (KERN_INFO, ATTO_LOG_XPORT, &(host->shost_gendev),
                          "sas_remove_host() called\n");
            sas_remove_host (host);
        }
#endif
        ATTO_DEV_LOG (KERN_INFO, ATTO_LOG_SCSI, &(host->shost_gendev),
                      "scsi_remove_host() called\n");
        scsi_remove_host (host);
        ATTO_DEV_LOG (KERN_INFO, ATTO_LOG_SCSI, &(host->shost_gendev),
                      "scsi_host_put() called\n");
        scsi_host_put (host);
    }
#endif
}


void LinuxUnregisterPci (void *_pcid)
{
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0)
    struct pci_dev *pcid = (struct pci_dev *) _pcid;

    if (pcid)
    {
        ATTO_DEV_LOG (KERN_INFO, ATTO_LOG_INIT, &pcid->dev,
                      "pci_disable_device() called.  msix_enabled:%d msi_enabled:%d pin:%d irq:%d\n",
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,18)
                      pcid->msix_enabled,
                      pcid->msi_enabled,
                      pcid->pin,
#else
                      0, 0, 0,
#endif
                      pcid->irq);

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,20)
    ATTO_DEV_LOG (KERN_INFO, ATTO_LOG_PCI, &pcid->dev,
                  "before pci_disable_device() enable_cnt:%d\n",
                  pcid->enable_cnt.counter);
#endif

        pci_disable_device (pcid);

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,20)
        ATTO_DEV_LOG (KERN_INFO, ATTO_LOG_INIT, &pcid->dev,
                      "after pci_disable_device() enable_cnt:%d\n", pcid->enable_cnt.counter);
#endif

        ATTO_DEV_LOG (KERN_INFO, ATTO_LOG_PCI, &pcid->dev,
                  "pci_set_drv_data(%p, NULL) called\n", pcid);
        pci_set_drvdata (pcid, NULL);
    }
#endif
}

void LinuxResetDetected (void *_sh, int channel)
{
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0)
    struct Scsi_Host *sh = (struct Scsi_Host *) _sh;

    if (sh)
    {
        ATTO_DEV_LOG (KERN_INFO, ATTO_LOG_SCSI, &(sh->shost_gendev),
                      "scsi_report_bus_reset() called; channel %d\n", channel);
        scsi_report_bus_reset (sh, channel);
    }
#endif
}


void LinuxAcquireSpinLock (void *_lock, unsigned long *_flags)
{
    spinlock_t *lock = (spinlock_t *) _lock;
    spin_lock_irqsave (lock, *(_flags));
}


void LinuxReleaseSpinLock (void *_lock, unsigned long *_flags)
{
    spinlock_t *lock = (spinlock_t *) _lock;
    spin_unlock_irqrestore (lock, *(_flags));
}


int LinuxIsSpinLockHeld (void *_lock)
{
    spinlock_t *lock = (spinlock_t *) _lock;
    return spin_is_locked (lock);
}


void *LinuxInitSpinLock (void)
{
    /* On some non-SMP systems, sizeof (spinlock_t) is 0, and      */
    /* vmalloc crashes when asked to allocate 0 bytes.  So we add  */
    /* a little bit of space to ensure that we allocate something. */

    spinlock_t *lock;

    if ((lock = (spinlock_t *) vmalloc (sizeof (*lock) + sizeof (int))) != NULL)
        spin_lock_init (lock);

    return lock;
}


void LinuxUninitSpinLock (void *lock)
{
    if (lock)
        vfree (lock);
}


int LinuxGetPageSize (void)
{
    return PAGE_SIZE;
}


void LinuxOutb (unsigned char v, unsigned long a)
{
    outb (v, a);
}


unsigned char LinuxInb (unsigned long a)
{
    return inb (a);
}


int LinuxSetDmaMask (void *_pdev, int size)
{
    u64 dma_mask = DMA_BIT_MASK (size);

    if ((size != 32) && (size != 64))
    {
        printk (DEBUG_HEADER "LinuxSetDmaMask invalid size %d!?\n", size);
        return 0;
    }

    /* Separate setting the coherent mask and the DMA mask. */
    /* Set the coherent mask to the requested value.        */

#ifdef dma_set_coherent_mask
    if (dma_set_coherent_mask (dev_from_pdev (_pdev), dma_mask) != 0)
#else
    if (pci_set_consistent_dma_mask ((struct pci_dev *) (_pdev), dma_mask) != 0)
#endif
    {
        printk (DEBUG_HEADER "Error setting %d-bit coherent DMA mask!\n", size);
        return 0;
    }

    /* Set the DMA mask to 64 bits, unless forced down to 32 bits */
    /* via a module parameter.                                    */
    /* NOTE: Celerity 8 can only access 36bits of memory, which   */
    /* gives us 512GB of physical RAM.  We're consciously setting */
    /* the mask to 64 bits, assuming system using our 8Gb card    */
    /* with > 512Gb of RAM are unlikely.  Should that actually    */
    /* happen, the I/O will fail and the user will have to set    */
    /* force_low_dma=1 when loading our module.                   */

    dma_mask = DMA_BIT_MASK( 64 );
#ifdef IFF_CELERITY8FC
    if (force_low_dma == 1)
        dma_mask = DMA_BIT_MASK( 32 );
#endif

    if (dma_set_mask (dev_from_pdev (_pdev), dma_mask) != 0)
        printk (DEBUG_HEADER "Error setting 0x%llx DMA mask!\n", dma_mask);

    return 1;
}


char *LinuxGetKernelVersion (void)
{
    return UTS_RELEASE;
}


void LinuxYield (void)
{
#ifdef __VMKLNX__
    return;
#else
#if LINUX_VERSION_CODE > KERNEL_VERSION(2,5,0)
    /* Yield the CPU if we are doing something potentially */
    /* time-consuming.  However, this is not safe to do    */
    /* in certain contexts, because it will schedule().    */

    if (!in_atomic () && !irqs_disabled ())
        cond_resched ();
#endif
#endif
}


int LinuxGetErrno (int atto_errno)
{
    switch (atto_errno)
    {
    case ATTO_BUSY:           return -EBUSY;
    case ATTO_NO_DEVICE:      return -ENODEV;
    case ATTO_NOT_IMPLMNTD:   return -ENOSYS;
    case ATTO_INVALID_ARG:    return -EINVAL;
    case ATTO_OUT_OF_MEMORY:  return -ENOMEM;
    case ATTO_EFBIG:          return -EFBIG;     /* File too big */
    case ATTO_ENOSPC:         return -ENOSPC;    /* No space left on device */
    }

    return -ENOSYS;
}


#define POINTER_TO_DWORD(x)    ((unsigned int) (unsigned long) (x))

void LinuxExchangeOffsets (PSCSICMD_OFFSETS scsicmd_off,
                           int pci_dev_offset)
{
    Scsi_Cmnd *null_cmd = NULL;

    scsicmd_off->scsi_done_offset    = POINTER_TO_DWORD (&null_cmd->scsi_done);
    scsicmd_off->cmd_len_offset      = POINTER_TO_DWORD (&null_cmd->cmd_len);
    scsicmd_off->sense_buffer_offset = POINTER_TO_DWORD (&null_cmd->sense_buffer);
    scsicmd_off->data_dir_offset     = POINTER_TO_DWORD (&null_cmd->sc_data_direction);
    scsicmd_off->cmnd_offset         = POINTER_TO_DWORD (&null_cmd->cmnd);
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,25)
    scsicmd_off->req_bufflen_offset  = POINTER_TO_DWORD (&null_cmd->request_bufflen);
    scsicmd_off->req_buffer_offset   = POINTER_TO_DWORD (&null_cmd->request_buffer);
    scsicmd_off->use_sg_offset       = POINTER_TO_DWORD (&null_cmd->use_sg);
#else
    scsicmd_off->req_bufflen_offset  = POINTER_TO_DWORD (&null_cmd->sdb.length);
    scsicmd_off->req_buffer_offset   = POINTER_TO_DWORD (&null_cmd->sdb.table.sgl);
    scsicmd_off->use_sg_offset       = POINTER_TO_DWORD (&null_cmd->sdb.table.nents);
    scsicmd_off->flags               = SCSICMD_FLAGS_USE_SENSE_PTR;
#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,25)
    scsicmd_off->flags              |= SCSICMD_FLAGS_USE_CMD_PTR;
#endif
#endif
    scsicmd_off->sense_buffer_size   = SCSI_SENSE_BUFFERSIZE;
    scsicmd_off->data_dir_unknown    = SCSI_DATA_UNKNOWN;
    scsicmd_off->data_dir_write      = SCSI_DATA_WRITE;
    scsicmd_off->data_dir_read       = SCSI_DATA_READ;
    scsicmd_off->data_dir_none       = SCSI_DATA_NONE;
    scsicmd_off->tag_value_head      = HEAD_OF_QUEUE_TAG;
    scsicmd_off->tag_value_simple    = SIMPLE_QUEUE_TAG;
    scsicmd_off->tag_value_ordered   = ORDERED_QUEUE_TAG; 

    scsicmd_off->error_success       = DID_OK;
    scsicmd_off->error_abort         = DID_ABORT;
    scsicmd_off->error_error         = DID_ERROR;
    scsicmd_off->error_no_connect    = DID_NO_CONNECT;
    scsicmd_off->error_reset         = DID_RESET;
    scsicmd_off->error_busy          = DID_BUS_BUSY;

    global_pci_dev_offset = pci_dev_offset;
}

/* The do_div macro is NOT defined in the vmklinux API. It is currently    */
/* only used for performance tracking/reporting in the core. However, this */
/* method must not be used when building vmware drivers!                   */

void LinuxDivideQwords (unsigned long long *Numerator,
                        unsigned int       *Denominator,
                        unsigned long long *Result)
{
    unsigned long long tmp = (*Numerator);
    do_div (tmp, (*Denominator));
    (*Result) = tmp;
}


void *LinuxGetReqBuffer (void *_cmd, unsigned int *BuffLength)
{
#ifdef ATTO_CUSTOM_STACK_SUPPORT
    return NULL;
#else
    Scsi_Cmnd *cmd = (Scsi_Cmnd *) _cmd;

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,23)
    struct scatterlist *sgl = (struct scatterlist *) cmd->request_buffer;
    int sg_count = cmd->use_sg;
    unsigned int request_bufflen = cmd->request_bufflen;
#else
    struct scatterlist *sgl = (struct scatterlist *) scsi_sglist (cmd);
    int sg_count = scsi_sg_count (cmd);
    unsigned int request_bufflen = scsi_bufflen (cmd);
#endif
    /* See the comment in the VMkernel source code in file                */
    /* drivers/ata/libata-scsi.c, ata_scsi_rbuf_get(). There is a         */
    /* problem with the implementation of kmap_atomic(). And, it's        */
    /* possible to run out of buffer space if only the first sg element   */
    /* is used. The following change is based on the VMware solution.     */
    /* The only additional requirement is that the buffer returned in     */
    /* LinuxReleaseReqBuf() MUST BE the same as the one returned here.    */
    unsigned char *buf;

    if (sg_count)
    {
        *BuffLength = request_bufflen;
        buf = kmalloc(*BuffLength, GFP_ATOMIC);
        if (buf == NULL)
            *BuffLength = 0;
        else
        {
#if defined(ATTO_VMK_50) || (LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,27))
            sg_copy_to_buffer(sgl, sg_count, buf, *BuffLength);
#else
            {
                int i;
                unsigned char *buf2;
                for (buf2 = buf, i = 0; i < sg_count; i++, sgl++)
                {
                    memcpy (buf2, phys_to_virt(sg_dma_address(sgl)),
                            sg_dma_len(sgl));
                    buf2 += sg_dma_len(sgl);
                }
            }
#endif
        }
    }
    else
    {
        buf = (void *)sgl;
        *BuffLength = request_bufflen;
    }

    return buf;

#endif /* ATTO_CUSTOM_STACK_SUPPORT */
}


void LinuxReleaseReqBuffer (void *_cmd, void *_buf)
{
#ifdef ATTO_CUSTOM_STACK_SUPPORT
    return;
#else
    Scsi_Cmnd *cmd = (Scsi_Cmnd *) _cmd;
    unsigned char *buf = (unsigned char *) _buf;

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,23)
    struct scatterlist *sgl = (struct scatterlist *) cmd->request_buffer;
    int sg_count = cmd->use_sg;
#else
    struct scatterlist *sgl = (struct scatterlist *) scsi_sglist (cmd);
    int sg_count = scsi_sg_count (cmd);
#endif

    /* See the comment in LinuxGetReqBuffer() */
    if (sg_count)
    {
#if defined(ATTO_VMK_50) || (LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,27))
        sg_copy_from_buffer(sgl, sg_count, buf, scsi_bufflen(cmd));
#else
        {
            int i;
            unsigned char *buf2;
            for (buf2 = buf, i = 0; i < sg_count; i++, sgl++)
            {
                memcpy(phys_to_virt(sg_dma_address(sgl)), buf2,
                       sg_dma_len(sgl));
                buf2 += sg_dma_len(sgl);
            }
        }
#endif
        kfree(buf);
        return;
    }
#endif /* ATTO_CUSTOM_STACK_SUPPORT */
}


int LinuxInRecovery (void *_sh)
{
    struct Scsi_Host *sh = (struct Scsi_Host *) _sh;

    return (sh->shost_state == SHOST_RECOVERY
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,14)
        ||  sh->shost_state == SHOST_CANCEL_RECOVERY
        ||  sh->shost_state == SHOST_DEL_RECOVERY
#endif
            );
}


#if defined (ESASRAID) || defined (ESASRAID2) || defined (ESAS4HBA) || defined (_MP_)
#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,0)
extern attocfg_fire_async_event fire_async_event;

void LinuxFireEvent (void *data, int len)
{
    if (!fire_async_event)
    {
        ATTO_LOG (KERN_WARNING, ATTO_LOG_EVENT,
                  "Error sending event message - handler not registered.\n");
        return;
    }

    if (!(*fire_async_event) (data, len))
        printk (DEBUG_HEADER "Error sending event message.\n");
}
#else

void LinuxFireEvent (void *data, int len)
{
    printk (DEBUG_HEADER "VDA event occurred, but not supported on this kernel.\n");
}

#endif
#endif /* ESASRAID(2) || ESAS4HBA || _MP_*/

#ifdef ESASHBA
#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,0)
extern attocfg_fire_async_event fire_bb_event;

void LinuxFireBbEvent (void *data, int len)
{
    if (!fire_bb_event)
    {
        printk (DEBUG_HEADER "Error sending event message - handler not registered.\n");
        return;
    }

    if (!(*fire_bb_event) (data, len))
        printk (DEBUG_HEADER "Error sending event message.\n");
}
#else

void LinuxFireBbEvent (void *data, int len)
{
    printk (DEBUG_HEADER "BB event occurred, but not supported on this kernel.\n");
}

#endif
#endif /* ESASHBA */

#if defined(ESASRAID) || defined(ESASRAID2) \
    || (defined(ESASHBA) && !defined(ESAS2HBA) && !defined(ESAS3HBA) && !defined(ESAS4HBA))
void *LinuxPciFindDevice (unsigned int vendor, unsigned int device, void *_prev)
{
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,25)
    return (void *) pci_get_device  (vendor, device, (struct pci_dev *) _prev);
#else
    return (void *) pci_find_device (vendor, device, (struct pci_dev *) _prev);
#endif
}

void LinuxPciReleaseDevice (void *_pdev)
{
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,25)
    struct pci_dev *pdev = (struct pci_dev *) _pdev;

    pci_dev_put (pdev);
#endif
}

void *LinuxGetBridgePdev (void *_pdev)
{
    struct pci_dev *pdev = (struct pci_dev *) _pdev;
    struct pci_bus *bus = NULL;
    struct pci_dev *bus_pdev = NULL;

    if ((pdev == NULL)
    || ((bus = pdev->bus) == NULL)
    || ((bus_pdev = bus->self) == NULL))
    {
        printk (DEBUG_HEADER "Error accessing bridge config space (%p, %p, %p)\n",
                pdev, bus, bus_pdev);
        return NULL;
    }

    return bus_pdev;
}
#endif

void LinuxVerifyMemoryForIO (unsigned long long addr, unsigned int len)
{
}

void LinuxScsiStateChange (void *_host)
{
}

void LinuxScsiUnregisterHost (void *_host)
{
#ifdef __VMKLNX__
    return;
#else
    struct Scsi_Host *host = (struct Scsi_Host *) _host;

    ATTO_DEV_LOG (KERN_INFO, ATTO_LOG_SCSI, &(host->shost_gendev),
                  "scsi_unregister() called\n");
    scsi_unregister (host);
#endif
}

/* Generic implementation of the Linux completion api. */

void *LinuxCompletionAlloc(void)
{
#ifdef ATTO_COMPLETION
    struct completion *cmpl = vmalloc (sizeof (struct completion));
    
    if (cmpl == NULL)
    {
        printk (DEBUG_HEADER "Error: Unable to allocate memory for completion struct.\n");
        return NULL;
    }

    init_completion(cmpl);

    return cmpl;
#else
    printk (DEBUG_HEADER "Warning: Linux Completion API not available.\n");
    return NULL;
#endif
}

void LinuxCompletionFree (void *_cmpl)
{
#ifdef ATTO_COMPLETION
    if (_cmpl != NULL)
        vfree (_cmpl);
#else
    printk (DEBUG_HEADER "Warning: Linux Completion API not available.\n");
#endif
    return;
}

void LinuxCompletionInit (void *_cmpl)
{
#ifdef ATTO_COMPLETION
    struct completion *cmpl = (struct completion *)_cmpl;

    if (cmpl == NULL)
    {
        printk (DEBUG_HEADER "Error: Unable to init completion struct.\n");
        return;
    }

    init_completion (cmpl);
#else
    printk (DEBUG_HEADER "Warning: Linux Completion API not available.\n");
#endif
    return;
}

void LinuxCompletionWait (void *_cmpl)
{
#ifdef ATTO_COMPLETION
    struct completion *cmpl = (struct completion *)_cmpl;

    wait_for_completion (cmpl);
#else
    printk (DEBUG_HEADER "Warning: Linux Completion API not available.\n");
#endif
    return;
}

void LinuxCompletionDone (void *_cmpl)
{
#ifdef ATTO_COMPLETION
    struct completion *cmpl = (struct completion *)_cmpl;

    complete (cmpl);
#else
    printk (DEBUG_HEADER "Warning: Linux Completion API not available.\n");
#endif
    return;
}

unsigned long LinuxCompletionWaitTimeout (void *_cmpl, unsigned long timeout /* msecs */)
{
    unsigned long timeleft = timeout;
#ifdef ATTO_COMPLETION
    struct completion *cmpl = (struct completion *)_cmpl;

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,11)
    timeleft = wait_for_completion_timeout (cmpl, msecs_to_jiffies (timeout));
#else
    printk (DEBUG_HEADER "wait_for_completion_timeout not implemented; ignoring timeout value.\n");
    wait_for_completion (cmpl);
#endif 

#else
    printk (DEBUG_HEADER "Warning: Linux Completion API not available.\n");
#endif
    return timeleft;
}

unsigned long LinuxCompletionWaitTimeoutInterruptible (void *_cmpl, unsigned long timeout /* msecs */)
{
    unsigned long timeleft = timeout;
#ifdef ATTO_COMPLETION
    struct completion *cmpl = (struct completion *)_cmpl;

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,11)
    timeleft = wait_for_completion_interruptible_timeout (cmpl, msecs_to_jiffies (timeout));
#else
    printk (DEBUG_HEADER "wait_for_completion_timeout_interruptible not implemented; ignoring timeout value.\n");
    wait_for_completion (cmpl);
#endif 

#else
    printk (DEBUG_HEADER "Warning: Linux Completion API not available.\n");
#endif
    return timeleft;
}


#ifdef __VMKLNX__
/* The VMkernel extends scsi_device to contain a dump_active field. */
/* This field is set when the VMkernel is dumping core. We need to  */
/* know this so that commands get completed during the dump phase.  */
int LinuxCmdGetDumpActive (void *_cmd)
{
    struct scsi_cmnd *cmd = (struct scsi_cmnd *)_cmd;
    struct scsi_device *sdev;

    if (cmd == NULL)
        return 0;

    sdev = cmd->device;
    if (sdev == NULL)
        return 0;

    return sdev->dumpActive;
}

#endif
void *LinuxGetHostDataFromScsiDev (void *_scsi_dev, int *target_id)
{
    Scsi_Device *sd = (Scsi_Device *) _scsi_dev;

    if (target_id)
        (*target_id) = sd->id;

    return sd->host->hostdata;
}

#ifdef ATTO_USE_NPIV

void LinuxSetVPortState (void *_shost, int newState)
{
    enum fc_port_state state;
    struct Scsi_Host *shost = (struct Scsi_Host *) _shost;
    struct fc_vport *vport;

    if (!shost)
    {
        ATTO_LOG (KERN_WARNING, ATTO_LOG_NPIV,
                  "LinuxSetVPortState called with NULL host\n");
        return;
    }

    ATTO_DEV_LOG (KERN_INFO, ATTO_LOG_NPIV, &(shost->shost_gendev),
                  "LinuxSetVPortState newstate:%d\n", newState);


    vport = dev_to_vport (shost->shost_gendev.parent);
    if (!vport)
    {
        ATTO_DEV_LOG (KERN_WARNING, ATTO_LOG_NPIV, &(shost->shost_gendev),
                      "LinuxSetVPortState called with NULL vport\n");
        return;
    }

    switch (newState)
    {
    case ATTO_NPIV_STATE_UNKNOWN:
        state = FC_VPORT_UNKNOWN;
        break;
    case ATTO_NPIV_STATE_ACTIVE:
        state = FC_VPORT_ACTIVE;
        break;
    case ATTO_NPIV_STATE_DISABLED:
        state = FC_VPORT_DISABLED;
        break;
    case ATTO_NPIV_STATE_LINKDOWN:
        state = FC_VPORT_LINKDOWN;
        break;
    case ATTO_NPIV_STATE_INITIALIZING:
        state = FC_VPORT_INITIALIZING;
        break;
    case ATTO_NPIV_STATE_NO_FABRIC:
        state = FC_VPORT_NO_FABRIC_SUPP;
        break;
    case ATTO_NPIV_STATE_FAB_RSRC:
        state = FC_VPORT_NO_FABRIC_RSCS;
        break;
    case ATTO_NPIV_STATE_LOGGINGOUT:
        state = FC_VPORT_FABRIC_LOGOUT;
        break;
    case ATTO_NPIV_STATE_REJECT_WWN:
        state = FC_VPORT_FABRIC_REJ_WWN;
        break;
    case ATTO_NPIV_STATE_FAILED:
        state = FC_VPORT_FAILED;
        break;
    default:
        state = FC_VPORT_UNKNOWN;
        break;
    }

    if (state != vport->vport_state)
    {
        vport->vport_last_state = vport->vport_state;
        vport->vport_state = state;
    }
}
#endif /* ATTO_USE_NPIV */

uint32_t LinuxRegisterStack (void *param1, void *param2)
{
#ifdef ATTO_AS_STACK_SUPPORT
    return AS_RegisterHwIntf (param1, param2);
#else
    return -1;
#endif
}

uint32_t LinuxUnregisterStack (void *param)
{
#ifdef ATTO_AS_STACK_SUPPORT
    return AS_UnregisterHwIntf (param);
#else
    return -1;
#endif
}

#ifdef ESASHBA
int LinuxListSasDevices(int index, char *buffer)
{
    int len = 0;
#if defined (ATTO_TRANSPORT) && defined (ATTO_SAS_PORTS)
    if (use_transport_layer)
        len = esas_topology_list_devices (&esas_topology[index], buffer);
#endif
    return len;
}

extern int num_targets;

int LinuxGetSgId (int index, int target)
{
    int sgid = num_targets;

#if defined (ATTO_TRANSPORT) && defined (ATTO_SAS_PORTS)

    /* The SG Id should be the same as the order in which the target device */
    /* was added to the mid-layer, which is the same as it's relative order */
    /* in the list of esas devices in the topology.                         */
    sgid = esas_topology_get_device_relative_order(&esas_topology[index], target);
#endif

    return sgid;

}

#endif /* ESASHBA */



int LinuxCopyProcBuffer (void *buffer, char **start, char ProcBuffer[], int offset, int size, int len)
{
#if (LINUX_VERSION_CODE < KERNEL_VERSION(3,10,0))
   if (offset > size - 1)
    {
        *start      = NULL;
        len         = 0;
    }
    else
    {
        *start = buffer;

        if (size - offset < len)
            len = size - offset;

        memcpy (buffer, &ProcBuffer [offset], len);
    }
#else
   if (offset > size - 1)
    {
        len         = 0;
    }
    else
    {
        if (size - offset < len)
            len = size - offset;
        
        seq_write((struct seq_file *)buffer, &ProcBuffer[offset], len);
    }
#endif


   return len;
}


#ifdef OS_32BIT
unsigned long long OsQwordDivDword( unsigned long long qw, unsigned long dw )
{
#ifdef div_long_long_rem
    long rem;

    return (unsigned long long)div_long_long_rem((u64)qw, (u32)dw, &rem);
#else
    unsigned int rem;

    return (unsigned long long)div_u64_rem((u64)qw, (u32)dw, (u32 *)&rem);
#endif
}
unsigned int OsQwordModDword( unsigned long long qw, unsigned long dw )
{
#ifdef div_long_long_rem
    long rem;

    div_long_long_rem((u64)qw, (u32)dw, &rem);
#else
    unsigned int rem;

    div_u64_rem((u64)qw, (u32)dw, (u32 *)&rem);
#endif
    return (unsigned int) rem;
}

unsigned long OsQwordModByte( unsigned long long qw, unsigned char b )
{
#ifdef div_long_long_rem
    long rem;

    div_long_long_rem((u64)qw, (u32)b, &rem);
#else
    unsigned int rem;

    div_u64_rem((u64)qw, (u32)b, (u32 *)&rem);
#endif
  return (unsigned int)rem;
}

#endif


unsigned int LinuxGetOnlineCPUCount(void)
{    

#ifdef __VMKLNX__

    return num_online_cpus();

#else

    uint32_t cpu;
    uint32_t i = 0;

    for_each_present_cpu( cpu ) 
    {
        if ( cpu_online( cpu ) )
            i++;
    }

    return (unsigned int) i;

#endif

}


unsigned int LinuxGetOnlineNodeCount(void)
{    
    return num_online_nodes();
}


int LinuxCpuToNode(int cpu)
{
    return cpu_to_node(cpu);
}

int LinuxCopyFromUser(void *src, void *dst, int size)
{
    return __copy_from_user (dst, src, size);
}
