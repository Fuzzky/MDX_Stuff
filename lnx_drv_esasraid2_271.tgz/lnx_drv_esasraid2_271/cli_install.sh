#!/bin/sh

# Script running in interactive or automatic mode?
if [ "$1" = "auto" ]; then
    INTERACTIVE=0
else
    INTERACTIVE=1
fi

CP=/bin/cp
CHMOD=/bin/chmod

# Subdirectory in package where CLI tools are stored
CLIDIR="cli"

DEFAULT_INSTALLDIR=/usr/local/sbin
if [ ! -d ${DEFAULT_INSTALLDIR} ]; then
  DEFAULT_INSTALLDIR=/usr/sbin
fi

# Installation directory for CLI tools
if [ "${INSTALLDIR}" = "" ]; then
  INSTALLDIR=$DEFAULT_INSTALLDIR
fi

echo
echo "ATTO Technology, Inc."
echo "CLI Tool Install Script v1.2"
echo

# Confirm with user the location of installation directory
if [ ${INTERACTIVE} -eq 1 ]; then
    echo "This script will install ATTO CLI tools on your system:"
    echo -n "Are you sure you want to proceed [Y/n]? "
    read RESPONSE
    echo 
    if [ "${RESPONSE}" != "y" -a "${RESPONSE}" != "Y" -a "${RESPONSE}" != "" ]; then
        echo
        echo "Installation aborted"
        echo
        exit 0
    fi
    echo -n "Tool Installation Directory [${INSTALLDIR}]: "
    read RESPONSE
    RESPONSE=`echo ${RESPONSE} | awk '{printf "%s", $0}'`
    echo
    if [ "${RESPONSE}" != "" ]; then
        INSTALLDIR=${RESPONSE}
    fi
fi

# Check existence of installation directory
if [ ! -d ${INSTALLDIR} ]; then
    echo "Error: Install directory '${INSTALLDIR}' does not exist. Exiting..."
    exit 1
fi

# Determine target arch - default will be 32 bit Linux
KERNEL=`uname -s`
ARCH=`uname -m | sed -e s/i.86/i386/`
if [ "$KERNEL" = "VMkernel" ]; then
    ARCHSUFFIX="vmw"
    CHMOD=chmod
else
if [ "$ARCH" = "x86_64" ]; then
    ARCHSUFFIX="x64"
else
    ARCHSUFFIX="32"
fi
fi

# Get a list of the 32 bit tools; all versions should be present
CLITOOLS=`cd cli; ls *_32`

# Install each CLI tool
for TOOL32 in ${CLITOOLS}; do

# The name of the tool
    TOOL=`echo ${TOOL32} | cut -d _ -f 1`

# Make sure the new one is executable
    ${CHMOD} 755 ${CLIDIR}/${TOOL}_${ARCHSUFFIX}

# Check if this tool is already installed
    INSTALLED=`which ${TOOL} 2>/dev/null`
    if [ "$INSTALLED" != "" ]; then
# If installed, get the installed and package version info
        IVERSION=`${TOOL} -v | awk '{printf "%s", $0}'`
        NVERSION=`${CLIDIR}/${TOOL}_${ARCHSUFFIX} -v | awk '{printf "%s", $0}'`
        if [ ${INTERACTIVE} -eq 1 ]; then
# Confirm the installation with the user
            echo "  A version of ${TOOL} is already installed in"
            echo "  ${INSTALLED}: ${IVERSION}."
            echo "  This package will install ${NVERSION}"
            if [ "${INSTALLED}" != "${INSTALLDIR}/${TOOL}" ]; then
                echo "  in ${INSTALLDIR}."
            fi
            echo -n "  Are you sure you want to proceed [Y/n]? "
            read RESPONSE
            echo
        else
# If not interactive, always replace
            RESPONSE="y"
        fi
    else
# If not already installed, then install now
        RESPONSE="y"
    fi

# Just hit enter, default to yes
    if [ "${RESPONSE}" = "" ]; then
        RESPONSE="y"
    fi

    if [ "${RESPONSE}" = "y" -o "${RESPONSE}" = "Y" ]; then
        ${CP} -p ${CLIDIR}/${TOOL}_${ARCHSUFFIX} ${INSTALLDIR}/${TOOL}
        if [ ${INTERACTIVE} -eq 1 ]; then
            echo "    installing ${TOOL}"
        fi
    else
        if [ ${INTERACTIVE} -eq 1 ]; then
            echo "    skipping ${TOOL}"
        fi
    fi
    echo
done

# All finished.
if [ ${INTERACTIVE} -eq 1 ]; then
    echo "Installation of ATTO CLI tools is complete."
    echo
fi