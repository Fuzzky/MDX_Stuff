#!/bin/bash
#script version
VERSION="2.21"

echo
echo "ATTO Technology, Inc."
echo "Linux Driver Uninstall Script v${VERSION}"
echo

# Make sure we are running in the directory where the script is located

SOURCE="${BASH_SOURCE[0]}"
while [ -h "$SOURCE" ]; do # resolve $SOURCE until the file is no longer a symlink
  DIR="$( cd -P "$( dirname "$SOURCE" )" && pwd )"
  SOURCE="$(readlink "$SOURCE")"
  [[ $SOURCE != /* ]] && SOURCE="$DIR/$SOURCE" # if $SOURCE was a relative symlink, we need to resolve it relative to the path where the symlink file was located
done
DIR="$( cd -P "$( dirname "$SOURCE" )" && pwd )"

cd $DIR

# First argument is driver name. If passed to this script, assume
# the user knows what they're doing and don't confirm the uninstall

DRIVER_NAME=$1
CONFIRM=0
BKUP_DRIVER_NAME="UNDEFINED"
AUX_DRIVER_NAME="UNDEFINED"

# Try to detect driver name based on core file
if [ "$DRIVER_NAME" == "" ]; then
    DRIVER_NAME=`ls src/*core_x86.o | cut -d_ -f1 | cut -d/ -f2`
    CONFIRM=1
fi

# If driver name not determined, then exit
if [ "$DRIVER_NAME" == "" ]; then
    echo
    echo "Error. Unable to detect driver name."
    exit 1
fi

# Determine name of backed-up driver
if [ "${DRIVER_NAME}" = "celerity8fc" ]; then
    BKUP_DRIVER_NAME="celerity8fcmp"
elif [ "${DRIVER_NAME}" = "celerity8fcmp" ]; then
    BKUP_DRIVER_NAME="celerity8fc"
elif [ "${DRIVER_NAME}" = "celerity16fc" ]; then
    BKUP_DRIVER_NAME="celerity16fc"
elif [ "${DRIVER_NAME}" = "celerity16fcmp" ]; then
    BKUP_DRIVER_NAME="celerity16fc"
elif [ "${DRIVER_NAME}" = "esas2hba" ]; then
    BKUP_DRIVER_NAME="pm8001"
elif [ "${DRIVER_NAME}" = "esas2raid" ]; then
    BKUP_DRIVER_NAME="esas2r"
elif [ "${DRIVER_NAME}" = "fastframe" ]; then
    BKUP_DRIVER_NAME="ixgbe"
    AUX_DRIVER_NAME="ffxgbe"
fi

if [ "$AUX_DRIVER_NAME" == "UNDEFINED" ]; then
    echo
    echo "Uninstalling and unloading the ATTO ${DRIVER_NAME} driver, please wait..."
    echo
else
    echo
    echo "Uninstalling and unloading the ATTO ${DRIVER_NAME} and ${AUX_DRIVER_NAME} drivers, please wait..."
    echo
fi

# Confirm request to unload/uninstall driver
if [ "$CONFIRM" == "1" ]; then
    if [ "$AUX_DRIVER_NAME" == "UNDEFINED" ]; then
        echo "Do you want to unload and uninstall ${DRIVER_NAME}?  [Y/n]"
    else
        echo "Do you want to unload and uninstall ${DRIVER_NAME} and ${AUX_DRIVER_NAME}?  [Y/n]"
    fi
    read -n 1 RESPONSE
    if [ "${RESPONSE}" == "n" -o "${RESPONSE}" == "N" ]; then
        echo
        echo "Exiting"
        exit 0;
    fi
fi

# Remove the installed driver, and any auxiliary driver (like ffxgbe)
FULL_KERNEL_VERSION=`uname -r`
MODULE_ROOT=/lib/modules/${FULL_KERNEL_VERSION}/kernel/drivers
rm -f ${MODULE_ROOT}/scsi/${DRIVER_NAME}.ko
if [ "$AUX_DRIVER_NAME" != "UNDEFINED" ]; then
    rm -f ${MODULE_ROOT}/net/${AUX_DRIVER_NAME}.ko
fi

# Unload the attocfg driver first, to remove that dependency on the HBA driver
# If an auxiliary driver (like ffxgbe) exists, unload that too
# Then unload the HBA driver
if lsmod | grep attocfg > /dev/null 2>/dev/null; then
    rmmod attocfg
fi

if lsmod | grep ${AUX_DRIVER_NAME} > /dev/null 2>/dev/null; then
	if [ "${AUX_DRIVER_NAME}" = "ffxgbe" ]
        then
		sh ./udev-rules.sh remove
        fi
    if ! rmmod ${AUX_DRIVER_NAME}; then
        echo "Sorry, could not unload ${AUX_DRIVER_NAME}."
        echo "You may need to reboot to completely unload the driver."
    fi
fi

if lsmod | grep ${DRIVER_NAME} | grep -v ${DRIVER_NAME}mp > /dev/null 2>/dev/null; then
    if ! rmmod ${DRIVER_NAME}; then
        echo "Sorry, could not unload ${DRIVER_NAME}."
        echo "You may need to reboot to completely unload the driver."
    fi
fi

BKUP_DRIVER_PRESENT=`find ${MODULE_ROOT} -name ${BKUP_DRIVER_NAME}.bkup`

if [ "${BKUP_DRIVER_PRESENT}" != "" ]; then
    echo
    echo "Backed up driver ${BKUP_DRIVER_NAME} found."
    if [ "$CONFIRM" == "1" ]; then
        echo "Do you want to restore and load ${BKUP_DRIVER_NAME}? [Y/n]"
        read -n 1 RESPONSE
	echo
    else
        echo "Restoring and loading ${BKUP_DRIVER_NAME}."
        RESPONSE="y"
    fi
    if [ "${RESPONSE}" != "n" -a "${RESPONSE}" != "Y" ]; then
        mv ${BKUP_DRIVER_PRESENT} ${BKUP_DRIVER_PRESENT/%.bkup/.ko}
        BKUP_DRIVER_PRESENT=${BKUP_DRIVER_PRESENT/%.bkup/.ko}
        depmod
        if ! modprobe ${BKUP_DRIVER_NAME}; then
            echo
            echo "Sorry, could not load ${BKUP_DRIVER_NAME}."
            echo "You may need to reboot to load the driver."
        else
            echo
            echo "${BKUP_DRIVER_NAME} loaded."
            echo
        fi
    fi
fi

echo "Finished"
echo
exit 0;


