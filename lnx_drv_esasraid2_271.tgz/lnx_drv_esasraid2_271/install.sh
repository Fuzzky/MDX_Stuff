#!/bin/bash
#script version
VERSION="2.64"

# Standard exit codes:
#  0:     Success, driver loaded
#  1:     An error occurred
#  2:     Build in command failure
#  126:   Cannot execute command
#  127:   Command not found
#  128:   Invalid exit argument
#  128+N: Terminated by signal N
#  !0:    Syntax error

# Custom exit codes
#  101:   Success, no adapter present: shutdown?
#  102:   Success, current driver in use: reboot?


SHUTDOWN="No"
REBOOT="No"


if [ "$1" = "auto" ]; then
    INTERACTIVE=0
else
    INTERACTIVE=1
fi


if [[ $(whoami) != "root" ]]; then
    echo "This script must be run by root!" 1>&2
    exit 1
fi


# Purpose: Determine if the machine needs to be shutdown to install the adapter
#          for the drivers that was just installed.  Check $SHUTDOWN
#
# Params:  $1- The driver message key, i.e. the driver name
#
function checkLoadStatus() {
    # oswrap.c 1 -> 37
    MISSING_ORIG_MSG="Driver not loading"

    # oswrap.c 38 -> current
    MISSING_CURR_MSG="Driver will not be loaded because no ATTO \w+ devices were found"

    # Some drivers printed this with a 0 before printing "not loading", so don't
    # assume this means something was found
    FOUND_MSG="Found ([0-9])+ adapters"


    # Find the last line that is one of the status messages above.  Look for the
    # failure messages too in case there is a success in the previous lines of
    # output
    STATUS_LINE=`dmesg | grep $1 | tail -n 10 | tac | grep -m 1 -E "$MISSING_ORIG_MSG|$MISSING_CURR_MSG|$FOUND_MSG"`


    # Capture the number of adapters, if possible.  NB the space around the capture
        # group, so it doesn't match e.g. 2 in esas2raid.
    ADAPTERS=`echo $STATUS_LINE | grep -o -E " ([0-9])+ "`

    if [ "$ADAPTERS" = "" -o "$ADAPTERS" = " 0 " ]; then
        SHUTDOWN="Yes"; # something other than the found count was printed
    fi
}

function pauseandexit {
    if [ "$INTERACTIVE" == "1" ]; then
        echo "Press any key to finish..."
        read -s -n 1
        echo
    fi
    exit $1
}

function checkforcommand {
    COMMAND=`which $1`
    if [ "${COMMAND}" = "" ]; then
        echo
        echo "ERROR: Unable to find '$1'."
        echo
        echo "       You must have '$1' to install this driver."
        echo
    if [ "${IS_RHEL_DERIVED}" = "1" ]; then
        echo
        echo "       You should be able to correct this problem by"
        echo "       running the following command:"
        echo
        echo "       # yum install $1"
    else
        echo "       Please refer to your system documentation for"
        echo "       instructions on obtaining '$1'."
    fi
        echo
        pauseandexit 1
    fi
}
    

echo
echo "ATTO Technology, Inc."
echo "Linux Driver Install Script v${VERSION}"
echo

# Make sure we are running in the directory where the script is located

SOURCE="${BASH_SOURCE[0]}"
while [ -h "$SOURCE" ]; do # resolve $SOURCE until the file is no longer a symlink
  DIR="$( cd -P "$( dirname "$SOURCE" )" && pwd )"
  SOURCE="$(readlink "$SOURCE")"
  [[ $SOURCE != /* ]] && SOURCE="$DIR/$SOURCE" # if $SOURCE was a relative symlink, we need to resolve it relative to the path where the symlink file was located
done
DIR="$( cd -P "$( dirname "$SOURCE" )" && pwd )"

cd $DIR

# Determine the distribution

DISTRIBUTION="Unknown"
IS_RHEL_DERIVED=0
IS_SUSE_DERIVED=0

IS_SLES=`grep 'SUSE Linux Enterprise Server' /etc/issue`
IS_OPENSUSE=`grep 'openSUSE' /etc/issue`
if [ "${IS_SLES}" != "" ]; then
    IS_SUSE_DERIVED=1
    VERSION=`cat /etc/issue | cut -f 7 -d " " | tr -d '\n'`
    SERVICE_PACK=`cat /etc/issue | cut -f 8 -d " " | tr -d '\n'`
    if [ "${SERVICE_PACK:0:2}" == "SP" ]; then
	DISTRIBUTION="SLES ${VERSION} ${SERVICE_PACK}"
    else
	DISTRIBUTION="SLES ${VERSION}"
    fi
elif [ "${IS_OPENSUSE}" != "" ]; then
    IS_SUSE_DERIVED=1
    VERSION=`cat /etc/issue | cut -f 4 -d " " | tr -d '\n'`
    DISTRIBUTION="openSUSE ${VERSION}"
elif [ -e /etc/redhat-release ]; then
    IS_RHEL_DERIVED=1
    IS_RHEL=`grep 'Red Hat Enterprise Linux Server' /etc/redhat-release`
    IS_CENTOS=`grep CentOS /etc/redhat-release`
    IS_FEDORA=`grep Fedora /etc/redhat-release`
    if [ "${IS_RHEL}" != "" ]; then
	VERSION=`cat /etc/redhat-release | cut -f 7 -d " "`
	DISTRIBUTION="RHEL ${VERSION}"
    elif [ "${IS_CENTOS}" != "" ]; then
	VERSION=`cat /etc/redhat-release | cut -f 4 -d " "`
	DISTRIBUTION="CentOS ${VERSION}"
    elif [ "${IS_FEDORA}" != "" ]; then
	VERSION=`cat /etc/redhat-release | cut -f 3 -d " "`
	DISTRIBUTION="Fedora ${VERSION}"
    fi
fi


# Check for a space in the current path name because
# the kernel Makefile is too stupid to deal with that

SPACE_IN_PWD=`pwd | grep " "`

if [ "${SPACE_IN_PWD}" != "" ]; then
    echo "ERROR: You are attempting to install this driver from a directory"
    echo "       which contains a space character somewhere in the path name."
    echo
    echo "       The Linux kernel Makefile cannot handle such a directory."
    echo
    echo "       Please extract the driver package to a different directory"
    echo "       and try again."
    echo
    pauseandexit 1
fi

# Check for kernel source code availability

FULL_KERNEL_VERSION=`uname -r`
KDIR="/lib/modules/${FULL_KERNEL_VERSION}/build"

if [ ! -x ${KDIR} ]; then
    echo
    echo "ERROR: Unable to find the kernel header directory."
    echo
    echo "       The kernel headers were expected in"
    echo "       ${KDIR}"
if [ "${IS_RHEL_DERIVED}" = "1" ]; then
    echo
    echo "       You should be able to correct this problem by"
    echo "       running the following command:"
    echo
    echo "       # yum install kernel-devel-${FULL_KERNEL_VERSION}"
else
    echo
    echo "       Please refer to your system documentation for"
    echo "       instructions on obtaining the kernel headers."
    echo "       This may be called the \"kernel-devel\" package."
    echo
    echo "       If the kernel headers are installed in a different"
    echo "       location, you can build the driver manually from the src/"
    echo "       directory by specifying the correct kernel header directory"
    echo "       on the make command line with the KDIR variable, eg:"
    echo
    echo "       # make clean install KDIR=/usr/src/kernel"
fi
    echo
    pauseandexit 1
fi

# Check for required commands

checkforcommand gcc
checkforcommand make

# Figure out what sort of driver we are building

DRIVER_NAME=`ls src/*core_x86.o | cut -d_ -f1 | cut -d/ -f2`
MP_DRIVER_NAME="UNDEFINED"
CONFLICT_DRIVER_NAME="UNDEFINED"
STD_DRIVER_NAME=${DRIVER_NAME}
VNIC_DRIVER_NAME=""

if [ "${DRIVER_NAME}" = "celerityfc" ]; then
    PRETTY_NAME="Celerity FC"
elif [ "${DRIVER_NAME}" = "esasraid" ]; then
    PRETTY_NAME="ExpressSAS RAID"
elif [ "${DRIVER_NAME}" = "esashba" ]; then
    PRETTY_NAME="ExpressSAS HBA"
elif [ "${DRIVER_NAME}" = "celerity8fc" ]; then
    PRETTY_NAME="Celerity FC 8Gb"
    MP_DRIVER_NAME="celerity8fcmp"
elif [ "${DRIVER_NAME}" = "celerity16fc" ]; then
    PRETTY_NAME="Celerity FC 16Gb/32Gb"
    MP_DRIVER_NAME="celerity16fcmp"
elif [ "${DRIVER_NAME}" = "esas2hba" ]; then
    PRETTY_NAME="ExpressSAS 6Gb HBA"
    CONFLICT_DRIVER_NAME="pm8001"
elif [ "${DRIVER_NAME}" = "esas4hba" ]; then
    PRETTY_NAME="ExpressSAS 12Gb HBA"
    CONFLICT_DRIVER_NAME="pm80xx"
elif [ "${DRIVER_NAME}" = "celerity8fcmp" ]; then
    PRETTY_NAME="Celerity Multipathing FC 8Gb"
    STD_DRIVER_NAME="celerity8fc"
    MP_DRIVER_NAME=${DRIVER_NAME}
elif [ "${DRIVER_NAME}" = "celerity16fcmp" ]; then
    PRETTY_NAME="Celerity Multipathing FC 16Gb/32Gb"
    STD_DRIVER_NAME="celerity16fc"
    MP_DRIVER_NAME=${DRIVER_NAME}
elif [ "${DRIVER_NAME}" = "esas2raid" ]; then
    PRETTY_NAME="ExpressSAS 6Gb RAID"
    CONFLICT_DRIVER_NAME="esas2r"
elif [ "${DRIVER_NAME}" = "fastframe" ]; then
    PRETTY_NAME="FastFrame FCoE"
    CONFLICT_DRIVER_NAME="ixgbe"
    VNIC_DRIVER_NAME="ffxgbe"
elif [ "${DRIVER_NAME}" = "esas3hba" ]; then
    PRETTY_NAME="ExpressSAS 6Gb HBA"
else
    echo
    echo "ERROR: Unable to detect driver name"
    echo
    echo "       This driver package may have been corrupted."
    echo
    echo "       Please re-download the package and try again."
    echo
    pauseandexit 1
fi

# Check to see if this distribution blocks the loading of 
# "unsupported modules" and ask the user if they wish
# to override this feature

AUTOLOAD_DRIVERS="y"

UNSUPPORTED_MODULES_CONFIG_FILE=""

if [ -e /etc/modprobe.d/unsupported-modules ]; then
    UNSUPPORTED_MODULES_CONFIG_FILE="/etc/modprobe.d/unsupported-modules"
elif [ -e /etc/modprobe.d/10-unsupported-modules.conf ]; then
    UNSUPPORTED_MODULES_CONFIG_FILE="/etc/modprobe.d/10-unsupported-modules.conf"
fi

if [ "$UNSUPPORTED_MODULES_CONFIG_FILE" != "" ]; then
    UNSUPPORTED_MODULES_ALLOWED=`grep "^allow_unsupported_modules 0" $UNSUPPORTED_MODULES_CONFIG_FILE`
    if [ "$UNSUPPORTED_MODULES_ALLOWED" != "" ]; then
        if [ "$INTERACTIVE" == "1" ]; then
            echo 
            echo "Your Linux distribution is currently configured to block the loading of"
            echo "unsupported modules, including the module you are attempting to install."
            echo "Would you like to override this setting to allow this module to load? [Y/n]"
            read -n 1 RESPONSE
	    echo
        else
            echo "Automatically setting allow_unsupported_modules in $UNSUPPORTED_MODULES_CONFIG_FILE..."
            RESPONSE="y"
        fi
        echo 
        if [ "${RESPONSE}" != "n" -a "${RESPONSE}" != "N" ]; then
            grep -v ^allow_unsupported_modules $UNSUPPORTED_MODULES_CONFIG_FILE > /tmp/atto.unsupp-mod
            echo "allow_unsupported_modules 1" >> /tmp/atto.unsupp-mod
            mv $UNSUPPORTED_MODULES_CONFIG_FILE ./unsupported-modules.backup
            mv /tmp/atto.unsupp-mod $UNSUPPORTED_MODULES_CONFIG_FILE
            echo "Unsupported modules are now allowed to load automatically on this system."
            echo 
        else
            echo "You have chosen not to override the blocking of unsupported module loading,"
            echo "so the driver you are installing will not load without manual intervention."
            echo "For information on how to correct this issue, please refer to the file"
            echo "$UNSUPPORTED_MODULES_CONFIG_FILE or your system documentation."
            echo 
            AUTOLOAD_DRIVERS="n"
        fi
    fi
fi


# If loading standard driver, check for MP version, and vice-versa
MODULE_ROOT=/lib/modules/${FULL_KERNEL_VERSION}/kernel/drivers

STD_DRIVER_INSTALLED=`find ${MODULE_ROOT} -name ${STD_DRIVER_NAME}.ko | grep -v ${MP_DRIVER_NAME}`
MP_DRIVER_INSTALLED=`find ${MODULE_ROOT} -name ${MP_DRIVER_NAME}.ko`
CONFLICT_DRIVER_INSTALLED=`find ${MODULE_ROOT} -name ${CONFLICT_DRIVER_NAME}.ko`

if [ "${DRIVER_NAME}" = "esas2hba" -a "${CONFLICT_DRIVER_INSTALLED}" = "" ]; then
    # esas2hba may also conflict with the pm80xx driver
    CONFLICT_DRIVER_NAME="pm80xx"
    CONFLICT_DRIVER_INSTALLED=`find ${MODULE_ROOT} -name ${CONFLICT_DRIVER_NAME}.ko`
fi

if [ "$DRIVER_NAME" == "$STD_DRIVER_NAME" ]; then
  if [ "$MP_DRIVER_INSTALLED" != "" ]; then
    # unload & uninstall mp driver
    echo "A conflict has been discovered with a preexisting ATTO multipathing"
    echo "driver for this device."
    echo
    if [ "$INTERACTIVE" == "1" ]; then
        echo "You may uninstall the ${MP_DRIVER_NAME} driver here, note that"
        echo "multipathing features will no longer be available."
        echo "The driver module will be preserved and can be reinstalled if the "
        echo "${DRIVER_NAME} driver is uninstalled using the uninstall script."
        echo
        echo "Would you like to unload and uninstall ${MP_DRIVER_NAME}? [Y/n]"
        read -n 1 RESPONSE
	echo
    else
        echo "Unloading and uninstalling ${MP_DRIVER_NAME}..."
        RESPONSE="y"
    fi
    if [ "${RESPONSE}" != "n" -a "${RESPONSE}" != "N" ]; then
        # Unload the driver and rename the module so that it can possibly be reinstalled later
        mv ${MP_DRIVER_INSTALLED} ${MP_DRIVER_INSTALLED/%.ko/.bkup}
        echo "${MP_DRIVER_NAME} backed up."
        echo
        if rmmod ${MP_DRIVER_NAME} ; then
            echo
            echo "${MP_DRIVER_NAME} unloaded."
        else
            echo
            echo "${MP_DRIVER_NAME} unload FAILED."
        fi
    fi
  fi
fi


if [ "$DRIVER_NAME" == "$MP_DRIVER_NAME" ]; then
  if [ "$STD_DRIVER_INSTALLED" != "" ]; then
    # unload & uninstall std driver
    echo "A conflict has been discovered with a preexisting ATTO non-multipathing"
    echo "driver for this device."
    echo
    if [ "$INTERACTIVE" == "1" ]; then
        echo "You may uninstall the ${STD_DRIVER_NAME} driver here."
        echo "The driver module will be preserved and can be reinstalled if the"
        echo "${DRIVER_NAME} driver is uninstalled using the uninstall script."
        echo
        echo "Would you like to unload and uninstall ${STD_DRIVER_NAME}? [Y/n]"
        read -n 1 RESPONSE
	echo
    else
        echo "Unloading and uninstalling ${STD_DRIVER_NAME}..."
        RESPONSE="y"
    fi
    if [ "${RESPONSE}" != "n" -a "${RESPONSE}" != "N" ]; then
        # Unload the driver and rename the module so that it can possibly be reinstalled later
        mv ${STD_DRIVER_INSTALLED} ${STD_DRIVER_INSTALLED/%.ko/.bkup}
        echo "${STD_DRIVER_NAME} backed up."
        echo
        if rmmod ${STD_DRIVER_NAME} ; then
            echo
            echo "${STD_DRIVER_NAME} unloaded."
        else
            echo
            echo "${STD_DRIVER_NAME} unload FAILED."
        fi
    fi
  fi
fi

if [ "$DRIVER_NAME" == "$MP_DRIVER_NAME" -o "$DRIVER_NAME" == "$STD_DRIVER_NAME" ]; then
  if [ "$CONFLICT_DRIVER_INSTALLED" != "" ]; then
    # unload & uninstall 3rd party driver conflict
    echo "A conflict has been discovered with a third-party driver (${CONFLICT_DRIVER_NAME})."
    echo
    if [ "$INTERACTIVE" == "1" ]; then
        echo "This could prevent the ATTO driver from operating properly."
        echo "You may uninstall the ${CONFLICT_DRIVER_NAME} driver here, although"
        echo "any devices that depend on it will no longer function."
        echo "The driver module will be preserved and can be reinstalled if the "
        echo "${DRIVER_NAME} driver is uninstalled using the uninstall script."
        echo
        echo "Would you like to unload and uninstall ${CONFLICT_DRIVER_NAME}? [Y/n]"
        read -n 1 RESPONSE
	echo
    else
        echo "Unloading and uninstalling ${CONFLICT_DRIVER_NAME}..."
        RESPONSE="y"
    fi
    if [ "${RESPONSE}" != "n" -a "${RESPONSE}" != "N" ]; then
        # Unload the driver and rename the module so that it can possibly be reinstalled later
        mv ${CONFLICT_DRIVER_INSTALLED} ${CONFLICT_DRIVER_INSTALLED/%.ko/.bkup}
        echo "${CONFLICT_DRIVER_NAME} backed up."
        echo
        if rmmod ${CONFLICT_DRIVER_NAME} ; then
            echo
            echo "${CONFLICT_DRIVER_NAME} unloaded."
        else
            echo
            echo "${CONFLICT_DRIVER_NAME} unload FAILED."
        fi
    fi
  fi
fi

STD_DRIVER_LOADED=`lsmod | grep ${STD_DRIVER_NAME} | grep -v ${MP_DRIVER_NAME}`
if [ "${VNIC_DRIVER_NAME}" == "" ]; then
    VNIC_DRIVER_LOADED=""
else
    VNIC_DRIVER_LOADED=`lsmod | grep ${VNIC_DRIVER_NAME}`
fi
ATTOCFG_DRIVER_LOADED=`lsmod | grep attocfg`
MP_DRIVER_LOADED=`lsmod | grep ${MP_DRIVER_NAME}`

VNIC_DRIVER_WAS_UNLOADED="FALSE"
ATTOCFG_DRIVER_WAS_UNLOADED="FALSE"

# Build & install the modules

echo "Building and installing the ATTO ${PRETTY_NAME} driver, please wait..."

cd src

LOAD_MODULE="n"

if make -j clean install >make.log 2>make.err; then
    echo
    echo "Successfully installed the ${PRETTY_NAME} driver"
    if [ "${AUTOLOAD_DRIVERS}" == "y" ]; then
#       if lsmod | grep ${DRIVER_NAME} > /dev/null 2>/dev/null; then
        if [ "${DRIVER_NAME}" == "${STD_DRIVER_NAME}" -a "${STD_DRIVER_LOADED}" != "" ]; then
            echo
            echo "An older version of ${DRIVER_NAME} appears to be loaded"
            if [ "$INTERACTIVE" == "1" ]; then
                echo "Would you like to try to unload the old version and load the new one? [Y/n]"
                read -n 1 RESPONSE
		echo 
		# note: sometimes performing an action like this immediately after reading
		# keyboard input can cause the key input queue to get stuck and act strangely
		# for example, the system may print out a series like this: "yyyyyy"
		sleep 1
            else
                echo "Unloading the old version and loading the new one..."
                RESPONSE="y"
                LOAD_MODULE="y"
            fi
            if [ "${RESPONSE}" != "n" -a "${RESPONSE}" != "N" ]; then
                echo
                if [ "${ATTOCFG_DRIVER_LOADED}" != "" ]; then
                    if rmmod attocfg ; then
                        ATTOCFG_DRIVER_WAS_UNLOADED="TRUE"
                    else
                        echo "Unable to unload 'attocfg'"
                    fi
                fi
                if [ "${VNIC_DRIVER_LOADED}" != "" ]; then
                    if rmmod ${VNIC_DRIVER_NAME} ; then
                        VNIC_DRIVER_WAS_UNLOADED="TRUE"
                    else
                        echo "Unable to unload ${VNIC_DRIVER_NAME}"
                    fi
                fi
                if ! rmmod ${DRIVER_NAME}; then
                    echo "Sorry, could not unload the old driver"
                    echo "You may need to reboot to use the new driver"
                    REBOOT="Yes"
                else
                    echo "Old version of ${DRIVER_NAME} successfully unloaded"
                    LOAD_MODULE="y"
                fi
            fi
        elif [ "${DRIVER_NAME}" == "${MP_DRIVER_NAME}" -a "${MP_DRIVER_LOADED}" != "" ]; then
            echo
            echo "An older version of ${DRIVER_NAME} appears to be loaded"
            if [ "$INTERACTIVE" == "1" ]; then
                echo "Would you like to try to unload the old version and load the new one? [Y/n]"
                read -n 1 RESPONSE
		echo 
		sleep 1
            else
                echo "Unloading the old version and loading the new one..."
                RESPONSE="y"
                LOAD_MODULE="y"
            fi
            if [ "${RESPONSE}" != "n" -a "${RESPONSE}" != "N" ]; then
                echo
                if [ "${ATTOCFG_DRIVER_LOADED}" != "" ]; then
                    if rmmod attocfg ; then
                        ATTOCFG_DRIVER_WAS_UNLOADED="TRUE"
                    else
                        echo "Unable to unload 'attocfg'"
                    fi
                fi
                if ! rmmod ${DRIVER_NAME}; then
                    echo "Sorry, could not unload the old driver"
                    echo "You may need to reboot to use the new driver"
                    REBOOT="Yes"
                else
                    echo "Old version of ${DRIVER_NAME} successfully unloaded"
                    LOAD_MODULE="y"
                fi
            fi
        else
            if [ "$INTERACTIVE" == "1" ]; then
                echo
                echo "Would you like to load the driver now? [Y/n]"
                read -n 1 LOAD_MODULE
		echo
            else
                LOAD_MODULE="y"
            fi
        fi
        echo
        if [ "${LOAD_MODULE}" != "n" -a "${LOAD_MODULE}" != "N" ]; then
            echo "Please wait a moment while the driver loads..."
            echo
	    sleep 1
            if ! modprobe ${DRIVER_NAME}; then
                echo "Driver load failed!  Displaying relevant dmesg output:"
                echo "---------"
                dmesg | grep ${DRIVER_NAME} | tail -n 10
                echo "---------          "

                checkLoadStatus ${DRIVER_NAME}
            else
                echo "The ${DRIVER_NAME} driver has been loaded"

                if [ "${ATTOCFG_DRIVER_WAS_UNLOADED}" == "TRUE" ]; then
                    if ! modprobe attocfg; then
                        echo "Driver attocfg reload failed!  Displaying relevant dmesg output:"
                        echo "---------"
                        dmesg | grep attocfg | tail -n 10
                        echo "---------          "
                    else
                        echo "The attocfg driver has been reloaded"
                    fi
                fi
                if [ "${VNIC_DRIVER_WAS_UNLOADED}" == "TRUE" ]; then
                    if ! modprobe ${VNIC_DRIVER_NAME}; then
                        echo "Driver ${VNIC_DRIVER_NAME} reload failed!  Displaying relevant dmesg output:"
                        echo "---------"
                        dmesg | grep ${VNIC_DRIVER_NAME} | tail -n 10
                        echo "---------          "
                    else
                        echo "The ${VNIC_DRIVER_NAME} driver has been reloaded"
                    fi
                else
                    if [ "${VNIC_DRIVER_NAME}" != "" ]; then
                        if [ "$INTERACTIVE" == "1" ]; then
                            echo
                            echo "There is an additional driver (${VNIC_DRIVER_NAME}) to provide Ethernet "
                            echo "access through your ${DRIVER_NAME} adapter"
                            echo
                            echo "Would you like to install the ${VNIC_DRIVER_NAME} virtual network driver as well? [Y/n]"
                            read -n 1 LOAD_MODULE
                            echo
                        else
                            LOAD_MODULE="y"
                        fi

                        if [ "${LOAD_MODULE}" != "n" -a "${LOAD_MODULE}" != "N" ]; then
                            echo "Please wait a moment while the driver loads..."
                            echo
			    sleep 1
                            if ! modprobe ${VNIC_DRIVER_NAME}; then
                                echo "Driver load failed!  Displaying relevant dmesg output:"
                                echo "---------"
                                dmesg | grep ${VNIC_DRIVER_NAME} | tail -n 10
                                echo "---------          "
                            else
				PROCDIR=/proc/scsi/fastframe/
                                echo "The ${VNIC_DRIVER_NAME} driver has been loaded"
				whilecnt=0
				ckvnic=`grep "Virtual network interface" $PROCDIR/[1-9]*`
				#echo $ckvnic
				while [ -z "$ckvnic" ]
				do
					(( whilecnt += 1 ))
					sleep 1
					if [ $whilecnt -gt 5 ]
					then
						echo "Virtual Network interface failed to load properly - aborting"
						exit 0
					fi
					ckvnic=`grep "Virtual network interface" $PROCDIR/[1-9]*`
				done
                            fi
                        else
                            echo "You can load the driver using the command 'modprobe ${VNIC_DRIVER_NAME}'"
                        fi
                    fi
                fi
            fi
        else
            echo "You can load the driver using the command 'modprobe ${DRIVER_NAME}'"
        fi
        echo
    fi
else
    echo
    echo "An error occurred while making the driver"
    echo
    echo "---make output---"
    cat make.log
    echo
    echo "---make errors---"
    cat make.err
    echo "---------"
    echo
    pauseandexit 1
fi

cd ..

# Execute the NIC installer and configurator - if they exist
if  [ "$LOAD_MODULE" = "Y" -o "$LOAD_MODULE" = "y" ]; then
    if [ -e ./udev-rules.sh  ]; then
        ./udev-rules.sh install
        if [ $INTERACTIVE = 1 ]; then 
            echo -e "Would you like to configure your ATTO Ethernet interfaces now? [N/y]"
            read -n 1 ANS
	    echo 
            if [ "$ANS" = "y" -o "$ANS" = "Y" ]; then
                ./if_menu.sh
            fi
        else
            echo "No interfaces configured - you can use if_menu.sh or edit your ethernet configuration files manually"
        fi
    fi
fi

# Execute the CLI tool installer - if it exists
if [ -e ./cli_install.sh  ]; then
    ./cli_install.sh $1
fi

if [ $SHUTDOWN = "Yes" -a "$INTERACTIVE" = 0 ]; then
    pauseandexit 101
fi

if [ $REBOOT = "Yes" -a "$INTERACTIVE" = 0 ]; then
    pauseandexit 102
fi

pauseandexit 0
